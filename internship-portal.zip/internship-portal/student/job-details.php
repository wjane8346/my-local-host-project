<?php
require_once '../includes/db_connect.php';
require_once '../includes/auth.php';
requireStudent();

$student = getCurrentUser($conn);
$job_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Get job details
$query = "SELECT j.*, c.name as company_name, c.description as company_description, c.industry, c.size, c.website
          FROM jobs j
          JOIN companies c ON j.company_id = c.id
          WHERE j.id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $job_id);
$stmt->execute();
$job = $stmt->get_result()->fetch_assoc();

// Check if already applied
$applied = false;
if ($job) {
    $check = "SELECT id FROM applications WHERE student_id = ? AND job_id = ?";
    $stmt = $conn->prepare($check);
    $stmt->bind_param("ii", $student['id'], $job_id);
    $stmt->execute();
    $applied = $stmt->get_result()->num_rows > 0;
}

// Handle application
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['apply']) && !$applied) {
    $query = "INSERT INTO applications (student_id, job_id, applied_date, status) VALUES (?, ?, CURDATE(), 'pending')";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $student['id'], $job_id);
    if ($stmt->execute()) {
        header("Location: applications.php");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $job ? htmlspecialchars($job['title']) : 'Job Not Found' ?> - SmartIntern Kenya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #0f172a;
            color: #e2e8f0;
        }
        
        .flag-header {
            height: 4px;
            background: linear-gradient(90deg, 
                #000000 0%, #000000 33.33%,
                #b91c1c 33.33%, #b91c1c 66.66%,
                #059669 66.66%, #059669 100%);
        }
        
        .navbar {
            background: #1e293b;
            border-bottom: 1px solid #334155;
            padding: 1rem 0;
        }
        
        .container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        .navbar-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .navbar-brand {
            font-weight: 700;
            font-size: 1.3rem;
            color: #4ade80;
            text-decoration: none;
        }
        
        .btn-back {
            color: #4ade80;
            text-decoration: none;
            padding: 8px 20px;
            border: 1px solid #4ade80;
            border-radius: 6px;
        }
        
        .job-header {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 12px;
            padding: 30px;
            margin: 30px 0;
        }
        
        .job-header h1 {
            color: white;
            font-size: 2rem;
            margin-bottom: 10px;
        }
        
        .company-name {
            color: #4ade80;
            font-size: 1.2rem;
            margin-bottom: 20px;
        }
        
        .job-meta {
            display: flex;
            gap: 30px;
            margin-bottom: 20px;
        }
        
        .job-meta-item {
            display: flex;
            align-items: center;
            gap: 10px;
            color: #94a3b8;
        }
        
        .job-meta-item i {
            color: #4ade80;
        }
        
        .salary-box {
            background: #0f172a;
            border: 1px solid #4ade80;
            border-radius: 8px;
            padding: 15px 25px;
            display: inline-block;
        }
        
        .salary-box .label {
            color: #94a3b8;
            font-size: 0.9rem;
        }
        
        .salary-box .amount {
            color: #4ade80;
            font-size: 1.5rem;
            font-weight: bold;
        }
        
        .section {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 20px;
        }
        
        .section h2 {
            color: white;
            font-size: 1.3rem;
            margin-bottom: 20px;
        }
        
        .section p {
            color: #94a3b8;
            line-height: 1.7;
        }
        
        .company-card {
            display: flex;
            align-items: center;
            gap: 20px;
            margin-bottom: 20px;
        }
        
        .company-logo {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, #059669, #4ade80);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.5rem;
            font-weight: bold;
        }
        
        .company-details h3 {
            color: white;
            margin-bottom: 5px;
        }
        
        .company-details p {
            color: #94a3b8;
        }
        
        .btn-apply {
            background: #4ade80;
            color: #0f172a;
            border: none;
            padding: 15px 40px;
            border-radius: 8px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            width: 100%;
        }
        
        .btn-apply:hover:not(:disabled) {
            background: #22c55e;
        }
        
        .btn-apply:disabled {
            background: #334155;
            color: #94a3b8;
            cursor: not-allowed;
        }
        
        .footer {
            background: #1e293b;
            border-top: 1px solid #334155;
            padding: 30px 0;
            margin-top: 50px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="flag-header"></div>
    
    <nav class="navbar">
        <div class="container navbar-content">
            <a href="../index.php" class="navbar-brand">
                <i class="fas fa-shield-alt"></i>SmartIntern Kenya
            </a>
            
            <a href="javascript:history.back()" class="btn-back">
                <i class="fas fa-arrow-left me-2"></i>Back
            </a>
        </div>
    </nav>
    
    <?php if ($job): ?>
        <div class="container">
            <!-- Job Header -->
            <div class="job-header">
                <h1><?= htmlspecialchars($job['title']) ?></h1>
                <div class="company-name">
                    <i class="fas fa-building"></i> <?= htmlspecialchars($job['company_name']) ?>
                </div>
                
                <div class="job-meta">
                    <div class="job-meta-item">
                        <i class="fas fa-map-marker-alt"></i>
                        <span><?= htmlspecialchars($job['location']) ?></span>
                    </div>
                    <div class="job-meta-item">
                        <i class="fas fa-clock"></i>
                        <span><?= htmlspecialchars($job['duration']) ?></span>
                    </div>
                    <div class="job-meta-item">
                        <i class="fas fa-calendar"></i>
                        <span>Deadline: <?= date('M d, Y', strtotime($job['deadline'])) ?></span>
                    </div>
                </div>
                
                <div class="salary-box">
                    <div class="label">Monthly Salary</div>
                    <div class="amount">KSh <?= number_format($job['salary']) ?></div>
                </div>
            </div>
            
            <!-- Job Description -->
            <div class="section">
                <h2>Job Description</h2>
                <p><?= nl2br(htmlspecialchars($job['description'])) ?></p>
            </div>
            
            <!-- Requirements -->
            <div class="section">
                <h2>Requirements</h2>
                <p><?= nl2br(htmlspecialchars($job['requirements'])) ?></p>
            </div>
            
            <!-- Company Info -->
            <div class="section">
                <h2>About the Company</h2>
                <div class="company-card">
                    <div class="company-logo">
                        <?= substr($job['company_name'], 0, 1) ?>
                    </div>
                    <div class="company-details">
                        <h3><?= htmlspecialchars($job['company_name']) ?></h3>
                        <p><?= htmlspecialchars($job['industry']) ?> • <?= htmlspecialchars($job['size']) ?> employees</p>
                        <p><i class="fas fa-globe"></i> <a href="http://<?= htmlspecialchars($job['website']) ?>" target="_blank" style="color: #4ade80;"><?= htmlspecialchars($job['website']) ?></a></p>
                    </div>
                </div>
                <p><?= nl2br(htmlspecialchars($job['company_description'] ?? 'No description available.')) ?></p>
            </div>
            
            <!-- Apply Button -->
            <form method="POST">
                <button type="submit" name="apply" class="btn-apply" <?= $applied ? 'disabled' : '' ?>>
                    <?php if ($applied): ?>
                        <i class="fas fa-check me-2"></i>Already Applied
                    <?php else: ?>
                        <i class="fas fa-paper-plane me-2"></i>Apply for this Internship
                    <?php endif; ?>
                </button>
            </form>
        </div>
    <?php else: ?>
        <div class="container">
            <div style="text-align: center; padding: 100px 0;">
                <i class="fas fa-exclamation-circle fa-4x" style="color: #ef4444; margin-bottom: 20px;"></i>
                <h1 style="color: white;">Job Not Found</h1>
                <p style="color: #94a3b8;">The internship you're looking for doesn't exist.</p>
                <a href="dashboard.php" class="btn-back" style="display: inline-block; margin-top: 20px;">Back to Dashboard</a>
            </div>
        </div>
    <?php endif; ?>
    
    <footer class="footer">
        <div class="container">
            <p>&copy; 2026 SmartIntern Kenya</p>
        </div>
    </footer>
</body>
</html>