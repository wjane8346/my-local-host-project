<?php
require_once '../includes/db_connect.php';
require_once '../includes/auth.php';
requireStudent();

$student = getCurrentUser($conn);
$message = '';
$error = '';

// Handle password change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $current = $_POST['current_password'] ?? '';
    $new = $_POST['new_password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';
    
    if (empty($current) || empty($new) || empty($confirm)) {
        $error = 'Please fill in all fields';
    } elseif ($new !== $confirm) {
        $error = 'New passwords do not match';
    } elseif (strlen($new) < 8) {
        $error = 'Password must be at least 8 characters';
    } else {
        // Verify current password
        if (password_verify($current, $student['password'])) {
            $new_hash = password_hash($new, PASSWORD_DEFAULT);
            $query = "UPDATE students SET password = ? WHERE id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("si", $new_hash, $student['id']);
            
            if ($stmt->execute()) {
                $message = "Password changed successfully!";
            } else {
                $error = "Error changing password";
            }
        } else {
            $error = "Current password is incorrect";
        }
    }
}

// Handle notification preferences
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_notifications'])) {
    // This would save to database in real implementation
    $message = "Notification preferences saved!";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Settings - SmartIntern Kenya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #0f172a;
            color: #e2e8f0;
        }
        
        .flag-header {
            height: 4px;
            background: linear-gradient(90deg, 
                #000000 0%, #000000 33.33%,
                #b91c1c 33.33%, #b91c1c 66.66%,
                #059669 66.66%, #059669 100%);
        }
        
        .navbar {
            background: #1e293b;
            border-bottom: 1px solid #334155;
            padding: 1rem 0;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        .navbar-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .navbar-brand {
            font-weight: 700;
            font-size: 1.3rem;
            color: #4ade80;
            text-decoration: none;
        }
        
        .navbar-brand i {
            color: #4ade80;
        }
        
        .nav-links {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .nav-links a {
            color: #cbd5e1;
            text-decoration: none;
            padding: 5px 10px;
        }
        
        .nav-links a:hover {
            color: #4ade80;
        }
        
        .nav-links a.active {
            color: #4ade80;
            border-bottom: 2px solid #4ade80;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
            color: #94a3b8;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #059669, #4ade80);
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
        }
        
        .btn-logout {
            color: #ef4444;
            text-decoration: none;
            padding: 8px 15px;
            border: 1px solid #ef4444;
            border-radius: 6px;
        }
        
        .page-title {
            margin: 30px 0;
        }
        
        .page-title h1 {
            color: white;
            font-size: 2rem;
        }
        
        .settings-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .settings-card {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 12px;
            padding: 25px;
        }
        
        .settings-card h2 {
            color: white;
            font-size: 1.3rem;
            margin-bottom: 20px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #cbd5e1;
            font-weight: 500;
        }
        
        .form-control {
            width: 100%;
            padding: 10px 15px;
            background: #0f172a;
            border: 1px solid #334155;
            border-radius: 8px;
            color: white;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #4ade80;
        }
        
        .checkbox-group {
            margin-bottom: 15px;
        }
        
        .checkbox-item {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 10px;
            color: #94a3b8;
        }
        
        .checkbox-item input[type="checkbox"] {
            width: 18px;
            height: 18px;
            accent-color: #4ade80;
        }
        
        .btn-primary {
            background: #4ade80;
            color: #0f172a;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
        }
        
        .btn-primary:hover {
            background: #22c55e;
        }
        
        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        
        .alert-success {
            background: #d1fae5;
            color: #065f46;
        }
        
        .alert-danger {
            background: #fee2e2;
            color: #b91c1c;
        }
        
        .footer {
            background: #1e293b;
            border-top: 1px solid #334155;
            padding: 30px 0;
            margin-top: 50px;
            text-align: center;
        }
        
        @media (max-width: 768px) {
            .settings-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="flag-header"></div>
    
    <nav class="navbar">
        <div class="container navbar-content">
            <a href="../index.php" class="navbar-brand">
                <i class="fas fa-shield-alt"></i>SmartIntern Kenya
            </a>
            
            <div class="nav-links">
                <a href="dashboard.php">Dashboard</a>
                <a href="profile.php">Profile</a>
                <a href="applications.php">Applications</a>
                <a href="matches.php">Job Matches</a>
                <a href="settings.php" class="active">Settings</a>
                
                <div class="user-info">
                    <div class="user-avatar">
                        <?= substr($student['name'], 0, 1) ?>
                    </div>
                    <span><?= htmlspecialchars($student['name']) ?></span>
                </div>
                
                <a href="../logout.php" class="btn-logout">Logout</a>
            </div>
        </div>
    </nav>
    
    <div class="container">
        <div class="page-title">
            <h1>Account Settings</h1>
        </div>
        
        <?php if ($message): ?>
            <div class="alert alert-success"><?= $message ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php endif; ?>
        
        <div class="settings-grid">
            <!-- Password Change -->
            <div class="settings-card">
                <h2>Change Password</h2>
                <form method="POST">
                    <div class="form-group">
                        <label>Current Password</label>
                        <input type="password" name="current_password" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label>New Password</label>
                        <input type="password" name="new_password" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Confirm New Password</label>
                        <input type="password" name="confirm_password" class="form-control" required>
                    </div>
                    
                    <button type="submit" name="change_password" class="btn-primary">Update Password</button>
                </form>
            </div>
            
            <!-- Notification Preferences -->
            <div class="settings-card">
                <h2>Notification Preferences</h2>
                <form method="POST">
                    <div class="checkbox-group">
                        <div class="checkbox-item">
                            <input type="checkbox" id="email_app" checked>
                            <label for="email_app">Application updates via email</label>
                        </div>
                        
                        <div class="checkbox-item">
                            <input type="checkbox" id="email_match" checked>
                            <label for="email_match">New job matches</label>
                        </div>
                        
                        <div class="checkbox-item">
                            <input type="checkbox" id="email_interview" checked>
                            <label for="email_interview">Interview reminders</label>
                        </div>
                        
                        <div class="checkbox-item">
                            <input type="checkbox" id="sms_alerts">
                            <label for="sms_alerts">SMS alerts for urgent updates</label>
                        </div>
                        
                        <div class="checkbox-item">
                            <input type="checkbox" id="newsletter">
                            <label for="newsletter">Monthly newsletter</label>
                        </div>
                    </div>
                    
                    <button type="submit" name="save_notifications" class="btn-primary">Save Preferences</button>
                </form>
            </div>
            
            <!-- Account Info -->
            <div class="settings-card">
                <h2>Account Information</h2>
                <div class="form-group">
                    <label>Member Since</label>
                    <input type="text" class="form-control" value="January 2026" disabled>
                </div>
                
                <div class="form-group">
                    <label>Last Login</label>
                    <input type="text" class="form-control" value="Today" disabled>
                </div>
                
                <div class="form-group">
                    <label>Account Status</label>
                    <input type="text" class="form-control" value="Active" style="color: #4ade80;" disabled>
                </div>
            </div>
            
            <!-- Danger Zone -->
            <div class="settings-card" style="border-color: #ef4444;">
                <h2 style="color: #ef4444;">Danger Zone</h2>
                <p style="color: #94a3b8; margin-bottom: 20px;">Once you delete your account, there is no going back. Please be certain.</p>
                
                <button class="btn-primary" style="background: #ef4444; color: white;" onclick="if(confirm('Are you sure you want to delete your account? This action cannot be undone.')) alert('Account deletion would happen here')">
                    Delete Account
                </button>
            </div>
        </div>
    </div>
    
    <footer class="footer">
        <div class="container">
            <p>&copy; 2026 SmartIntern Kenya</p>
        </div>
    </footer>
</body>
</html>