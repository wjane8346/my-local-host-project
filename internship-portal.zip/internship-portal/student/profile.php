<?php
require_once '../includes/db_connect.php';
require_once '../includes/auth.php';
requireStudent();

$student = getCurrentUser($conn);
$message = '';
$error = '';

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? $student['name'];
    $course = $_POST['course'] ?? $student['course'];
    $year = $_POST['year'] ?? $student['year'];
    $cgpa = $_POST['cgpa'] ?? $student['cgpa'];
    $skills = $_POST['skills'] ?? $student['skills'];
    $location = $_POST['location'] ?? $student['location'];
    $bio = $_POST['bio'] ?? $student['bio'];
    
    $query = "UPDATE students SET name=?, course=?, year=?, cgpa=?, skills=?, location=?, bio=? WHERE id=?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ssidsssi", $name, $course, $year, $cgpa, $skills, $location, $bio, $student['id']);
    
    if ($stmt->execute()) {
        $message = "Profile updated successfully!";
        $student = getCurrentUser($conn);
    } else {
        $error = "Error updating profile: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - SmartIntern Kenya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #0f172a;
            color: #e2e8f0;
        }
        
        .flag-header {
            height: 4px;
            background: linear-gradient(90deg, 
                #000000 0%, #000000 33.33%,
                #b91c1c 33.33%, #b91c1c 66.66%,
                #059669 66.66%, #059669 100%);
        }
        
        .navbar {
            background: #1e293b;
            border-bottom: 1px solid #334155;
            padding: 1rem 0;
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        .navbar-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .navbar-brand {
            font-weight: 700;
            font-size: 1.3rem;
            color: #4ade80;
            text-decoration: none;
        }
        
        .navbar-brand i {
            color: #4ade80;
            margin-right: 8px;
        }
        
        .nav-links {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .nav-links a {
            color: #cbd5e1;
            text-decoration: none;
            padding: 5px 10px;
            border-radius: 6px;
            transition: all 0.2s;
        }
        
        .nav-links a:hover {
            color: #4ade80;
            background: #0f172a;
        }
        
        .nav-links a.active {
            color: #4ade80;
            background: #0f172a;
            border-left: 3px solid #4ade80;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
            color: #94a3b8;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #059669, #4ade80);
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
        }
        
        .btn-logout {
            color: #ef4444;
            text-decoration: none;
            padding: 8px 15px;
            border-radius: 6px;
            border: 1px solid #ef4444;
            transition: all 0.2s;
        }
        
        .btn-logout:hover {
            background: #ef4444;
            color: white;
        }
        
        /* Profile Header */
        .profile-header {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 12px;
            padding: 30px;
            margin: 30px 0;
            display: flex;
            align-items: center;
            gap: 30px;
        }
        
        .profile-avatar {
            width: 100px;
            height: 100px;
            background: linear-gradient(135deg, #059669, #4ade80);
            border-radius: 50px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 2.5rem;
            font-weight: bold;
        }
        
        .profile-info h1 {
            color: white;
            margin-bottom: 5px;
        }
        
        .profile-info p {
            color: #94a3b8;
            margin-bottom: 5px;
        }
        
        .profile-meta {
            display: flex;
            gap: 20px;
            margin-top: 10px;
            color: #4ade80;
        }
        
        .profile-meta i {
            margin-right: 5px;
        }
        
        /* Form Card */
        .form-card {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 12px;
            padding: 30px;
            margin-bottom: 30px;
        }
        
        .form-card h2 {
            color: white;
            margin-bottom: 25px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #cbd5e1;
            font-weight: 500;
        }
        
        .form-control {
            width: 100%;
            padding: 12px 15px;
            background: #0f172a;
            border: 1px solid #334155;
            border-radius: 8px;
            color: white;
            font-size: 1rem;
            transition: all 0.2s;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #4ade80;
            box-shadow: 0 0 0 3px rgba(74, 222, 128, 0.2);
        }
        
        .form-control:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }
        
        textarea.form-control {
            resize: vertical;
            min-height: 100px;
        }
        
        /* Skills Section */
        .skills-section {
            margin: 20px 0;
        }
        
        .skill-tag {
            background: #0f172a;
            color: #94a3b8;
            padding: 5px 15px;
            border-radius: 20px;
            display: inline-block;
            margin: 0 5px 5px 0;
            border: 1px solid #334155;
        }
        
        /* Buttons */
        .btn-primary {
            background: #4ade80;
            color: #0f172a;
            border: none;
            padding: 12px 30px;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .btn-primary:hover {
            background: #22c55e;
            transform: translateY(-2px);
        }
        
        .btn-secondary {
            background: transparent;
            color: #e2e8f0;
            border: 1px solid #334155;
            padding: 12px 30px;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            text-decoration: none;
            display: inline-block;
            margin-left: 10px;
        }
        
        .btn-secondary:hover {
            border-color: #4ade80;
            color: #4ade80;
        }
        
        /* Alert */
        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        
        .alert-success {
            background: #d1fae5;
            color: #065f46;
            border: 1px solid #a7f3d0;
        }
        
        .alert-danger {
            background: #fee2e2;
            color: #b91c1c;
            border: 1px solid #fecaca;
        }
        
        /* Footer */
        .footer {
            background: #1e293b;
            border-top: 1px solid #334155;
            padding: 30px 0;
            margin-top: 50px;
            text-align: center;
            color: #64748b;
        }
        
        @media (max-width: 768px) {
            .profile-header {
                flex-direction: column;
                text-align: center;
            }
            
            .profile-meta {
                flex-direction: column;
                gap: 10px;
            }
            
            .navbar-content {
                flex-direction: column;
                gap: 15px;
            }
        }
    </style>
</head>
<body>
    <div class="flag-header"></div>
    
    <!-- Navbar -->
    <nav class="navbar">
        <div class="container navbar-content">
            <a href="../index.php" class="navbar-brand">
                <i class="fas fa-shield-alt"></i>SmartIntern Kenya
            </a>
            
            <div class="nav-links">
                <a href="dashboard.php">Dashboard</a>
                <a href="profile.php" class="active">Profile</a>
                <a href="applications.php">Applications</a>
                <a href="matches.php">Job Matches</a>
                <a href="settings.php">Settings</a>
                
                <div class="user-info">
                    <div class="user-avatar">
                        <?= substr($student['name'], 0, 1) ?>
                    </div>
                    <span><?= htmlspecialchars($student['name']) ?></span>
                </div>
                
                <a href="../logout.php" class="btn-logout">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </div>
    </nav>
    
    <div class="container">
        <!-- Profile Header -->
        <div class="profile-header">
            <div class="profile-avatar">
                <?= substr($student['name'], 0, 1) ?>
            </div>
            <div class="profile-info">
                <h1><?= htmlspecialchars($student['name']) ?></h1>
                <p><?= htmlspecialchars($student['course']) ?> at <?= htmlspecialchars($student['university']) ?></p>
                <div class="profile-meta">
                    <span><i class="fas fa-graduation-cap"></i> Year <?= $student['year'] ?></span>
                    <span><i class="fas fa-star"></i> CGPA: <?= $student['cgpa'] ?></span>
                    <span><i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($student['location']) ?></span>
                </div>
            </div>
        </div>
        
        <!-- Messages -->
        <?php if ($message): ?>
            <div class="alert alert-success"><?= $message ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php endif; ?>
        
        <!-- Edit Profile Form -->
        <div class="form-card">
            <h2>Edit Profile</h2>
            
            <form method="POST">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Full Name</label>
                            <input type="text" class="form-control" name="name" value="<?= htmlspecialchars($student['name']) ?>" required>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" class="form-control" value="<?= htmlspecialchars($student['email']) ?>" disabled>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Course</label>
                            <input type="text" class="form-control" name="course" value="<?= htmlspecialchars($student['course']) ?>" required>
                        </div>
                    </div>
                    
                    <div class="col-md-3">
                        <div class="form-group">
                            <label>Year</label>
                            <select class="form-control" name="year">
                                <?php for($i=1; $i<=4; $i++): ?>
                                <option value="<?= $i ?>" <?= $student['year'] == $i ? 'selected' : '' ?>>
                                    Year <?= $i ?>
                                </option>
                                <?php endfor; ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="col-md-3">
                        <div class="form-group">
                            <label>CGPA</label>
                            <input type="number" step="0.01" min="0" max="4" class="form-control" name="cgpa" value="<?= $student['cgpa'] ?>" required>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Location</label>
                            <input type="text" class="form-control" name="location" value="<?= htmlspecialchars($student['location']) ?>" required>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>University</label>
                            <input type="text" class="form-control" value="<?= htmlspecialchars($student['university']) ?>" disabled>
                        </div>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Skills (comma separated)</label>
                    <input type="text" class="form-control" name="skills" value="<?= htmlspecialchars($student['skills']) ?>" 
                           placeholder="e.g., Python, JavaScript, SQL, React">
                </div>
                
                <div class="form-group">
                    <label>Bio / About Me</label>
                    <textarea class="form-control" name="bio" rows="4" placeholder="Tell employers about yourself..."><?= htmlspecialchars($student['bio'] ?? '') ?></textarea>
                </div>
                
                <button type="submit" class="btn-primary">Save Changes</button>
                <a href="dashboard.php" class="btn-secondary">Cancel</a>
            </form>
        </div>
        
        <!-- Current Skills Display -->
        <div class="form-card">
            <h2>Your Skills</h2>
            <div class="skills-section">
                <?php 
                $skills = explode(',', $student['skills']);
                foreach($skills as $skill): 
                    if(trim($skill)):
                ?>
                    <span class="skill-tag"><?= trim($skill) ?></span>
                <?php 
                    endif;
                endforeach; 
                ?>
            </div>
        </div>
    </div>
    
    <footer class="footer">
        <div class="container">
            <p>&copy; 2026 SmartIntern Kenya - Student Portal</p>
        </div>
    </footer>
</body>
</html>