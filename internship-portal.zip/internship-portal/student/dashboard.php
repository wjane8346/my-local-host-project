<?php
require_once '../includes/db_connect.php';
require_once '../includes/auth.php';
requireStudent();

$student = getCurrentUser($conn);
$student_id = $student['id'];

// Get recent applications
$query = "SELECT a.*, j.title, j.company_id, j.location, j.salary, c.name as company_name 
          FROM applications a
          JOIN jobs j ON a.job_id = j.id
          JOIN companies c ON j.company_id = c.id
          WHERE a.student_id = ?
          ORDER BY a.applied_date DESC
          LIMIT 5";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $student_id);
$stmt->execute();
$applications = $stmt->get_result();

// Get application stats
$stats = [
    'total' => 0,
    'pending' => 0,
    'reviewing' => 0,
    'shortlisted' => 0,
    'interview' => 0,
    'rejected' => 0,
    'accepted' => 0
];

$query = "SELECT status, COUNT(*) as count FROM applications WHERE student_id = ? GROUP BY status";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $student_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $stats[$row['status']] = $row['count'];
    $stats['total'] += $row['count'];
}

// Get recommended jobs
$skills = explode(',', $student['skills']);
$skill_conditions = [];
foreach($skills as $skill) {
    $skill = trim($skill);
    if(!empty($skill)) {
        $skill_conditions[] = "requirements LIKE '%$skill%'";
    }
}
$skill_query = implode(' OR ', $skill_conditions);

if(!empty($skill_query)) {
    $query = "SELECT j.*, c.name as company_name 
              FROM jobs j
              JOIN companies c ON j.company_id = c.id
              WHERE $skill_query OR j.location = ?
              ORDER BY j.created_at DESC
              LIMIT 3";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $student['location']);
    $stmt->execute();
    $recommended = $stmt->get_result();
} else {
    $recommended = null;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard - SmartIntern Kenya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #0f172a;
            color: #e2e8f0;
            line-height: 1.6;
        }
        
        /* Kenyan Flag Header */
        .flag-header {
            height: 4px;
            background: linear-gradient(90deg, 
                #000000 0%, #000000 33.33%,
                #b91c1c 33.33%, #b91c1c 66.66%,
                #059669 66.66%, #059669 100%);
        }
        
        /* Navbar */
        .navbar {
            background: #1e293b;
            border-bottom: 1px solid #334155;
            padding: 1rem 0;
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        .navbar-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .navbar-brand {
            font-weight: 700;
            font-size: 1.3rem;
            color: #4ade80;
            text-decoration: none;
        }
        
        .navbar-brand i {
            color: #4ade80;
            margin-right: 8px;
        }
        
        .nav-links {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .nav-links a {
            color: #cbd5e1;
            text-decoration: none;
            transition: color 0.2s;
            padding: 5px 10px;
            border-radius: 6px;
        }
        
        .nav-links a:hover {
            color: #4ade80;
            background: #0f172a;
        }
        
        .nav-links a.active {
            color: #4ade80;
            background: #0f172a;
            border-left: 3px solid #4ade80;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
            color: #94a3b8;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #059669, #4ade80);
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.1rem;
        }
        
        .btn-logout {
            color: #ef4444;
            text-decoration: none;
            padding: 8px 15px;
            border-radius: 6px;
            border: 1px solid #ef4444;
            transition: all 0.2s;
        }
        
        .btn-logout:hover {
            background: #ef4444;
            color: white;
        }
        
        /* Welcome Section */
        .welcome-section {
            background: linear-gradient(135deg, #1e293b, #0f172a);
            border: 1px solid #334155;
            border-radius: 12px;
            padding: 30px;
            margin: 30px 0;
            display: flex;
            align-items: center;
            gap: 30px;
        }
        
        .welcome-avatar {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #059669, #4ade80);
            border-radius: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 2rem;
            font-weight: bold;
        }
        
        .welcome-text h1 {
            color: white;
            margin-bottom: 5px;
        }
        
        .welcome-text p {
            color: #94a3b8;
        }
        
        .welcome-stats {
            display: flex;
            gap: 30px;
            margin-left: auto;
        }
        
        .stat-item {
            text-align: center;
        }
        
        .stat-value {
            font-size: 1.5rem;
            font-weight: 700;
            color: #4ade80;
        }
        
        .stat-label {
            color: #94a3b8;
            font-size: 0.9rem;
        }
        
        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 10px;
            padding: 20px;
            display: flex;
            align-items: center;
            gap: 15px;
            transition: all 0.3s;
        }
        
        .stat-card:hover {
            border-color: #4ade80;
            transform: translateY(-2px);
        }
        
        .stat-icon {
            width: 50px;
            height: 50px;
            background: #0f172a;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #4ade80;
            font-size: 1.3rem;
        }
        
        .stat-info h3 {
            font-size: 1.8rem;
            color: white;
            margin-bottom: 2px;
        }
        
        .stat-info p {
            color: #94a3b8;
            margin: 0;
            font-size: 0.9rem;
        }
        
        /* Section Headers */
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 30px 0 20px;
        }
        
        .section-header h2 {
            color: white;
            font-size: 1.5rem;
        }
        
        .section-header a {
            color: #4ade80;
            text-decoration: none;
        }
        
        .section-header a:hover {
            text-decoration: underline;
        }
        
        /* Cards */
        .card {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
        }
        
        .application-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 0;
            border-bottom: 1px solid #334155;
        }
        
        .application-item:last-child {
            border-bottom: none;
        }
        
        .application-info h4 {
            color: white;
            margin-bottom: 5px;
        }
        
        .application-info p {
            color: #94a3b8;
            font-size: 0.9rem;
        }
        
        .application-meta {
            display: flex;
            gap: 15px;
            margin-top: 8px;
            color: #64748b;
            font-size: 0.85rem;
        }
        
        .application-meta i {
            color: #4ade80;
            margin-right: 5px;
        }
        
        .status-badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .status-pending { background: #fef3c7; color: #92400e; }
        .status-reviewing { background: #dbeafe; color: #1e40af; }
        .status-shortlisted { background: #d1fae5; color: #065f46; }
        .status-interview { background: #e0f2fe; color: #0369a1; }
        .status-rejected { background: #fee2e2; color: #b91c1c; }
        .status-accepted { background: #d1fae5; color: #059669; }
        
        .job-card {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 15px;
        }
        
        .job-card h4 {
            color: white;
            margin-bottom: 5px;
        }
        
        .job-company {
            color: #4ade80;
            font-size: 0.9rem;
            margin-bottom: 10px;
        }
        
        .job-details {
            display: flex;
            gap: 15px;
            color: #94a3b8;
            font-size: 0.85rem;
            margin-bottom: 10px;
        }
        
        .job-details i {
            color: #4ade80;
            margin-right: 5px;
        }
        
        .job-salary {
            color: #4ade80;
            font-weight: 600;
            margin-bottom: 10px;
        }
        
        .btn-job {
            color: #4ade80;
            text-decoration: none;
            font-size: 0.9rem;
            border: 1px solid #4ade80;
            padding: 5px 15px;
            border-radius: 6px;
            display: inline-block;
            transition: all 0.2s;
        }
        
        .btn-job:hover {
            background: #4ade80;
            color: #0f172a;
        }
        
        /* Skills Section */
        .skills-section {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 10px;
            padding: 20px;
            margin-top: 30px;
        }
        
        .skills-title {
            color: white;
            margin-bottom: 15px;
        }
        
        .skill-tag {
            background: #0f172a;
            color: #94a3b8;
            padding: 5px 15px;
            border-radius: 20px;
            display: inline-block;
            margin: 0 5px 5px 0;
            font-size: 0.9rem;
            border: 1px solid #334155;
        }
        
        .footer {
            background: #1e293b;
            border-top: 1px solid #334155;
            padding: 30px 0;
            margin-top: 50px;
            text-align: center;
            color: #64748b;
        }
        
        @media (max-width: 768px) {
            .stats-grid,
            .welcome-section {
                grid-template-columns: 1fr;
            }
            
            .navbar-content {
                flex-direction: column;
                gap: 15px;
            }
            
            .nav-links {
                flex-wrap: wrap;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <div class="flag-header"></div>
    
    <!-- Navbar -->
    <nav class="navbar">
        <div class="container navbar-content">
            <a href="../index.php" class="navbar-brand">
                <i class="fas fa-shield-alt"></i>SmartIntern Kenya
            </a>
            
            <div class="nav-links">
                <a href="dashboard.php" class="active">Dashboard</a>
                <a href="profile.php">Profile</a>
                <a href="applications.php">Applications</a>
                <a href="matches.php">Job Matches</a>
                
                <div class="user-info">
                    <div class="user-avatar">
                        <?= substr($student['name'], 0, 1) ?>
                    </div>
                    <span><?= htmlspecialchars($student['name']) ?></span>
                </div>
                
                <a href="../logout.php" class="btn-logout">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </div>
    </nav>
    
    <div class="container">
        <!-- Welcome Section -->
        <div class="welcome-section">
            <div class="welcome-avatar">
                <?= substr($student['name'], 0, 1) ?>
            </div>
            <div class="welcome-text">
                <h1>Welcome back, <?= htmlspecialchars($student['name']) ?>!</h1>
                <p><?= htmlspecialchars($student['course']) ?> • <?= htmlspecialchars($student['university']) ?> • Year <?= $student['year'] ?></p>
            </div>
            <div class="welcome-stats">
                <div class="stat-item">
                    <div class="stat-value"><?= $stats['total'] ?></div>
                    <div class="stat-label">Applications</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value"><?= $stats['shortlisted'] + $stats['interview'] ?></div>
                    <div class="stat-label">Shortlisted</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value"><?= $stats['interview'] ?></div>
                    <div class="stat-label">Interviews</div>
                </div>
            </div>
        </div>
        
        <!-- Stats Cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-file-alt"></i>
                </div>
                <div class="stat-info">
                    <h3><?= $stats['total'] ?></h3>
                    <p>Total Applications</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-clock"></i>
                </div>
                <div class="stat-info">
                    <h3><?= $stats['pending'] + $stats['reviewing'] ?></h3>
                    <p>In Review</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-check-circle"></i>
                </div>
                <div class="stat-info">
                    <h3><?= $stats['shortlisted'] + $stats['interview'] ?></h3>
                    <p>Shortlisted</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-calendar"></i>
                </div>
                <div class="stat-info">
                    <h3><?= $stats['interview'] ?></h3>
                    <p>Interviews</p>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-8">
                <!-- Recent Applications -->
                <div class="section-header">
                    <h2>Recent Applications</h2>
                    <a href="applications.php">View All →</a>
                </div>
                
                <div class="card">
                    <?php if ($applications && $applications->num_rows > 0): ?>
                        <?php while($app = $applications->fetch_assoc()): ?>
                            <div class="application-item">
                                <div class="application-info">
                                    <h4><?= htmlspecialchars($app['title']) ?></h4>
                                    <p><?= htmlspecialchars($app['company_name']) ?></p>
                                    <div class="application-meta">
                                        <span><i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($app['location']) ?></span>
                                        <span><i class="fas fa-money-bill"></i> KSh <?= number_format($app['salary']) ?></span>
                                        <span><i class="fas fa-calendar"></i> <?= date('M d', strtotime($app['applied_date'])) ?></span>
                                    </div>
                                </div>
                                <div>
                                    <?php
                                    $statusClass = '';
                                    switch($app['status']) {
                                        case 'pending': $statusClass = 'status-pending'; break;
                                        case 'reviewing': $statusClass = 'status-reviewing'; break;
                                        case 'shortlisted': $statusClass = 'status-shortlisted'; break;
                                        case 'interview': $statusClass = 'status-interview'; break;
                                        case 'rejected': $statusClass = 'status-rejected'; break;
                                        case 'accepted': $statusClass = 'status-accepted'; break;
                                    }
                                    ?>
                                    <span class="status-badge <?= $statusClass ?>">
                                        <?= ucfirst($app['status']) ?>
                                    </span>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <p style="color: #64748b; text-align: center; padding: 20px;">No applications yet. Start applying!</p>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="col-md-4">
                <!-- Recommended Jobs -->
                <div class="section-header">
                    <h2>Recommended</h2>
                    <a href="matches.php">View All →</a>
                </div>
                
                <?php if ($recommended && $recommended->num_rows > 0): ?>
                    <?php while($job = $recommended->fetch_assoc()): ?>
                        <div class="job-card">
                            <h4><?= htmlspecialchars($job['title']) ?></h4>
                            <div class="job-company">
                                <i class="fas fa-building"></i> <?= htmlspecialchars($job['company_name']) ?>
                            </div>
                            <div class="job-details">
                                <span><i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($job['location']) ?></span>
                                <span><i class="fas fa-clock"></i> <?= htmlspecialchars($job['duration']) ?></span>
                            </div>
                            <div class="job-salary">
                                KSh <?= number_format($job['salary']) ?>/month
                            </div>
                            <a href="../job-details.php?id=<?= $job['id'] ?>" class="btn-job">View Details</a>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="card">
                        <p style="color: #64748b; text-align: center;">Update your skills to get recommendations</p>
                    </div>
                <?php endif; ?>
                
                <!-- Skills Section -->
                <div class="skills-section">
                    <h3 class="skills-title">Your Skills</h3>
                    <div>
                        <?php 
                        $skills = explode(',', $student['skills']);
                        foreach($skills as $skill): 
                            if(trim($skill)):
                        ?>
                            <span class="skill-tag"><?= trim($skill) ?></span>
                        <?php 
                            endif;
                        endforeach; 
                        ?>
                    </div>
                    <a href="profile.php" style="color: #4ade80; text-decoration: none; display: block; margin-top: 15px;">Edit Skills →</a>
                </div>
            </div>
        </div>
    </div>
    
    <footer class="footer">
        <div class="container">
            <p>&copy; 2026 SmartIntern Kenya - Student Portal</p>
        </div>
    </footer>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>