<?php
require_once '../includes/db_connect.php';
require_once '../includes/auth.php';
requireStudent();

$student = getCurrentUser($conn);
$student_id = $student['id'];

// Get student's skills
$skills = explode(',', $student['skills']);
$skill_conditions = [];
foreach($skills as $skill) {
    $skill = trim($skill);
    if(!empty($skill)) {
        $skill_conditions[] = "j.requirements LIKE '%$skill%'";
    }
}
$skill_query = implode(' OR ', $skill_conditions);

// Find matching jobs based on skills and location
if(!empty($skill_query)) {
    $query = "SELECT j.*, c.name as company_name, c.industry,
                     (SELECT COUNT(*) FROM applications WHERE job_id = j.id) as applicant_count
              FROM jobs j
              JOIN companies c ON j.company_id = c.id
              WHERE ($skill_query) OR j.location = ?
              AND j.deadline > CURDATE()
              ORDER BY j.created_at DESC";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $student['location']);
    $stmt->execute();
    $matches = $stmt->get_result();
} else {
    // If no skills, show recent jobs
    $query = "SELECT j.*, c.name as company_name, c.industry,
                     (SELECT COUNT(*) FROM applications WHERE job_id = j.id) as applicant_count
              FROM jobs j
              JOIN companies c ON j.company_id = c.id
              WHERE j.deadline > CURDATE()
              ORDER BY j.created_at DESC
              LIMIT 10";
    $matches = $conn->query($query);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Job Matches - SmartIntern Kenya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #0f172a;
            color: #e2e8f0;
        }
        
        .flag-header {
            height: 4px;
            background: linear-gradient(90deg, 
                #000000 0%, #000000 33.33%,
                #b91c1c 33.33%, #b91c1c 66.66%,
                #059669 66.66%, #059669 100%);
        }
        
        .navbar {
            background: #1e293b;
            border-bottom: 1px solid #334155;
            padding: 1rem 0;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        .navbar-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .navbar-brand {
            font-weight: 700;
            font-size: 1.3rem;
            color: #4ade80;
            text-decoration: none;
        }
        
        .navbar-brand i {
            color: #4ade80;
        }
        
        .nav-links {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .nav-links a {
            color: #cbd5e1;
            text-decoration: none;
            padding: 5px 10px;
        }
        
        .nav-links a:hover {
            color: #4ade80;
        }
        
        .nav-links a.active {
            color: #4ade80;
            border-bottom: 2px solid #4ade80;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
            color: #94a3b8;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #059669, #4ade80);
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
        }
        
        .btn-logout {
            color: #ef4444;
            text-decoration: none;
            padding: 8px 15px;
            border: 1px solid #ef4444;
            border-radius: 6px;
        }
        
        .page-header {
            margin: 30px 0;
        }
        
        .page-header h1 {
            color: white;
            font-size: 2rem;
            margin-bottom: 10px;
        }
        
        .page-header p {
            color: #94a3b8;
        }
        
        .skills-panel {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 30px;
        }
        
        .skills-panel h3 {
            color: white;
            margin-bottom: 15px;
        }
        
        .skill-tag {
            background: #0f172a;
            color: #94a3b8;
            padding: 5px 15px;
            border-radius: 20px;
            display: inline-block;
            margin: 0 5px 5px 0;
            border: 1px solid #334155;
        }
        
        .matches-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .match-card {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 12px;
            padding: 25px;
            transition: all 0.3s;
        }
        
        .match-card:hover {
            border-color: #4ade80;
            transform: translateY(-5px);
        }
        
        .match-header {
            display: flex;
            justify-content: space-between;
            align-items: start;
            margin-bottom: 15px;
        }
        
        .match-header h3 {
            color: white;
            font-size: 1.2rem;
            margin: 0;
        }
        
        .match-score {
            background: #4ade80;
            color: #0f172a;
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .match-company {
            color: #4ade80;
            margin-bottom: 15px;
        }
        
        .match-details {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 15px;
            color: #94a3b8;
            font-size: 0.9rem;
        }
        
        .match-details i {
            color: #4ade80;
            margin-right: 5px;
        }
        
        .match-skills {
            margin: 15px 0;
        }
        
        .skill-req {
            background: #0f172a;
            color: #94a3b8;
            padding: 3px 10px;
            border-radius: 15px;
            font-size: 0.8rem;
            display: inline-block;
            margin: 0 5px 5px 0;
            border: 1px solid #334155;
        }
        
        .match-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 20px;
        }
        
        .applicant-count {
            color: #94a3b8;
            font-size: 0.9rem;
        }
        
        .btn-apply {
            background: #4ade80;
            color: #0f172a;
            padding: 8px 20px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.2s;
        }
        
        .btn-apply:hover {
            background: #22c55e;
        }
        
        .empty-state {
            grid-column: span 2;
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 12px;
            padding: 60px;
            text-align: center;
        }
        
        .footer {
            background: #1e293b;
            border-top: 1px solid #334155;
            padding: 30px 0;
            margin-top: 50px;
            text-align: center;
        }
        
        @media (max-width: 768px) {
            .matches-grid {
                grid-template-columns: 1fr;
            }
            
            .empty-state {
                grid-column: span 1;
            }
        }
    </style>
</head>
<body>
    <div class="flag-header"></div>
    
    <nav class="navbar">
        <div class="container navbar-content">
            <a href="../index.php" class="navbar-brand">
                <i class="fas fa-shield-alt"></i>SmartIntern Kenya
            </a>
            
            <div class="nav-links">
                <a href="dashboard.php">Dashboard</a>
                <a href="profile.php">Profile</a>
                <a href="applications.php">Applications</a>
                <a href="matches.php" class="active">Job Matches</a>
                <a href="settings.php">Settings</a>
                
                <div class="user-info">
                    <div class="user-avatar">
                        <?= substr($student['name'], 0, 1) ?>
                    </div>
                    <span><?= htmlspecialchars($student['name']) ?></span>
                </div>
                
                <a href="../logout.php" class="btn-logout">Logout</a>
            </div>
        </div>
    </nav>
    
    <div class="container">
        <div class="page-header">
            <h1>AI Job Matches</h1>
            <p>Based on your skills and preferences</p>
        </div>
        
        <!-- Skills Panel -->
        <div class="skills-panel">
            <h3>Your Skills</h3>
            <div>
                <?php 
                foreach($skills as $skill): 
                    if(trim($skill)):
                ?>
                    <span class="skill-tag"><?= trim($skill) ?></span>
                <?php 
                    endif;
                endforeach; 
                ?>
            </div>
        </div>
        
        <!-- Matches Grid -->
        <div class="matches-grid">
            <?php if ($matches && $matches->num_rows > 0): ?>
                <?php while($job = $matches->fetch_assoc()): 
                    // Calculate match percentage
                    $job_skills = explode(',', $job['requirements']);
                    $student_skills = explode(',', $student['skills']);
                    $matches_count = 0;
                    
                    foreach($job_skills as $js) {
                        foreach($student_skills as $ss) {
                            if(stripos(trim($js), trim($ss)) !== false) {
                                $matches_count++;
                                break;
                            }
                        }
                    }
                    
                    $total_skills = count($job_skills);
                    $match_percent = $total_skills > 0 ? round(($matches_count / $total_skills) * 100) : 50;
                ?>
                    <div class="match-card">
                        <div class="match-header">
                            <h3><?= htmlspecialchars($job['title']) ?></h3>
                            <span class="match-score"><?= $match_percent ?>% Match</span>
                        </div>
                        
                        <div class="match-company">
                            <i class="fas fa-building"></i> <?= htmlspecialchars($job['company_name']) ?>
                        </div>
                        
                        <div class="match-details">
                            <span><i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($job['location']) ?></span>
                            <span><i class="fas fa-clock"></i> <?= htmlspecialchars($job['duration']) ?></span>
                            <span><i class="fas fa-money-bill"></i> KSh <?= number_format($job['salary']) ?>/mo</span>
                        </div>
                        
                        <div class="match-skills">
                            <?php 
                            $req_skills = explode(',', $job['requirements']);
                            foreach($req_skills as $skill): 
                                if(trim($skill)):
                            ?>
                                <span class="skill-req"><?= trim($skill) ?></span>
                            <?php 
                                endif;
                            endforeach; 
                            ?>
                        </div>
                        
                        <div class="match-footer">
                            <span class="applicant-count">
                                <i class="fas fa-users"></i> <?= $job['applicant_count'] ?> applicants
                            </span>
                            <a href="job-details.php?id=<?= $job['id'] ?>" class="btn-apply">Apply Now</a>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="empty-state">
                    <i class="fas fa-search fa-4x" style="color: #334155; margin-bottom: 20px;"></i>
                    <h3>No Matches Found</h3>
                    <p>Try updating your skills to get better matches</p>
                    <a href="profile.php" class="btn-apply" style="display: inline-block; margin-top: 15px;">Update Profile</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <footer class="footer">
        <div class="container">
            <p>&copy; 2026 SmartIntern Kenya</p>
        </div>
    </footer>
</body>
</html>