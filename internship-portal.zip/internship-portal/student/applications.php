<?php
require_once '../includes/db_connect.php';
require_once '../includes/auth.php';
requireStudent();

$student = getCurrentUser($conn);
$student_id = $student['id'];

// Get all applications
$query = "SELECT a.*, j.title, j.location, j.salary, j.duration, j.deadline,
                 c.name as company_name, c.industry
          FROM applications a
          JOIN jobs j ON a.job_id = j.id
          JOIN companies c ON j.company_id = c.id
          WHERE a.student_id = ?
          ORDER BY a.applied_date DESC";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $student_id);
$stmt->execute();
$applications = $stmt->get_result();

// Get status counts
$stats = [
    'pending' => 0,
    'reviewing' => 0,
    'shortlisted' => 0,
    'interview' => 0,
    'rejected' => 0,
    'accepted' => 0
];

$query = "SELECT status, COUNT(*) as count FROM applications WHERE student_id = ? GROUP BY status";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $student_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $stats[$row['status']] = $row['count'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Applications - SmartIntern Kenya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #0f172a;
            color: #e2e8f0;
        }
        
        .flag-header {
            height: 4px;
            background: linear-gradient(90deg, 
                #000000 0%, #000000 33.33%,
                #b91c1c 33.33%, #b91c1c 66.66%,
                #059669 66.66%, #059669 100%);
        }
        
        .navbar {
            background: #1e293b;
            border-bottom: 1px solid #334155;
            padding: 1rem 0;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        .navbar-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .navbar-brand {
            font-weight: 700;
            font-size: 1.3rem;
            color: #4ade80;
            text-decoration: none;
        }
        
        .navbar-brand i {
            color: #4ade80;
        }
        
        .nav-links {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .nav-links a {
            color: #cbd5e1;
            text-decoration: none;
            padding: 5px 10px;
        }
        
        .nav-links a:hover {
            color: #4ade80;
        }
        
        .nav-links a.active {
            color: #4ade80;
            border-bottom: 2px solid #4ade80;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
            color: #94a3b8;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #059669, #4ade80);
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
        }
        
        .btn-logout {
            color: #ef4444;
            text-decoration: none;
            padding: 8px 15px;
            border: 1px solid #ef4444;
            border-radius: 6px;
        }
        
        .page-title {
            margin: 30px 0;
        }
        
        .page-title h1 {
            color: white;
            font-size: 2rem;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(6, 1fr);
            gap: 15px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 8px;
            padding: 15px;
            text-align: center;
        }
        
        .stat-number {
            font-size: 1.5rem;
            font-weight: 700;
            color: #4ade80;
        }
        
        .stat-label {
            color: #94a3b8;
            font-size: 0.8rem;
        }
        
        .applications-list {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 12px;
            overflow: hidden;
            margin-bottom: 30px;
        }
        
        .application-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            border-bottom: 1px solid #334155;
        }
        
        .application-item:last-child {
            border-bottom: none;
        }
        
        .application-item:hover {
            background: #0f172a;
        }
        
        .application-info h3 {
            color: white;
            margin-bottom: 8px;
        }
        
        .application-company {
            color: #4ade80;
            margin-bottom: 8px;
        }
        
        .application-meta {
            display: flex;
            gap: 20px;
            color: #94a3b8;
            font-size: 0.9rem;
        }
        
        .application-meta i {
            color: #4ade80;
            margin-right: 5px;
        }
        
        .application-right {
            text-align: right;
        }
        
        .application-date {
            color: #94a3b8;
            font-size: 0.9rem;
            margin-bottom: 10px;
        }
        
        .status-badge {
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
            display: inline-block;
        }
        
        .status-pending { background: #fef3c7; color: #92400e; }
        .status-reviewing { background: #dbeafe; color: #1e40af; }
        .status-shortlisted { background: #d1fae5; color: #065f46; }
        .status-interview { background: #e0f2fe; color: #0369a1; }
        .status-rejected { background: #fee2e2; color: #b91c1c; }
        .status-accepted { background: #d1fae5; color: #059669; }
        
        .btn-view {
            color: #4ade80;
            text-decoration: none;
            margin-top: 10px;
            display: inline-block;
        }
        
        .empty-state {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 12px;
            padding: 60px;
            text-align: center;
        }
        
        .empty-state i {
            font-size: 4rem;
            color: #334155;
            margin-bottom: 20px;
        }
        
        .empty-state h3 {
            color: white;
            margin-bottom: 10px;
        }
        
        .empty-state p {
            color: #94a3b8;
            margin-bottom: 20px;
        }
        
        .btn-browse {
            background: #4ade80;
            color: #0f172a;
            padding: 12px 30px;
            border-radius: 8px;
            text-decoration: none;
            display: inline-block;
            font-weight: 600;
        }
        
        .footer {
            background: #1e293b;
            border-top: 1px solid #334155;
            padding: 30px 0;
            margin-top: 50px;
            text-align: center;
        }
        
        @media (max-width: 768px) {
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .application-item {
                flex-direction: column;
                text-align: center;
                gap: 15px;
            }
            
            .application-meta {
                flex-wrap: wrap;
                justify-content: center;
            }
            
            .application-right {
                text-align: center;
            }
        }
    </style>
</head>
<body>
    <div class="flag-header"></div>
    
    <nav class="navbar">
        <div class="container navbar-content">
            <a href="../index.php" class="navbar-brand">
                <i class="fas fa-shield-alt"></i>SmartIntern Kenya
            </a>
            
            <div class="nav-links">
                <a href="dashboard.php">Dashboard</a>
                <a href="profile.php">Profile</a>
                <a href="applications.php" class="active">Applications</a>
                <a href="matches.php">Job Matches</a>
                <a href="settings.php">Settings</a>
                
                <div class="user-info">
                    <div class="user-avatar">
                        <?= substr($student['name'], 0, 1) ?>
                    </div>
                    <span><?= htmlspecialchars($student['name']) ?></span>
                </div>
                
                <a href="../logout.php" class="btn-logout">Logout</a>
            </div>
        </div>
    </nav>
    
    <div class="container">
        <div class="page-title">
            <h1>My Applications</h1>
        </div>
        
        <!-- Stats Cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-number"><?= $applications->num_rows ?></div>
                <div class="stat-label">Total</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?= $stats['pending'] ?></div>
                <div class="stat-label">Pending</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?= $stats['reviewing'] ?></div>
                <div class="stat-label">Reviewing</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?= $stats['shortlisted'] ?></div>
                <div class="stat-label">Shortlisted</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?= $stats['interview'] ?></div>
                <div class="stat-label">Interviews</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?= $stats['rejected'] ?></div>
                <div class="stat-label">Rejected</div>
            </div>
        </div>
        
        <!-- Applications List -->
        <?php if ($applications && $applications->num_rows > 0): ?>
            <div class="applications-list">
                <?php while($app = $applications->fetch_assoc()): ?>
                    <div class="application-item">
                        <div class="application-info">
                            <h3><?= htmlspecialchars($app['title']) ?></h3>
                            <div class="application-company">
                                <i class="fas fa-building"></i> <?= htmlspecialchars($app['company_name']) ?>
                            </div>
                            <div class="application-meta">
                                <span><i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($app['location']) ?></span>
                                <span><i class="fas fa-money-bill"></i> KSh <?= number_format($app['salary']) ?></span>
                                <span><i class="fas fa-clock"></i> <?= htmlspecialchars($app['duration']) ?></span>
                            </div>
                        </div>
                        
                        <div class="application-right">
                            <div class="application-date">
                                <i class="fas fa-calendar"></i> Applied: <?= date('M d, Y', strtotime($app['applied_date'])) ?>
                            </div>
                            
                            <?php
                            $statusClass = '';
                            switch($app['status']) {
                                case 'pending': $statusClass = 'status-pending'; break;
                                case 'reviewing': $statusClass = 'status-reviewing'; break;
                                case 'shortlisted': $statusClass = 'status-shortlisted'; break;
                                case 'interview': $statusClass = 'status-interview'; break;
                                case 'rejected': $statusClass = 'status-rejected'; break;
                                case 'accepted': $statusClass = 'status-accepted'; break;
                            }
                            ?>
                            <span class="status-badge <?= $statusClass ?>">
                                <?= ucfirst($app['status']) ?>
                            </span>
                            
                            <a href="job-details.php?id=<?= $app['job_id'] ?>" class="btn-view">
                                <i class="fas fa-eye"></i> View Details
                            </a>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <i class="fas fa-file-alt"></i>
                <h3>No Applications Yet</h3>
                <p>Start applying to internships to track your applications here</p>
                <a href="../internships.php" class="btn-browse">
                    <i class="fas fa-search me-2"></i>Browse Internships
                </a>
            </div>
        <?php endif; ?>
    </div>
    
    <footer class="footer">
        <div class="container">
            <p>&copy; 2026 SmartIntern Kenya</p>
        </div>
    </footer>
</body>
</html>