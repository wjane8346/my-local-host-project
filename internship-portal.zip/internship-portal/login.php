<?php
require_once 'includes/db_connect.php';

$error = '';

// Handle login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $user_type = $_POST['user_type'] ?? 'student';
    
    if (empty($email) || empty($password)) {
        $error = 'Please enter email and password';
    } else {
        // Determine table based on user type
        $table = $user_type === 'student' ? 'students' : ($user_type === 'company' ? 'companies' : 'institutions');
        
        $query = "SELECT * FROM $table WHERE email = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                // Set session
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_type'] = $user_type;
                $_SESSION['user_name'] = $user['name'];
                
                // Redirect to appropriate dashboard
                $redirect = $user_type === 'student' ? 'student/dashboard.php' : 
                           ($user_type === 'company' ? 'company/dashboard.php' : 'institution/dashboard.php');
                header("Location: $redirect");
                exit();
            } else {
                $error = 'Invalid password';
            }
        } else {
            $error = 'User not found';
        }
    }
}

// Check if user type is preselected from URL
$preselected_type = isset($_GET['type']) ? $_GET['type'] : 'student';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - SmartIntern Kenya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #0f172a;
            color: #e2e8f0;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        /* Kenyan Flag Header */
        .flag-header {
            height: 4px;
            background: linear-gradient(90deg, 
                #000000 0%, #000000 33.33%,
                #b91c1c 33.33%, #b91c1c 66.66%,
                #059669 66.66%, #059669 100%);
        }
        
        /* Navbar */
        .navbar {
            background: #1e293b;
            border-bottom: 1px solid #334155;
            padding: 1rem 0;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        .navbar-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .navbar-brand {
            font-weight: 700;
            font-size: 1.5rem;
            color: #4ade80;
            text-decoration: none;
        }
        
        .navbar-brand i {
            color: #4ade80;
            margin-right: 8px;
        }
        
        .btn-home {
            border: 1px solid #4ade80;
            color: #4ade80;
            padding: 8px 20px;
            border-radius: 6px;
            text-decoration: none;
            transition: all 0.2s;
        }
        
        .btn-home:hover {
            background: #4ade80;
            color: #0f172a;
        }
        
        /* Login Container */
        .login-container {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 40px 20px;
        }
        
        .login-card {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 16px;
            padding: 40px;
            width: 100%;
            max-width: 450px;
            box-shadow: 0 20px 30px rgba(0, 0, 0, 0.3);
        }
        
        .login-header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .login-header i {
            font-size: 3rem;
            color: #4ade80;
            margin-bottom: 15px;
        }
        
        .login-header h2 {
            color: white;
            font-size: 2rem;
            margin-bottom: 5px;
        }
        
        .login-header p {
            color: #94a3b8;
        }
        
        /* User Type Selector */
        .user-type-selector {
            display: flex;
            gap: 15px;
            margin-bottom: 25px;
            justify-content: center;
        }
        
        .type-option {
            flex: 1;
            text-align: center;
        }
        
        .type-option input[type="radio"] {
            display: none;
        }
        
        .type-option label {
            display: block;
            padding: 12px;
            background: #0f172a;
            border: 1px solid #334155;
            border-radius: 8px;
            color: #94a3b8;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .type-option input[type="radio"]:checked + label {
            background: #4ade80;
            color: #0f172a;
            border-color: #4ade80;
        }
        
        .type-option label i {
            display: block;
            font-size: 1.5rem;
            margin-bottom: 5px;
        }
        
        /* Form */
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #cbd5e1;
            font-weight: 500;
        }
        
        .form-control {
            width: 100%;
            padding: 12px 15px;
            background: #0f172a;
            border: 1px solid #334155;
            border-radius: 8px;
            color: white;
            font-size: 1rem;
            transition: all 0.2s;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #4ade80;
            box-shadow: 0 0 0 3px rgba(74, 222, 128, 0.2);
        }
        
        .form-control::placeholder {
            color: #64748b;
        }
        
        /* Options */
        .form-options {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }
        
        .remember-me {
            display: flex;
            align-items: center;
            gap: 8px;
            color: #94a3b8;
        }
        
        .remember-me input[type="checkbox"] {
            width: 16px;
            height: 16px;
            accent-color: #4ade80;
        }
        
        .forgot-password {
            color: #4ade80;
            text-decoration: none;
        }
        
        .forgot-password:hover {
            text-decoration: underline;
        }
        
        /* Buttons */
        .btn-login {
            width: 100%;
            padding: 14px;
            background: #4ade80;
            color: #0f172a;
            border: none;
            border-radius: 8px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            margin-bottom: 20px;
        }
        
        .btn-login:hover {
            background: #22c55e;
            transform: translateY(-2px);
        }
        
        /* Register Link */
        .register-link {
            text-align: center;
            color: #94a3b8;
        }
        
        .register-link a {
            color: #4ade80;
            text-decoration: none;
            font-weight: 600;
        }
        
        .register-link a:hover {
            text-decoration: underline;
        }
        
        /* Divider */
        .divider {
            position: relative;
            text-align: center;
            margin: 25px 0;
        }
        
        .divider::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 0;
            right: 0;
            height: 1px;
            background: #334155;
        }
        
        .divider span {
            position: relative;
            background: #1e293b;
            padding: 0 15px;
            color: #94a3b8;
            font-size: 0.9rem;
        }
        
        /* Demo Accounts */
        .demo-accounts {
            background: #0f172a;
            border: 1px solid #334155;
            border-radius: 8px;
            padding: 15px;
            margin-top: 20px;
        }
        
        .demo-accounts h4 {
            color: white;
            margin-bottom: 10px;
            font-size: 1rem;
        }
        
        .demo-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 8px;
            border-bottom: 1px solid #334155;
            font-size: 0.9rem;
        }
        
        .demo-item:last-child {
            border-bottom: none;
        }
        
        .demo-type {
            background: #4ade80;
            color: #0f172a;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 0.8rem;
            font-weight: 600;
            min-width: 70px;
            text-align: center;
        }
        
        .demo-email {
            color: #94a3b8;
            flex: 1;
        }
        
        .demo-password {
            color: #4ade80;
            font-family: monospace;
        }
        
        /* Alert */
        .alert {
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 0.95rem;
        }
        
        .alert-danger {
            background: #fee2e2;
            color: #b91c1c;
            border: 1px solid #fecaca;
        }
        
        /* Footer */
        .footer {
            background: #1e293b;
            border-top: 1px solid #334155;
            padding: 20px 0;
            text-align: center;
            color: #64748b;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .login-card {
                padding: 30px 20px;
            }
            
            .user-type-selector {
                flex-direction: column;
                gap: 10px;
            }
            
            .demo-item {
                flex-direction: column;
                align-items: flex-start;
                gap: 5px;
            }
        }
    </style>
</head>
<body>
    <div class="flag-header"></div>
    
    <!-- Navbar with Home Link -->
    <nav class="navbar">
        <div class="container navbar-content">
            <a href="index.php" class="navbar-brand">
                <i class="fas fa-shield-alt"></i>SmartIntern Kenya
            </a>
            
            <a href="index.php" class="btn-home">
                <i class="fas fa-home me-2"></i>Back to Home
            </a>
        </div>
    </nav>
    
    <!-- Login Container -->
    <div class="login-container">
        <div class="login-card">
            <div class="login-header">
                <i class="fas fa-shield-alt"></i>
                <h2>Welcome Back</h2>
                <p>Sign in to your account</p>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle me-2"></i><?= $error ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <!-- User Type Selection -->
                <div class="user-type-selector">
                    <div class="type-option">
                        <input type="radio" name="user_type" value="student" id="student" <?= $preselected_type == 'student' ? 'checked' : '' ?>>
                        <label for="student">
                            <i class="fas fa-user-graduate"></i>
                            <span>Student</span>
                        </label>
                    </div>
                    
                    <div class="type-option">
                        <input type="radio" name="user_type" value="company" id="company" <?= $preselected_type == 'company' ? 'checked' : '' ?>>
                        <label for="company">
                            <i class="fas fa-building"></i>
                            <span>Company</span>
                        </label>
                    </div>
                    
                    <div class="type-option">
                        <input type="radio" name="user_type" value="institution" id="institution" <?= $preselected_type == 'institution' ? 'checked' : '' ?>>
                        <label for="institution">
                            <i class="fas fa-university"></i>
                            <span>Institution</span>
                        </label>
                    </div>
                </div>
                
                <!-- Email -->
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" class="form-control" id="email" name="email" 
                           placeholder="Enter your email" 
                           value="<?= $preselected_type == 'student' ? 'wendy.jane@students.uonbi.ac.ke' : ($preselected_type == 'company' ? 'hr@safaricom.co.ke' : 'careers@uonbi.ac.ke') ?>"
                           required>
                </div>
                
                <!-- Password -->
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" class="form-control" id="password" name="password" 
                           placeholder="Enter your password" value="password123" required>
                </div>
                
                <!-- Options -->
                <div class="form-options">
                    <label class="remember-me">
                        <input type="checkbox" name="remember"> 
                        <span>Remember me</span>
                    </label>
                    <a href="#" class="forgot-password">Forgot Password?</a>
                </div>
                
                <!-- Login Button -->
                <button type="submit" class="btn-login">
                    <i class="fas fa-sign-in-alt me-2"></i>Sign In
                </button>
                
                <!-- Register Link -->
                <div class="register-link">
                    Don't have an account? <a href="register.php">Create Account</a>
                </div>
                
                <div class="divider">
                    <span>Demo Accounts</span>
                </div>
                
                <!-- Demo Accounts -->
                <div class="demo-accounts">
                    <div class="demo-item">
                        <span class="demo-type">Student</span>
                        <span class="demo-email">wendy.jane@students.uonbi.ac.ke</span>
                        <span class="demo-password">password123</span>
                    </div>
                    <div class="demo-item">
                        <span class="demo-type">Company</span>
                        <span class="demo-email">hr@safaricom.co.ke</span>
                        <span class="demo-password">password123</span>
                    </div>
                    <div class="demo-item">
                        <span class="demo-type">Institution</span>
                        <span class="demo-email">careers@uonbi.ac.ke</span>
                        <span class="demo-password">password123</span>
                    </div>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <p>&copy; 2026 SmartIntern Kenya. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>