<?php
require_once '../includes/db_connect.php';

echo "<h1 style='color: #059669;'>📊 Seeding Real Data</h1>";

// Clear existing data (safe order with foreign keys)
$conn->query("SET FOREIGN_KEY_CHECKS = 0");
$conn->query("TRUNCATE TABLE applications");
$conn->query("TRUNCATE TABLE matches");
$conn->query("TRUNCATE TABLE jobs");
$conn->query("TRUNCATE TABLE students");
$conn->query("TRUNCATE TABLE companies");
$conn->query("TRUNCATE TABLE institutions");
$conn->query("SET FOREIGN_KEY_CHECKS = 1");

echo "<p>✅ Old data cleared</p>";

// ============================================
// 1. ADD INSTITUTIONS
// ============================================
$institutions = [
    [
        'name' => 'University of Nairobi',
        'email' => 'careers@uonbi.ac.ke',
        'password' => password_hash('password123', PASSWORD_DEFAULT),
        'location' => 'Nairobi',
        'established' => '1970',
        'students_count' => 3500,
        'code' => 'UON'
    ],
    [
        'name' => 'Jomo Kenyatta University of Agriculture and Technology',
        'email' => 'careers@jkuat.ac.ke',
        'password' => password_hash('password123', PASSWORD_DEFAULT),
        'location' => 'Kiambu',
        'established' => '1981',
        'students_count' => 2800,
        'code' => 'JKUAT'
    ],
    [
        'name' => 'Strathmore University',
        'email' => 'careers@strathmore.edu',
        'password' => password_hash('password123', PASSWORD_DEFAULT),
        'location' => 'Nairobi',
        'established' => '1961',
        'students_count' => 1800,
        'code' => 'STRATH'
    ]
];

foreach ($institutions as $inst) {
    $query = "INSERT INTO institutions (name, email, password, location, established, students_count, code) 
              VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sssssis", $inst['name'], $inst['email'], $inst['password'], 
                     $inst['location'], $inst['established'], $inst['students_count'], $inst['code']);
    if ($stmt->execute()) {
        echo "<p>✅ Added institution: {$inst['name']}</p>";
    } else {
        echo "<p style='color:red;'>❌ Error: " . $stmt->error . "</p>";
    }
}

// ============================================
// 2. ADD COMPANIES
// ============================================
$companies = [
    [
        'name' => 'Safaricom PLC',
        'email' => 'hr@safaricom.co.ke',
        'password' => password_hash('password123', PASSWORD_DEFAULT),
        'industry' => 'Telecommunications',
        'location' => 'Nairobi',
        'size' => '5000+',
        'website' => 'www.safaricom.co.ke',
        'description' => 'Leading telecommunications company in Kenya.'
    ],
    [
        'name' => 'KCB Bank Kenya',
        'email' => 'careers@kcb.co.ke',
        'password' => password_hash('password123', PASSWORD_DEFAULT),
        'industry' => 'Banking',
        'location' => 'Nairobi',
        'size' => '3000+',
        'website' => 'www.kcbgroup.com',
        'description' => 'One of the largest banks in East Africa.'
    ],
    [
        'name' => 'Kenya Airways',
        'email' => 'hr@kenya-airways.com',
        'password' => password_hash('password123', PASSWORD_DEFAULT),
        'industry' => 'Aviation',
        'location' => 'Nairobi',
        'size' => '2000+',
        'website' => 'www.kenya-airways.com',
        'description' => 'National carrier of Kenya.'
    ]
];

foreach ($companies as $comp) {
    $query = "INSERT INTO companies (name, email, password, industry, location, size, website, description) 
              VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ssssssss", $comp['name'], $comp['email'], $comp['password'], 
                     $comp['industry'], $comp['location'], $comp['size'], 
                     $comp['website'], $comp['description']);
    if ($stmt->execute()) {
        echo "<p>✅ Added company: {$comp['name']}</p>";
    } else {
        echo "<p style='color:red;'>❌ Error: " . $stmt->error . "</p>";
    }
}

// ============================================
// 3. ADD STUDENTS
// ============================================
$students = [
    [
        'name' => 'Wendy Jane',
        'email' => 'wendy.jane@students.uonbi.ac.ke',
        'password' => password_hash('password123', PASSWORD_DEFAULT),
        'university' => 'University of Nairobi',
        'course' => 'Computer Science',
        'year' => 3,
        'cgpa' => 3.8,
        'skills' => 'Python, JavaScript, React, SQL, Django',
        'location' => 'Nairobi',
        'bio' => 'Passionate about web development.'
    ],
    [
        'name' => 'Brian Otieno',
        'email' => 'brian.otieno@students.uonbi.ac.ke',
        'password' => password_hash('password123', PASSWORD_DEFAULT),
        'university' => 'University of Nairobi',
        'course' => 'Electrical Engineering',
        'year' => 4,
        'cgpa' => 3.6,
        'skills' => 'Circuit Design, MATLAB, C++, Python',
        'location' => 'Nairobi',
        'bio' => 'Electronics enthusiast.'
    ],
    [
        'name' => 'James Mwangi',
        'email' => 'james.mwangi@students.jkuat.ac.ke',
        'password' => password_hash('password123', PASSWORD_DEFAULT),
        'university' => 'Jomo Kenyatta University of Agriculture and Technology',
        'course' => 'Software Engineering',
        'year' => 4,
        'cgpa' => 3.6,
        'skills' => 'Java, Spring Boot, MySQL, AWS, JavaScript',
        'location' => 'Kiambu',
        'bio' => 'Backend developer.'
    ],
    [
        'name' => 'Alice Kariuki',
        'email' => 'alice.kariuki@strathmore.edu',
        'password' => password_hash('password123', PASSWORD_DEFAULT),
        'university' => 'Strathmore University',
        'course' => 'Data Science',
        'year' => 4,
        'cgpa' => 3.9,
        'skills' => 'Python, Pandas, TensorFlow, SQL, Tableau',
        'location' => 'Nairobi',
        'bio' => 'Data scientist.'
    ]
];

foreach ($students as $student) {
    $query = "INSERT INTO students (name, email, password, university, course, year, cgpa, skills, location, bio) 
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sssssiisss", $student['name'], $student['email'], $student['password'],
                     $student['university'], $student['course'], $student['year'],
                     $student['cgpa'], $student['skills'], $student['location'], $student['bio']);
    if ($stmt->execute()) {
        echo "<p>✅ Added student: {$student['name']}</p>";
    } else {
        echo "<p style='color:red;'>❌ Error: " . $stmt->error . "</p>";
    }
}

// ============================================
// 4. ADD JOBS
// ============================================
$jobs = [
    [
        'company_id' => 1,
        'title' => 'Software Developer Intern',
        'description' => 'Join Safaricom\'s digital team.',
        'requirements' => 'Python, JavaScript, SQL, React',
        'location' => 'Nairobi',
        'salary' => 45000,
        'duration' => '3 months',
        'deadline' => '2026-05-30'
    ],
    [
        'company_id' => 1,
        'title' => 'Network Engineer Intern',
        'description' => 'Work with network infrastructure.',
        'requirements' => 'CCNA, Networking, TCP/IP, Linux',
        'location' => 'Nairobi',
        'salary' => 40000,
        'duration' => '4 months',
        'deadline' => '2026-06-15'
    ],
    [
        'company_id' => 2,
        'title' => 'Banking Intern',
        'description' => 'Learn banking operations.',
        'requirements' => 'Excel, Communication, Accounting',
        'location' => 'Nairobi',
        'salary' => 35000,
        'duration' => '6 months',
        'deadline' => '2026-06-01'
    ],
    [
        'company_id' => 3,
        'title' => 'Aviation Intern',
        'description' => 'Learn airline operations.',
        'requirements' => 'Communication, Customer Service',
        'location' => 'Nairobi',
        'salary' => 32000,
        'duration' => '4 months',
        'deadline' => '2026-06-10'
    ]
];

foreach ($jobs as $job) {
    $query = "INSERT INTO jobs (company_id, title, description, requirements, location, salary, duration, deadline) 
              VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("isssssds", $job['company_id'], $job['title'], $job['description'],
                     $job['requirements'], $job['location'], $job['salary'], 
                     $job['duration'], $job['deadline']);
    if ($stmt->execute()) {
        echo "<p>✅ Added job: {$job['title']}</p>";
    } else {
        echo "<p style='color:red;'>❌ Error: " . $stmt->error . "</p>";
    }
}

// ============================================
// 5. ADD APPLICATIONS
// ============================================
$applications = [
    [1, 1, '2026-02-15', 'pending'],
    [1, 2, '2026-02-16', 'reviewing'],
    [3, 1, '2026-02-14', 'interview'],
    [4, 2, '2026-02-13', 'shortlisted'],
    [2, 3, '2026-02-12', 'pending']
];

foreach ($applications as $app) {
    $query = "INSERT INTO applications (student_id, job_id, applied_date, status) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("iiss", $app[0], $app[1], $app[2], $app[3]);
    if ($stmt->execute()) {
        echo "<p>✅ Added application</p>";
    }
}

echo "<h2 style='color: #059669; margin-top: 20px;'>✅ Data seeding complete!</h2>";
echo "<p><a href='/internship-portal/login.php' style='color: #059669;'>Go to Login Page →</a></p>";
?>