<?php
// Turn on error reporting for debugging (remove this in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
$host = 'localhost';
$user = 'root';
$pass = '';
$db = 'internship_portal';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Get current user if logged in
$currentUser = null;
if (isset($_SESSION['user_id']) && isset($_SESSION['user_type'])) {
    $type = $_SESSION['user_type'];
    $id = $_SESSION['user_id'];
    
    if ($type == 'student') {
        $result = $conn->query("SELECT * FROM students WHERE id = $id");
    } elseif ($type == 'company') {
        $result = $conn->query("SELECT * FROM companies WHERE id = $id");
    } else {
        $result = $conn->query("SELECT * FROM institutions WHERE id = $id");
    }
    
    if ($result && $result->num_rows > 0) {
        $currentUser = $result->fetch_assoc();
    }
}

// Get all active jobs
$jobs = $conn->query("
    SELECT j.*, c.name as company_name, c.industry 
    FROM jobs j 
    JOIN companies c ON j.company_id = c.id 
    WHERE j.deadline > CURDATE() 
    ORDER BY j.created_at DESC
");

// Get unique locations for filter
$locations = $conn->query("SELECT DISTINCT location FROM jobs ORDER BY location");

// Get unique industries for filter
$industries = $conn->query("SELECT DISTINCT industry FROM companies ORDER BY industry");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Internships - SmartIntern Kenya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #0f172a;
            color: #e2e8f0;
        }
        
        .flag-header {
            height: 4px;
            background: linear-gradient(90deg, 
                #000000 0%, #000000 33.33%,
                #b91c1c 33.33%, #b91c1c 66.66%,
                #059669 66.66%, #059669 100%);
        }
        
        .navbar {
            background: #1e293b;
            border-bottom: 1px solid #334155;
            padding: 1rem 0;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        .navbar-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .navbar-brand {
            font-weight: 700;
            font-size: 1.3rem;
            color: #4ade80;
            text-decoration: none;
        }
        
        .navbar-brand i {
            color: #4ade80;
            margin-right: 8px;
        }
        
        .nav-links {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .nav-links a {
            color: #cbd5e1;
            text-decoration: none;
            transition: color 0.2s;
        }
        
        .nav-links a:hover {
            color: #4ade80;
        }
        
        .page-header {
            text-align: center;
            margin: 40px 0;
        }
        
        .page-header h1 {
            color: white;
            font-size: 2.5rem;
            margin-bottom: 10px;
        }
        
        .page-header p {
            color: #94a3b8;
            font-size: 1.1rem;
        }
        
        .filter-section {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 30px;
        }
        
        .filter-form {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
        }
        
        .filter-group {
            flex: 1;
            min-width: 200px;
        }
        
        .filter-group label {
            display: block;
            margin-bottom: 5px;
            color: #94a3b8;
            font-size: 0.9rem;
        }
        
        .filter-control {
            width: 100%;
            padding: 8px 12px;
            background: #0f172a;
            border: 1px solid #334155;
            border-radius: 6px;
            color: white;
        }
        
        .filter-control:focus {
            outline: none;
            border-color: #4ade80;
        }
        
        .btn-filter {
            background: #4ade80;
            color: #0f172a;
            border: none;
            padding: 8px 25px;
            border-radius: 6px;
            font-weight: 600;
            cursor: pointer;
            height: 38px;
            margin-top: 22px;
        }
        
        .btn-filter:hover {
            background: #22c55e;
        }
        
        .jobs-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin-bottom: 40px;
        }
        
        .job-card {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 10px;
            padding: 25px;
            transition: all 0.3s;
        }
        
        .job-card:hover {
            border-color: #4ade80;
            transform: translateY(-2px);
        }
        
        .job-title {
            color: #4ade80;
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 8px;
        }
        
        .company-name {
            color: white;
            font-weight: 500;
            margin-bottom: 15px;
        }
        
        .job-details {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            color: #94a3b8;
            font-size: 0.9rem;
            margin-bottom: 15px;
        }
        
        .job-details i {
            color: #4ade80;
            margin-right: 5px;
            width: 16px;
        }
        
        .job-description {
            color: #94a3b8;
            font-size: 0.95rem;
            margin-bottom: 20px;
            line-height: 1.5;
        }
        
        .job-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .salary {
            color: #4ade80;
            font-weight: 600;
            font-size: 1.1rem;
        }
        
        .deadline {
            color: #ef4444;
            font-size: 0.85rem;
        }
        
        .btn-view {
            background: #4ade80;
            color: #0f172a;
            padding: 8px 20px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 500;
            display: inline-block;
        }
        
        .btn-view:hover {
            background: #22c55e;
        }
        
        .no-results {
            grid-column: span 2;
            text-align: center;
            padding: 60px;
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 10px;
            color: #94a3b8;
        }
        
        .footer {
            background: #1e293b;
            border-top: 1px solid #334155;
            padding: 30px 0;
            margin-top: 50px;
            text-align: center;
            color: #64748b;
        }
        
        @media (max-width: 768px) {
            .jobs-grid {
                grid-template-columns: 1fr;
            }
            
            .filter-form {
                flex-direction: column;
            }
            
            .btn-filter {
                margin-top: 0;
                width: 100%;
            }
            
            .no-results {
                grid-column: span 1;
            }
        }
    </style>
</head>
<body>
    <div class="flag-header"></div>
    
    <!-- Navbar -->
    <nav class="navbar">
        <div class="container navbar-content">
            <a href="index.php" class="navbar-brand">
                <i class="fas fa-shield-alt"></i>SmartIntern Kenya
            </a>
            
            <div class="nav-links">
                <a href="index.php">Home</a>
                <a href="internships.php">Internships</a>
                
                <?php if ($currentUser): ?>
                    <span style="color: #4ade80;">Welcome, <?= htmlspecialchars($currentUser['name']) ?></span>
                    <a href="logout.php" style="color: #ef4444;">Logout</a>
                <?php else: ?>
                    <a href="login.php">Login</a>
                    <a href="register.php">Register</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>
    
    <div class="container">
        <!-- Header -->
        <div class="page-header">
            <h1>Internship Opportunities</h1>
            <p>Find your perfect internship in Kenya</p>
        </div>
        
        <!-- Filter Section -->
        <div class="filter-section">
            <form method="GET" class="filter-form">
                <div class="filter-group">
                    <label>Search</label>
                    <input type="text" name="search" class="filter-control" placeholder="Job title or keywords...">
                </div>
                
                <div class="filter-group">
                    <label>Location</label>
                    <select name="location" class="filter-control">
                        <option value="">All Locations</option>
                        <?php if ($locations && $locations->num_rows > 0): ?>
                            <?php while($loc = $locations->fetch_assoc()): ?>
                                <option value="<?= htmlspecialchars($loc['location']) ?>">
                                    <?= htmlspecialchars($loc['location']) ?>
                                </option>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label>Industry</label>
                    <select name="industry" class="filter-control">
                        <option value="">All Industries</option>
                        <?php if ($industries && $industries->num_rows > 0): ?>
                            <?php while($ind = $industries->fetch_assoc()): ?>
                                <option value="<?= htmlspecialchars($ind['industry']) ?>">
                                    <?= htmlspecialchars($ind['industry']) ?>
                                </option>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </select>
                </div>
                
                <button type="submit" class="btn-filter">
                    <i class="fas fa-search me-2"></i>Search
                </button>
            </form>
        </div>
        
        <!-- Jobs Grid -->
        <div class="jobs-grid">
            <?php if ($jobs && $jobs->num_rows > 0): ?>
                <?php while($job = $jobs->fetch_assoc()): ?>
                <div class="job-card">
                    <div class="job-title"><?= htmlspecialchars($job['title']) ?></div>
                    <div class="company-name">
                        <i class="fas fa-building me-2"></i><?= htmlspecialchars($job['company_name']) ?>
                    </div>
                    
                    <div class="job-details">
                        <span><i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($job['location']) ?></span>
                        <span><i class="fas fa-clock"></i> <?= htmlspecialchars($job['duration']) ?></span>
                        <span><i class="fas fa-tag"></i> <?= htmlspecialchars($job['industry']) ?></span>
                    </div>
                    
                    <div class="job-description">
                        <?= htmlspecialchars(substr($job['description'], 0, 150)) ?>...
                    </div>
                    
                    <div class="job-footer">
                        <div class="salary">KSh <?= number_format($job['salary']) ?>/mo</div>
                        <div class="deadline">
                            <i class="fas fa-calendar me-1"></i><?= date('M d', strtotime($job['deadline'])) ?>
                        </div>
                    </div>
                    
                    <a href="#" class="btn-view mt-3">View Details</a>
                </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="no-results">
                    <i class="fas fa-search fa-3x mb-3" style="color: #334155;"></i>
                    <h3>No internships found</h3>
                    <p>Check back later for new opportunities</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <p>&copy; 2026 SmartIntern Kenya. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>