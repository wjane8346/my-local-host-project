<?php
require_once '../includes/db_connect.php';
require_once '../ai/match-engine.php';

$engine = new SmartMatchEngine($conn);

// Get job ID from URL or default to 1
$jobId = isset($_GET['job_id']) ? (int)$_GET['job_id'] : 1;

// Get all jobs for dropdown
$jobs = $conn->query("SELECT * FROM jobs");

// Get matches
$matches = $engine->findMatchesForJob($jobId);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Candidate Matches - SmartIntern Kenya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: #0f172a;
            color: #e2e8f0;
            font-family: Arial, sans-serif;
        }
        .flag-header {
            height: 4px;
            background: linear-gradient(90deg, #000000 33%, #BB2B1F 33%, #BB2B1F 66%, #006233 66%);
        }
        .navbar {
            background: #1e293b;
            padding: 1rem;
            border-bottom: 1px solid #334155;
        }
        .navbar-brand {
            color: #4ade80 !important;
            font-weight: bold;
        }
        .match-card {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 1rem;
        }
        .score-high {
            color: #4ade80;
            font-size: 2rem;
            font-weight: bold;
        }
        .skill-tag {
            background: #0f172a;
            color: #94a3b8;
            padding: 0.2rem 0.5rem;
            border-radius: 4px;
            font-size: 0.8rem;
            display: inline-block;
            margin: 0.1rem;
        }
        .btn-outline-success {
            border: 1px solid #4ade80;
            color: #4ade80;
            padding: 0.5rem 1rem;
            border-radius: 6px;
            text-decoration: none;
        }
        .btn-outline-success:hover {
            background: #4ade80;
            color: #0f172a;
        }
    </style>
</head>
<body>

<div class="flag-header"></div>

<nav class="navbar">
    <div class="container">
        <a class="navbar-brand" href="/internship-portal/index.html">SmartIntern Kenya</a>
        <a href="/internship-portal/company/dashboard.html" class="btn btn-outline-success">← Back</a>
    </div>
</nav>

<div class="container py-4">
    <h2 class="text-white mb-4">
        <i class="fas fa-robot me-2 text-success"></i>AI Candidate Matches
    </h2>
    
    <!-- Job Selector -->
    <div class="bg-dark p-3 rounded mb-4 border border-secondary">
        <form method="GET" class="row">
            <div class="col-md-10">
                <select name="job_id" class="form-select bg-dark text-white border-secondary">
                    <?php while($job = $jobs->fetch_assoc()): ?>
                    <option value="<?= $job['id'] ?>" <?= $jobId == $job['id'] ? 'selected' : '' ?>>
                        <?= $job['title'] ?>
                    </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-success w-100">View Matches</button>
            </div>
        </form>
    </div>
    
    <!-- Results -->
    <?php if (empty($matches)): ?>
        <div class="alert alert-info">No matches found.</div>
    <?php else: ?>
        <?php foreach($matches as $match): ?>
        <div class="match-card">
            <div class="row">
                <div class="col-md-1 text-center">
                    <span class="score-high"><?= $match['match_score'] ?>%</span>
                </div>
                <div class="col-md-5">
                    <h5 class="text-white"><?= $match['student']['name'] ?></h5>
                    <p class="text-muted"><?= $match['student']['course'] ?> • <?= $match['student']['university'] ?></p>
                    <div>
                        <?php 
                        $skills = explode(',', $match['student']['skills']);
                        foreach($skills as $skill): 
                            if(trim($skill)): ?>
                        <span class="skill-tag"><?= trim($skill) ?></span>
                        <?php endif; endforeach; ?>
                    </div>
                </div>
                <div class="col-md-3">
                    <p><i class="fas fa-graduation-cap me-2 text-success"></i>CGPA: <?= $match['student']['cgpa'] ?></p>
                    <p><i class="fas fa-map-marker-alt me-2 text-success"></i><?= $match['student']['location'] ?></p>
                </div>
                <div class="col-md-3 text-end">
                    <a href="#" class="btn-outline-success me-2">View</a>
                    <a href="#" class="btn-outline-success">Contact</a>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

</body>
</html>