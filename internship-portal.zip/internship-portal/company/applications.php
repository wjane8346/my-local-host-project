<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Applications - SmartIntern Kenya</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        body {
            background: #0f172a;
            color: #e2e8f0;
            font-family: 'Inter', sans-serif;
        }
        
        .flag-header {
            height: 4px;
            background: linear-gradient(90deg, #000000 33%, #BB2B1F 33%, #BB2B1F 66%, #006233 66%);
        }
        
        .navbar {
            background: #1e293b;
            border-bottom: 1px solid #334155;
        }
        
        .filter-bar {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 8px;
            padding: 1rem;
            margin-bottom: 1.5rem;
        }
        
        .application-card {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 8px;
            padding: 1rem;
            margin-bottom: 1rem;
        }
        
        .status-select {
            background: #0f172a;
            color: white;
            border: 1px solid #334155;
            padding: 0.3rem;
            border-radius: 4px;
        }
        
        .match-high { color: #4ade80; }
        .match-medium { color: #fbbf24; }
        .match-low { color: #ef4444; }
        
        .btn-success {
            background: #4ade80;
            color: #0f172a;
            border: none;
        }
    </style>
</head>
<body>

<div class="flag-header"></div>

<nav class="navbar">
    <div class="container">
        <a class="navbar-brand text-success" href="../index.html">SmartIntern Kenya</a>
        <a href="dashboard.html" class="btn btn-sm btn-outline-success">← Back</a>
    </div>
</nav>

<div class="container mt-4">
    <h4 class="text-white mb-4">Applications for Software Developer Intern</h4>
    
    <!-- Filters -->
    <div class="filter-bar">
        <div class="row">
            <div class="col-md-3">
                <select class="form-select bg-dark text-white border-secondary">
                    <option>All Applications</option>
                    <option>Pending Review</option>
                    <option>Shortlisted</option>
                    <option>Rejected</option>
                </select>
            </div>
            <div class="col-md-3">
                <select class="form-select bg-dark text-white border-secondary">
                    <option>Sort by Match</option>
                    <option>Highest First</option>
                    <option>Lowest First</option>
                </select>
            </div>
            <div class="col-md-6">
                <input type="text" class="form-control bg-dark text-white border-secondary" placeholder="Search applicants...">
            </div>
        </div>
    </div>
    
    <!-- Applications List -->
    <div class="application-card">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h6 class="text-white">Wendy Jane</h6>
                <p class="text-muted small">Computer Science, UoN • Year 3 • CGPA 3.8</p>
                <p class="text-muted small">Applied: 2 days ago</p>
            </div>
            <div class="col-md-3">
                <span class="match-high">92% Match</span>
            </div>
            <div class="col-md-3">
                <select class="status-select">
                    <option>Pending Review</option>
                    <option>Shortlisted</option>
                    <option>Rejected</option>
                </select>
            </div>
        </div>
    </div>
    
    <div class="application-card">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h6 class="text-white">James Mwangi</h6>
                <p class="text-muted small">Computer Science, JKUAT • Year 4 • CGPA 3.6</p>
                <p class="text-muted small">Applied: 3 days ago</p>
            </div>
            <div class="col-md-3">
                <span class="match-high">87% Match</span>
            </div>
            <div class="col-md-3">
                <select class="status-select">
                    <option>Pending Review</option>
                    <option>Shortlisted</option>
                    <option>Rejected</option>
                </select>
            </div>
        </div>
    </div>
</div>

</body>
</html>