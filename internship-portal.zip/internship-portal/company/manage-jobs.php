<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Jobs - SmartIntern Kenya</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: #0f172a;
            color: #e2e8f0;
        }

        .flag-header {
            height: 4px;
            background: linear-gradient(90deg, 
                #000000 0%, #000000 33.33%,
                #BB2B1F 33.33%, #BB2B1F 66.66%,
                #006233 66.66%, #006233 100%);
        }

        .navbar {
            background: #1e293b;
            padding: 0.75rem 0;
            border-bottom: 1px solid #334155;
        }

        .navbar-brand {
            color: #4ade80 !important;
            font-weight: 700;
        }

        .page-header {
            padding: 1.5rem 0;
            border-bottom: 1px solid #334155;
        }

        .filter-tabs {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 8px;
            padding: 0.5rem;
            margin-bottom: 1.5rem;
        }

        .filter-tab {
            display: inline-block;
            padding: 0.5rem 1rem;
            color: #94a3b8;
            text-decoration: none;
            border-radius: 6px;
        }

        .filter-tab.active {
            background: #4ade80;
            color: #0f172a;
            font-weight: 500;
        }

        .job-table {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 10px;
            overflow: hidden;
        }

        .job-row {
            display: flex;
            align-items: center;
            padding: 1rem;
            border-bottom: 1px solid #334155;
        }

        .job-row:last-child {
            border-bottom: none;
        }

        .job-row:hover {
            background: #2d3a4f;
        }

        .job-info {
            flex: 3;
        }

        .job-title {
            color: white;
            font-weight: 600;
            margin-bottom: 0.25rem;
        }

        .job-meta {
            display: flex;
            gap: 1.5rem;
            color: #94a3b8;
            font-size: 0.8rem;
        }

        .job-stats {
            flex: 1;
            text-align: center;
        }

        .stat-number {
            color: #4ade80;
            font-weight: 700;
            font-size: 1.1rem;
        }

        .stat-label {
            color: #94a3b8;
            font-size: 0.7rem;
        }

        .job-status {
            flex: 1;
            text-align: center;
        }

        .status-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 500;
        }

        .status-active {
            background: #166534;
            color: #bbf7d0;
        }

        .status-closed {
            background: #7f1d1d;
            color: #fecaca;
        }

        .job-actions {
            flex: 1;
            text-align: right;
        }

        .btn-icon {
            background: transparent;
            border: 1px solid #334155;
            color: #94a3b8;
            width: 32px;
            height: 32px;
            border-radius: 6px;
            margin: 0 0.2rem;
        }

        .btn-icon:hover {
            border-color: #4ade80;
            color: #4ade80;
        }

        .btn-green {
            background: #4ade80;
            color: #0f172a;
            border: none;
            padding: 0.5rem 1.5rem;
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
        }

        .pagination {
            margin-top: 2rem;
        }

        .page-link {
            background: #1e293b;
            border: 1px solid #334155;
            color: #94a3b8;
        }

        .page-link:hover {
            background: #4ade80;
            color: #0f172a;
        }
    </style>
</head>
<body>

<div class="flag-header"></div>

<!-- Navbar -->
<nav class="navbar">
    <div class="container">
        <a class="navbar-brand" href="../index.html">
            <i class="fas fa-shield-alt me-2"></i>SmartIntern Kenya
        </a>
        <a href="dashboard.html" class="btn btn-sm btn-outline-success">← Back to Dashboard</a>
    </div>
</nav>

<!-- Page Header -->
<div class="page-header">
    <div class="container">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h1 class="text-white h3">Manage Internships</h1>
                <p class="text-muted small mb-0">View and manage all your job postings</p>
            </div>
            <a href="post-internship.html" class="btn-green">
                <i class="fas fa-plus-circle me-2"></i>Post New
            </a>
        </div>
    </div>
</div>

<div class="container py-4">
    <!-- Filter Tabs -->
    <div class="filter-tabs">
        <a href="#" class="filter-tab active">All Jobs (12)</a>
        <a href="#" class="filter-tab">Active (8)</a>
        <a href="#" class="filter-tab">Closed (4)</a>
        <a href="#" class="filter-tab">Drafts (2)</a>
    </div>

    <!-- Jobs Table -->
    <div class="job-table">
        <!-- Job Row 1 -->
        <div class="job-row">
            <div class="job-info">
                <div class="job-title">Software Developer Intern</div>
                <div class="job-meta">
                    <span><i class="fas fa-map-marker-alt me-1 text-success"></i>Nairobi</span>
                    <span><i class="fas fa-clock me-1 text-success"></i>3 months</span>
                    <span><i class="fas fa-money-bill me-1 text-success"></i>KSh 45k</span>
                    <span><i class="fas fa-calendar me-1 text-success"></i>Posted: Feb 10</span>
                </div>
            </div>
            <div class="job-stats">
                <div class="stat-number">45</div>
                <div class="stat-label">Applicants</div>
            </div>
            <div class="job-stats">
                <div class="stat-number">12</div>
                <div class="stat-label">Shortlisted</div>
            </div>
            <div class="job-status">
                <span class="status-badge status-active">Active</span>
            </div>
            <div class="job-actions">
                <button class="btn-icon"><i class="fas fa-eye"></i></button>
                <button class="btn-icon"><i class="fas fa-edit"></i></button>
                <button class="btn-icon"><i class="fas fa-times"></i></button>
            </div>
        </div>

        <!-- Job Row 2 -->
        <div class="job-row">
            <div class="job-info">
                <div class="job-title">Network Engineer Intern</div>
                <div class="job-meta">
                    <span><i class="fas fa-map-marker-alt me-1 text-success"></i>Nairobi</span>
                    <span><i class="fas fa-clock me-1 text-success"></i>4 months</span>
                    <span><i class="fas fa-money-bill me-1 text-success"></i>KSh 40k</span>
                    <span><i class="fas fa-calendar me-1 text-success"></i>Posted: Feb 8</span>
                </div>
            </div>
            <div class="job-stats">
                <div class="stat-number">32</div>
                <div class="stat-label">Applicants</div>
            </div>
            <div class="job-stats">
                <div class="stat-number">8</div>
                <div class="stat-label">Shortlisted</div>
            </div>
            <div class="job-status">
                <span class="status-badge status-active">Active</span>
            </div>
            <div class="job-actions">
                <button class="btn-icon"><i class="fas fa-eye"></i></button>
                <button class="btn-icon"><i class="fas fa-edit"></i></button>
                <button class="btn-icon"><i class="fas fa-times"></i></button>
            </div>
        </div>

        <!-- Job Row 3 -->
        <div class="job-row">
            <div class="job-info">
                <div class="job-title">Data Science Intern</div>
                <div class="job-meta">
                    <span><i class="fas fa-map-marker-alt me-1 text-success"></i>Nairobi</span>
                    <span><i class="fas fa-clock me-1 text-success"></i>3 months</span>
                    <span><i class="fas fa-money-bill me-1 text-success"></i>KSh 50k</span>
                    <span><i class="fas fa-calendar me-1 text-success"></i>Posted: Feb 5</span>
                </div>
            </div>
            <div class="job-stats">
                <div class="stat-number">28</div>
                <div class="stat-label">Applicants</div>
            </div>
            <div class="job-stats">
                <div class="stat-number">6</div>
                <div class="stat-label">Shortlisted</div>
            </div>
            <div class="job-status">
                <span class="status-badge status-active">Active</span>
            </div>
            <div class="job-actions">
                <button class="btn-icon"><i class="fas fa-eye"></i></button>
                <button class="btn-icon"><i class="fas fa-edit"></i></button>
                <button class="btn-icon"><i class="fas fa-times"></i></button>
            </div>
        </div>

        <!-- Job Row 4 (Closed) -->
        <div class="job-row">
            <div class="job-info">
                <div class="job-title">Marketing Intern</div>
                <div class="job-meta">
                    <span><i class="fas fa-map-marker-alt me-1 text-success"></i>Nairobi</span>
                    <span><i class="fas fa-clock me-1 text-success"></i>3 months</span>
                    <span><i class="fas fa-money-bill me-1 text-success"></i>KSh 35k</span>
                    <span><i class="fas fa-calendar me-1 text-success"></i>Posted: Jan 15</span>
                </div>
            </div>
            <div class="job-stats">
                <div class="stat-number">52</div>
                <div class="stat-label">Applicants</div>
            </div>
            <div class="job-stats">
                <div class="stat-number">18</div>
                <div class="stat-label">Hired</div>
            </div>
            <div class="job-status">
                <span class="status-badge status-closed">Closed</span>
            </div>
            <div class="job-actions">
                <button class="btn-icon"><i class="fas fa-eye"></i></button>
                <button class="btn-icon"><i class="fas fa-copy"></i></button>
            </div>
        </div>
    </div>

    <!-- Pagination -->
    <nav class="pagination justify-content-center">
        <ul class="pagination">
            <li class="page-item disabled"><a class="page-link" href="#">Previous</a></li>
            <li class="page-item active"><a class="page-link" href="#">1</a></li>
            <li class="page-item"><a class="page-link" href="#">2</a></li>
            <li class="page-item"><a class="page-link" href="#">3</a></li>
            <li class="page-item"><a class="page-link" href="#">Next</a></li>
        </ul>
    </nav>
</div>

</body>
</html>