<?php
require_once '../includes/db_connect.php';
require_once '../includes/auth.php';
requireCompany();

$company = getCurrentUser($conn);
$company_id = $company['id'];

// Get company's jobs
$jobs_query = "SELECT j.*, 
               (SELECT COUNT(*) FROM applications WHERE job_id = j.id) as applicant_count
               FROM jobs j 
               WHERE j.company_id = ? 
               ORDER BY j.created_at DESC";
$stmt = $conn->prepare($jobs_query);
$stmt->bind_param("i", $company_id);
$stmt->execute();
$jobs = $stmt->get_result();

// Get application stats
$stats_query = "SELECT 
                COUNT(DISTINCT a.id) as total_apps,
                SUM(CASE WHEN a.status = 'pending' THEN 1 ELSE 0 END) as pending,
                SUM(CASE WHEN a.status = 'reviewing' THEN 1 ELSE 0 END) as reviewing,
                SUM(CASE WHEN a.status = 'shortlisted' THEN 1 ELSE 0 END) as shortlisted,
                SUM(CASE WHEN a.status = 'interview' THEN 1 ELSE 0 END) as interviews
                FROM applications a
                JOIN jobs j ON a.job_id = j.id
                WHERE j.company_id = ?";
$stmt = $conn->prepare($stats_query);
$stmt->bind_param("i", $company_id);
$stmt->execute();
$stats = $stmt->get_result()->fetch_assoc();

// Get recent applicants
$recent_query = "SELECT a.*, s.name as student_name, s.course, s.university, j.title as job_title
                 FROM applications a
                 JOIN students s ON a.student_id = s.id
                 JOIN jobs j ON a.job_id = j.id
                 WHERE j.company_id = ?
                 ORDER BY a.created_at DESC
                 LIMIT 5";
$stmt = $conn->prepare($recent_query);
$stmt->bind_param("i", $company_id);
$stmt->execute();
$recent_apps = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Company Dashboard - SmartIntern Kenya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #0f172a;
            color: #e2e8f0;
            line-height: 1.6;
        }
        
        .flag-header {
            height: 4px;
            background: linear-gradient(90deg, 
                #000000 0%, #000000 33.33%,
                #b91c1c 33.33%, #b91c1c 66.66%,
                #059669 66.66%, #059669 100%);
        }
        
        .navbar {
            background: #1e293b;
            border-bottom: 1px solid #334155;
            padding: 1rem 0;
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        .navbar-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .navbar-brand {
            font-weight: 700;
            font-size: 1.3rem;
            color: #4ade80;
            text-decoration: none;
        }
        
        .navbar-brand i {
            color: #4ade80;
            margin-right: 8px;
        }
        
        .nav-links {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .nav-links a {
            color: #cbd5e1;
            text-decoration: none;
            transition: color 0.2s;
            padding: 5px 10px;
            border-radius: 6px;
        }
        
        .nav-links a:hover {
            color: #4ade80;
            background: #0f172a;
        }
        
        .nav-links a.active {
            color: #4ade80;
            background: #0f172a;
            border-left: 3px solid #4ade80;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
            color: #94a3b8;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #059669, #4ade80);
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.1rem;
        }
        
        .btn-logout {
            color: #ef4444;
            text-decoration: none;
            padding: 8px 15px;
            border-radius: 6px;
            border: 1px solid #ef4444;
            transition: all 0.2s;
        }
        
        .btn-logout:hover {
            background: #ef4444;
            color: white;
        }
        
        .welcome-section {
            background: linear-gradient(135deg, #1e293b, #0f172a);
            border: 1px solid #334155;
            border-radius: 12px;
            padding: 30px;
            margin: 30px 0;
            display: flex;
            align-items: center;
            gap: 30px;
        }
        
        .welcome-avatar {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #059669, #4ade80);
            border-radius: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 2rem;
            font-weight: bold;
        }
        
        .welcome-text h1 {
            color: white;
            margin-bottom: 5px;
        }
        
        .welcome-text p {
            color: #94a3b8;
        }
        
        .welcome-stats {
            display: flex;
            gap: 30px;
            margin-left: auto;
        }
        
        .stat-item {
            text-align: center;
        }
        
        .stat-value {
            font-size: 1.5rem;
            font-weight: 700;
            color: #4ade80;
        }
        
        .stat-label {
            color: #94a3b8;
            font-size: 0.9rem;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 10px;
            padding: 20px;
            display: flex;
            align-items: center;
            gap: 15px;
            transition: all 0.3s;
        }
        
        .stat-card:hover {
            border-color: #4ade80;
            transform: translateY(-2px);
        }
        
        .stat-icon {
            width: 50px;
            height: 50px;
            background: #0f172a;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #4ade80;
            font-size: 1.3rem;
        }
        
        .stat-info h3 {
            font-size: 1.8rem;
            color: white;
            margin-bottom: 2px;
        }
        
        .stat-info p {
            color: #94a3b8;
            margin: 0;
            font-size: 0.9rem;
        }
        
        .action-buttons {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 15px;
            margin-bottom: 30px;
        }
        
        .action-btn {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 8px;
            padding: 15px;
            text-align: center;
            text-decoration: none;
            color: #e2e8f0;
            transition: all 0.3s;
        }
        
        .action-btn:hover {
            border-color: #4ade80;
            transform: translateY(-2px);
        }
        
        .action-btn i {
            color: #4ade80;
            font-size: 1.5rem;
            margin-bottom: 10px;
            display: block;
        }
        
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 30px 0 20px;
        }
        
        .section-header h2 {
            color: white;
            font-size: 1.5rem;
        }
        
        .section-header a {
            color: #4ade80;
            text-decoration: none;
        }
        
        .section-header a:hover {
            text-decoration: underline;
        }
        
        .card {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
        }
        
        .job-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 0;
            border-bottom: 1px solid #334155;
        }
        
        .job-item:last-child {
            border-bottom: none;
        }
        
        .job-info h4 {
            color: white;
            margin-bottom: 5px;
        }
        
        .job-info p {
            color: #94a3b8;
            font-size: 0.9rem;
        }
        
        .job-meta {
            display: flex;
            gap: 15px;
            margin-top: 8px;
            color: #64748b;
            font-size: 0.85rem;
        }
        
        .job-meta i {
            color: #4ade80;
            margin-right: 5px;
        }
        
        .applicant-badge {
            background: #0f172a;
            color: #4ade80;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.85rem;
        }
        
        .applicant-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 0;
            border-bottom: 1px solid #334155;
        }
        
        .applicant-item:last-child {
            border-bottom: none;
        }
        
        .applicant-info h4 {
            color: white;
            margin-bottom: 5px;
        }
        
        .applicant-info p {
            color: #94a3b8;
            font-size: 0.85rem;
        }
        
        .status-badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .status-pending { background: #fef3c7; color: #92400e; }
        .status-reviewing { background: #dbeafe; color: #1e40af; }
        .status-shortlisted { background: #d1fae5; color: #065f46; }
        .status-interview { background: #e0f2fe; color: #0369a1; }
        
        .footer {
            background: #1e293b;
            border-top: 1px solid #334155;
            padding: 30px 0;
            margin-top: 50px;
            text-align: center;
            color: #64748b;
        }
        
        @media (max-width: 768px) {
            .stats-grid,
            .action-buttons {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .navbar-content {
                flex-direction: column;
                gap: 15px;
            }
        }
    </style>
</head>
<body>
    <div class="flag-header"></div>
    
    <nav class="navbar">
        <div class="container navbar-content">
            <a href="../index.php" class="navbar-brand">
                <i class="fas fa-shield-alt"></i>SmartIntern Kenya
            </a>
            
            <div class="nav-links">
                <a href="dashboard.php" class="active">Dashboard</a>
                <a href="post-job.php">Post Job</a>
                <a href="manage-jobs.php">Manage Jobs</a>
                <a href="applications.php">Applications</a>
                <a href="candidates.php">Find Candidates</a>
                <a href="ai-matches.php">AI Matches</a>
                
                <div class="user-info">
                    <div class="user-avatar">
                        <?= substr($company['name'], 0, 1) ?>
                    </div>
                    <span><?= htmlspecialchars($company['name']) ?></span>
                </div>
                
                <a href="../logout.php" class="btn-logout">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </div>
    </nav>
    
    <div class="container">
        <!-- Welcome Section -->
        <div class="welcome-section">
            <div class="welcome-avatar">
                <?= substr($company['name'], 0, 1) ?>
            </div>
            <div class="welcome-text">
                <h1>Welcome back, <?= htmlspecialchars($company['name']) ?>!</h1>
                <p><?= htmlspecialchars($company['industry']) ?> • <?= htmlspecialchars($company['location']) ?></p>
            </div>
            <div class="welcome-stats">
                <div class="stat-item">
                    <div class="stat-value"><?= $jobs->num_rows ?></div>
                    <div class="stat-label">Active Jobs</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value"><?= $stats['total_apps'] ?? 0 ?></div>
                    <div class="stat-label">Applications</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value"><?= $stats['shortlisted'] ?? 0 ?></div>
                    <div class="stat-label">Shortlisted</div>
                </div>
            </div>
        </div>
        
        <!-- Stats Cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-briefcase"></i>
                </div>
                <div class="stat-info">
                    <h3><?= $jobs->num_rows ?></h3>
                    <p>Active Jobs</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-file-alt"></i>
                </div>
                <div class="stat-info">
                    <h3><?= $stats['total_apps'] ?? 0 ?></h3>
                    <p>Total Applications</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-check-circle"></i>
                </div>
                <div class="stat-info">
                    <h3><?= $stats['shortlisted'] ?? 0 ?></h3>
                    <p>Shortlisted</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-calendar"></i>
                </div>
                <div class="stat-info">
                    <h3><?= $stats['interviews'] ?? 0 ?></h3>
                    <p>Interviews</p>
                </div>
            </div>
        </div>
        
        <!-- Quick Actions -->
        <div class="action-buttons">
            <a href="post-job.php" class="action-btn">
                <i class="fas fa-plus-circle"></i>
                Post New Job
            </a>
            <a href="manage-jobs.php" class="action-btn">
                <i class="fas fa-briefcase"></i>
                Manage Jobs
            </a>
            <a href="applications.php" class="action-btn">
                <i class="fas fa-file-alt"></i>
                View Applications
            </a>
            <a href="ai-matches.php" class="action-btn">
                <i class="fas fa-robot"></i>
                AI Matches
            </a>
        </div>
        
        <div class="row">
            <div class="col-md-7">
                <!-- Active Jobs -->
                <div class="section-header">
                    <h2>Your Active Jobs</h2>
                    <a href="manage-jobs.php">Manage All →</a>
                </div>
                
                <div class="card">
                    <?php if ($jobs && $jobs->num_rows > 0): ?>
                        <?php while($job = $jobs->fetch_assoc()): ?>
                            <div class="job-item">
                                <div class="job-info">
                                    <h4><?= htmlspecialchars($job['title']) ?></h4>
                                    <p><?= htmlspecialchars($job['location']) ?> • KSh <?= number_format($job['salary']) ?>/month</p>
                                    <div class="job-meta">
                                        <span><i class="fas fa-clock"></i> <?= htmlspecialchars($job['duration']) ?></span>
                                        <span><i class="fas fa-calendar"></i> Deadline: <?= date('M d', strtotime($job['deadline'])) ?></span>
                                    </div>
                                </div>
                                <div>
                                    <span class="applicant-badge">
                                        <i class="fas fa-users"></i> <?= $job['applicant_count'] ?> applicants
                                    </span>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <p style="color: #64748b; text-align: center; padding: 20px;">No jobs posted yet. Post your first internship!</p>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="col-md-5">
                <!-- Recent Applicants -->
                <div class="section-header">
                    <h2>Recent Applicants</h2>
                    <a href="applications.php">View All →</a>
                </div>
                
                <div class="card">
                    <?php if ($recent_apps && $recent_apps->num_rows > 0): ?>
                        <?php while($app = $recent_apps->fetch_assoc()): ?>
                            <div class="applicant-item">
                                <div class="applicant-info">
                                    <h4><?= htmlspecialchars($app['student_name']) ?></h4>
                                    <p><?= htmlspecialchars($app['course']) ?> • <?= htmlspecialchars($app['university']) ?></p>
                                    <p style="color: #64748b; font-size: 0.8rem;">Applied for: <?= htmlspecialchars($app['job_title']) ?></p>
                                </div>
                                <div>
                                    <?php
                                    $statusClass = '';
                                    switch($app['status']) {
                                        case 'pending': $statusClass = 'status-pending'; break;
                                        case 'reviewing': $statusClass = 'status-reviewing'; break;
                                        case 'shortlisted': $statusClass = 'status-shortlisted'; break;
                                        case 'interview': $statusClass = 'status-interview'; break;
                                    }
                                    ?>
                                    <span class="status-badge <?= $statusClass ?>">
                                        <?= ucfirst($app['status']) ?>
                                    </span>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <p style="color: #64748b; text-align: center; padding: 20px;">No applications yet.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <footer class="footer">
        <div class="container">
            <p>&copy; 2026 SmartIntern Kenya - Company Portal</p>
        </div>
    </footer>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>