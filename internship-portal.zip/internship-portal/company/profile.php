<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Company Profile - SmartIntern Kenya</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        body {
            background: #0f172a;
            color: #e2e8f0;
            font-family: 'Inter', sans-serif;
        }

        .flag-header {
            height: 4px;
            background: linear-gradient(90deg, #000000 33%, #BB2B1F 33%, #BB2B1F 66%, #006233 66%);
        }

        .navbar {
            background: #1e293b;
            border-bottom: 1px solid #334155;
        }

        .profile-container {
            max-width: 800px;
            margin: 2rem auto;
        }

        .profile-card {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 12px;
            padding: 2rem;
        }

        .company-logo-large {
            width: 100px;
            height: 100px;
            background: linear-gradient(135deg, #006233, #BB2B1F);
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 700;
            font-size: 2.5rem;
        }

        .info-row {
            display: flex;
            padding: 0.75rem 0;
            border-bottom: 1px solid #334155;
        }

        .info-label {
            width: 150px;
            color: #94a3b8;
        }

        .info-value {
            flex: 1;
            color: white;
        }

        .btn-save {
            background: #4ade80;
            color: #0f172a;
            font-weight: 600;
            padding: 0.8rem;
            width: 100%;
            border: none;
            border-radius: 8px;
        }
    </style>
</head>
<body>

<div class="flag-header"></div>

<nav class="navbar">
    <div class="container">
        <a class="navbar-brand text-success" href="../index.html">SmartIntern Kenya</a>
        <a href="dashboard.html" class="btn btn-sm btn-outline-success">← Back</a>
    </div>
</nav>

<div class="container profile-container">
    <div class="profile-card">
        <div class="text-center mb-4">
            <div class="company-logo-large mx-auto mb-3">S</div>
            <h3 class="text-white">Safaricom PLC</h3>
            <span class="badge bg-success">Verified Company</span>
        </div>

        <form>
            <div class="info-row">
                <span class="info-label">Company Name</span>
                <span class="info-value">Safaricom PLC</span>
            </div>
            <div class="info-row">
                <span class="info-label">Industry</span>
                <select class="form-select bg-dark text-white border-secondary">
                    <option>Telecommunications</option>
                    <option>Technology</option>
                    <option>Banking</option>
                </select>
            </div>
            <div class="info-row">
                <span class="info-label">Email</span>
                <input type="email" class="form-control bg-dark text-white border-secondary" value="hr@safaricom.co.ke">
            </div>
            <div class="info-row">
                <span class="info-label">Phone</span>
                <input type="text" class="form-control bg-dark text-white border-secondary" value="+254 700 000 000">
            </div>
            <div class="info-row">
                <span class="info-label">Website</span>
                <input type="text" class="form-control bg-dark text-white border-secondary" value="www.safaricom.co.ke">
            </div>
            <div class="info-row">
                <span class="info-label">Location</span>
                <input type="text" class="form-control bg-dark text-white border-secondary" value="Westlands, Nairobi">
            </div>
            <div class="info-row">
                <span class="info-label">Founded</span>
                <input type="text" class="form-control bg-dark text-white border-secondary" value="1997">
            </div>
            <div class="info-row">
                <span class="info-label">Employees</span>
                <select class="form-select bg-dark text-white border-secondary">
                    <option>5000+</option>
                    <option>1000-5000</option>
                    <option>500-1000</option>
                </select>
            </div>
            <div class="info-row">
                <span class="info-label">Description</span>
                <textarea class="form-control bg-dark text-white border-secondary" rows="3">Leading telecommunications company in Kenya, known for M-PESA mobile money service.</textarea>
            </div>

            <button type="submit" class="btn-save mt-4">Save Changes</button>
        </form>
    </div>
</div>

</body>
</html>