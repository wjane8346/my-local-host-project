<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Find Candidates - SmartIntern Kenya</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        body {
            background: #0f172a;
            color: #e2e8f0;
            font-family: 'Inter', sans-serif;
        }

        .flag-header {
            height: 4px;
            background: linear-gradient(90deg, #000000 33%, #BB2B1F 33%, #BB2B1F 66%, #006233 66%);
        }

        .navbar {
            background: #1e293b;
            border-bottom: 1px solid #334155;
        }

        .search-section {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 2rem;
        }

        .candidate-card {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 10px;
            padding: 1.25rem;
            transition: all 0.2s;
            height: 100%;
        }

        .candidate-card:hover {
            border-color: #4ade80;
            transform: translateY(-2px);
        }

        .candidate-avatar {
            width: 60px;
            height: 60px;
            background: #0f172a;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #4ade80;
            font-weight: 700;
            font-size: 1.3rem;
        }

        .skill-tag {
            background: #0f172a;
            color: #94a3b8;
            padding: 0.2rem 0.6rem;
            border-radius: 4px;
            font-size: 0.7rem;
            display: inline-block;
            margin: 0.2rem;
        }

        .match-score {
            font-size: 1.3rem;
            font-weight: 700;
            color: #4ade80;
        }

        .btn-view {
            border: 1px solid #4ade80;
            color: #4ade80;
            padding: 0.3rem 1rem;
            border-radius: 6px;
            text-decoration: none;
            font-size: 0.85rem;
        }

        .btn-view:hover {
            background: #4ade80;
            color: #0f172a;
        }
    </style>
</head>
<body>

<div class="flag-header"></div>

<nav class="navbar">
    <div class="container">
        <a class="navbar-brand text-success" href="../index.html">SmartIntern Kenya</a>
        <a href="dashboard.html" class="btn btn-sm btn-outline-success">← Back</a>
    </div>
</nav>

<div class="container py-4">
    <h3 class="text-white mb-4"><i class="fas fa-search me-2 text-success"></i>Find Top Talent</h3>

    <!-- Search Section -->
    <div class="search-section">
        <div class="row g-3">
            <div class="col-md-4">
                <input type="text" class="form-control bg-dark text-white border-secondary" placeholder="Search skills...">
            </div>
            <div class="col-md-3">
                <select class="form-select bg-dark text-white border-secondary">
                    <option>All Universities</option>
                    <option>University of Nairobi</option>
                    <option>JKUAT</option>
                    <option>Strathmore</option>
                    <option>Moi University</option>
                </select>
            </div>
            <div class="col-md-3">
                <select class="form-select bg-dark text-white border-secondary">
                    <option>Min. CGPA: Any</option>
                    <option>3.5 and above</option>
                    <option>3.0 and above</option>
                    <option>2.5 and above</option>
                </select>
            </div>
            <div class="col-md-2">
                <button class="btn btn-success w-100">Search</button>
            </div>
        </div>
    </div>

    <!-- AI Match Info -->
    <div class="alert alert-success bg-success bg-opacity-10 text-success border-success mb-4">
        <i class="fas fa-robot me-2"></i>AI is matching candidates to your job requirements. Showing best matches first.
    </div>

    <!-- Candidates Grid -->
    <div class="row g-3">
        <!-- Candidate 1 -->
        <div class="col-md-6 col-lg-4">
            <div class="candidate-card">
                <div class="d-flex align-items-center gap-3 mb-3">
                    <div class="candidate-avatar">WJ</div>
                    <div>
                        <h5 class="text-white mb-1">Wendy Jane</h5>
                        <p class="text-muted small mb-0">Computer Science, UoN</p>
                        <p class="text-muted small">Year 3 • CGPA 3.8</p>
                    </div>
                </div>
                <div class="mb-2">
                    <span class="skill-tag">Python</span>
                    <span class="skill-tag">JavaScript</span>
                    <span class="skill-tag">React</span>
                    <span class="skill-tag">SQL</span>
                    <span class="skill-tag">Django</span>
                </div>
                <div class="d-flex justify-content-between align-items-center mt-3">
                    <div>
                        <span class="match-score">92%</span>
                        <span class="text-muted small"> match</span>
                    </div>
                    <a href="#" class="btn-view">View Profile</a>
                </div>
            </div>
        </div>

        <!-- Candidate 2 -->
        <div class="col-md-6 col-lg-4">
            <div class="candidate-card">
                <div class="d-flex align-items-center gap-3 mb-3">
                    <div class="candidate-avatar">JM</div>
                    <div>
                        <h5 class="text-white mb-1">James Mwangi</h5>
                        <p class="text-muted small mb-0">Computer Science, JKUAT</p>
                        <p class="text-muted small">Year 4 • CGPA 3.6</p>
                    </div>
                </div>
                <div class="mb-2">
                    <span class="skill-tag">Java</span>
                    <span class="skill-tag">Spring Boot</span>
                    <span class="skill-tag">MySQL</span>
                    <span class="skill-tag">AWS</span>
                </div>
                <div class="d-flex justify-content-between align-items-center mt-3">
                    <div>
                        <span class="match-score">87%</span>
                        <span class="text-muted small"> match</span>
                    </div>
                    <a href="#" class="btn-view">View Profile</a>
                </div>
            </div>
        </div>

        <!-- Candidate 3 -->
        <div class="col-md-6 col-lg-4">
            <div class="candidate-card">
                <div class="d-flex align-items-center gap-3 mb-3">
                    <div class="candidate-avatar">AK</div>
                    <div>
                        <h5 class="text-white mb-1">Alice Kariuki</h5>
                        <p class="text-muted small mb-0">Data Science, Strathmore</p>
                        <p class="text-muted small">Year 4 • CGPA 3.9</p>
                    </div>
                </div>
                <div class="mb-2">
                    <span class="skill-tag">Python</span>
                    <span class="skill-tag">Pandas</span>
                    <span class="skill-tag">TensorFlow</span>
                    <span class="skill-tag">SQL</span>
                    <span class="skill-tag">Tableau</span>
                </div>
                <div class="d-flex justify-content-between align-items-center mt-3">
                    <div>
                        <span class="match-score">94%</span>
                        <span class="text-muted small"> match</span>
                    </div>
                    <a href="#" class="btn-view">View Profile</a>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>