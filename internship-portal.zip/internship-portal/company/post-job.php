<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Post Internship - SmartIntern Kenya</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: #0f172a;
            color: #e2e8f0;
        }

        .flag-header {
            height: 4px;
            background: linear-gradient(90deg, 
                #000000 0%, #000000 33.33%,
                #BB2B1F 33.33%, #BB2B1F 66.66%,
                #006233 66.66%, #006233 100%);
        }

        .navbar {
            background: #1e293b;
            padding: 0.75rem 0;
            border-bottom: 1px solid #334155;
        }

        .navbar-brand {
            color: #4ade80 !important;
            font-weight: 700;
            font-size: 1.3rem;
        }

        .nav-link {
            color: #cbd5e1 !important;
            font-weight: 500;
            margin: 0 0.5rem;
        }

        .nav-link:hover,
        .nav-link.active {
            color: #4ade80 !important;
        }

        .dropdown-menu {
            background: #1e293b;
            border: 1px solid #334155;
        }

        .dropdown-item {
            color: #cbd5e1;
        }

        .dropdown-item:hover {
            background: #0f172a;
            color: #4ade80;
        }

        .form-container {
            max-width: 800px;
            margin: 2rem auto;
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 12px;
            padding: 2rem;
        }

        .form-label {
            color: #cbd5e1;
            font-weight: 500;
            margin-bottom: 0.3rem;
        }

        .form-control, .form-select {
            background: #0f172a;
            border: 1px solid #334155;
            color: white;
            padding: 0.6rem;
            border-radius: 6px;
        }

        .form-control:focus, .form-select:focus {
            border-color: #4ade80;
            box-shadow: none;
        }

        .btn-post {
            background: #4ade80;
            color: #0f172a;
            font-weight: 600;
            padding: 0.8rem;
            width: 100%;
            border: none;
            border-radius: 8px;
        }

        .btn-post:hover {
            background: #22c55e;
        }
    </style>
</head>
<body>

<div class="flag-header"></div>

<!-- Navbar with Student and Company Dropdowns -->
<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="../index.html">
            <i class="fas fa-shield-alt me-2"></i>SmartIntern Kenya
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav mx-auto">
                <li class="nav-item">
                    <a class="nav-link" href="../index.html">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../internships.html">Internships</a>
                </li>
                
                <!-- Student Dropdown -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                        Students
                    </a>
                    <ul class="dropdown-menu dropdown-menu-dark">
                        <li><a class="dropdown-item" href="../dashboard.html">Student Dashboard</a></li>
                        <li><a class="dropdown-item" href="../profile.html">My Profile</a></li>
                        <li><a class="dropdown-item" href="../applications.html">My Applications</a></li>
                    </ul>
                </li>
                
                <!-- Company Dropdown (Active) -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle active" href="#" role="button" data-bs-toggle="dropdown">
                        Companies
                    </a>
                    <ul class="dropdown-menu dropdown-menu-dark">
                        <li><a class="dropdown-item" href="dashboard.html">Company Dashboard</a></li>
                        <li><a class="dropdown-item active" href="post-internship.html">Post Internship</a></li>
                        <li><a class="dropdown-item" href="manage-jobs.html">Manage Jobs</a></li>
                        <li><a class="dropdown-item" href="candidates.html">Find Candidates</a></li>
                    </ul>
                </li>
                
                <li class="nav-item">
                    <a class="nav-link" href="../contact.html">Contact</a>
                </li>
            </ul>
            <div class="d-flex ms-3">
                <span class="text-success me-3"><i class="fas fa-building"></i> Safaricom</span>
                <a href="../login.html" class="btn btn-sm btn-outline-danger">Logout</a>
            </div>
        </div>
    </div>
</nav>

<div class="container">
    <div class="form-container">
        <h3 class="text-white mb-4"><i class="fas fa-plus-circle me-2 text-success"></i>Post New Internship</h3>
        
        <form>
            <div class="mb-3">
                <label class="form-label">Job Title</label>
                <input type="text" class="form-control" placeholder="e.g., Software Developer Intern">
            </div>
            
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Location</label>
                    <select class="form-select">
                        <option>Nairobi</option>
                        <option>Mombasa</option>
                        <option>Kisumu</option>
                        <option>Nakuru</option>
                        <option>Remote</option>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Duration (months)</label>
                    <select class="form-select">
                        <option>3 months</option>
                        <option>4 months</option>
                        <option>6 months</option>
                        <option>12 months</option>
                    </select>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Monthly Salary (KSh)</label>
                    <input type="number" class="form-control" placeholder="e.g., 45000">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Application Deadline</label>
                    <input type="date" class="form-control">
                </div>
            </div>
            
            <div class="mb-3">
                <label class="form-label">Required Skills (comma separated)</label>
                <input type="text" class="form-control" placeholder="Python, JavaScript, SQL, React">
            </div>
            
            <div class="mb-3">
                <label class="form-label">Job Description</label>
                <textarea class="form-control" rows="5" placeholder="Describe the internship role, responsibilities, and requirements..."></textarea>
            </div>
            
            <button type="submit" class="btn-post">Post Internship</button>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>