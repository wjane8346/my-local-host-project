<?php
require_once '../includes/db_connect.php';
require_once 'analytics-engine.php';

$ml = new MLAnalyticsEngine($conn);
$predictions = $ml->predictAllPlacements();
$facultyStats = $ml->getPlacementByFaculty();
$forecast = $ml->forecastPlacementTrend();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Placement Predictions - SmartIntern Kenya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #0f172a; color: #e2e8f0; font-family: Arial, sans-serif; }
        .flag-header { height: 4px; background: linear-gradient(90deg, black 33%, #BB2B1F 33%, #BB2B1F 66%, #006233 66%); }
        .navbar { background: #1e293b; padding: 1rem; }
        .container { max-width: 1200px; margin: 2rem auto; padding: 0 20px; }
        .stat-card { background: #1e293b; border: 1px solid #334155; border-radius: 10px; padding: 1.5rem; margin-bottom: 1rem; }
        .high { color: #4ade80; }
        .medium { color: #f59e0b; }
        .low { color: #ef4444; }
        .progress-bar { height: 8px; border-radius: 4px; }
    </style>
</head>
<body>
<div class="flag-header"></div>

<nav class="navbar">
    <div class="container">
        <a class="navbar-brand text-success" href="../index.html">SmartIntern Kenya</a>
        <a href="../institution/dashboard.html" class="btn btn-outline-success">← Back</a>
    </div>
</nav>

<div class="container">
    <h1 class="text-white mb-4">📊 Placement Predictions</h1>
    
    <!-- Forecast Card -->
    <div class="stat-card">
        <h3 class="text-white">Next Month Forecast</h3>
        <div class="row">
            <div class="col-md-4">
                <h2 class="high"><?= $forecast['next_month'] ?></h2>
                <p>Expected Placements</p>
            </div>
            <div class="col-md-4">
                <h2 class="high"><?= $forecast['confidence'] ?>%</h2>
                <p>Confidence Level</p>
            </div>
        </div>
    </div>
    
    <!-- Faculty Stats -->
    <h3 class="text-white mt-4">Placement by Faculty</h3>
    <div class="row">
        <?php foreach($facultyStats as $faculty => $stats): ?>
        <div class="col-md-4">
            <div class="stat-card">
                <h4><?= $faculty ?></h4>
                <p>Students: <?= $stats['student_count'] ?></p>
                <p>Avg CGPA: <?= $stats['avg_cgpa'] ?></p>
                <p>Placement Rate: <span class="high"><?= $stats['placement_rate'] ?>%</span></p>
                <div class="progress">
                    <div class="progress-bar bg-success" style="width: <?= $stats['placement_rate'] ?>%"></div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    
    <!-- Individual Predictions -->
    <h3 class="text-white mt-4">Student Placement Predictions</h3>
    <table class="table table-dark">
        <thead>
            <tr>
                <th>Student</th>
                <th>University</th>
                <th>CGPA</th>
                <th>Skills</th>
                <th>Probability</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($predictions as $pred): ?>
            <tr>
                <td><?= $pred['student']['name'] ?></td>
                <td><?= $pred['student']['university'] ?></td>
                <td><?= $pred['student']['cgpa'] ?></td>
                <td><?= substr($pred['student']['skills'], 0, 30) ?>...</td>
                <td>
                    <span class="<?= $pred['probability'] >= 70 ? 'high' : ($pred['probability'] >= 40 ? 'medium' : 'low') ?>">
                        <?= $pred['probability'] ?>%
                    </span>
                </td>
                <td><span class="badge bg-<?= $pred['probability'] >= 70 ? 'success' : ($pred['probability'] >= 40 ? 'warning' : 'danger') ?>">
                    <?= $pred['status'] ?>
                </span></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
</body>
</html>