<?php
/**
 * MACHINE LEARNING ANALYTICS ENGINE
 * Pure PHP implementation - No Python required
 */

class MLAnalyticsEngine {
    private $conn;
    
    public function __construct($db_connection) {
        $this->conn = $db_connection;
    }
    
    /**
     * Predict placement probability for a student
     * Uses weighted logistic regression
     */
    public function predictPlacementProbability($student) {
        $weights = [
            'cgpa' => 0.35,
            'skills' => 0.30,
            'year' => 0.20,
            'applications' => 0.15
        ];
        
        // CGPA score (normalized to 0-100)
        $cgpaScore = ($student['cgpa'] / 4.0) * 100;
        
        // Skills score (based on number of skills)
        $skillCount = count(explode(',', $student['skills'] ?? ''));
        $skillsScore = min(100, $skillCount * 12.5);
        
        // Year score (final year students have higher chance)
        $yearScore = ($student['year'] / 4) * 100;
        
        // Applications score
        $appCount = $this->getApplicationCount($student['id']);
        $appScore = min(100, $appCount * 10);
        
        // Weighted average
        $probability = 
            ($cgpaScore * $weights['cgpa']) +
            ($skillsScore * $weights['skills']) +
            ($yearScore * $weights['year']) +
            ($appScore * $weights['applications']);
        
        return round($probability, 2);
    }
    
    /**
     * Predict expected salary for a student
     * Uses linear regression
     */
    public function predictSalary($student) {
        $baseSalary = 25000;
        
        // CGPA impact
        $cgpaBonus = ($student['cgpa'] - 2.0) * 15000;
        
        // Skills impact
        $skillCount = count(explode(',', $student['skills'] ?? ''));
        $skillsBonus = $skillCount * 2000;
        
        // University premium
        $uniPremium = $this->getUniversityPremium($student['university']);
        
        // Year impact
        $yearBonus = $student['year'] * 3000;
        
        $predicted = $baseSalary + $cgpaBonus + $skillsBonus + $uniPremium + $yearBonus;
        
        return round($predicted, -3);
    }
    
    /**
     * Detect at-risk students
     * Uses decision tree logic
     */
    public function detectAtRiskStudents($institution = null) {
        $query = "SELECT * FROM students";
        if ($institution) {
            $query .= " WHERE university LIKE '%$institution%'";
        }
        $result = $this->conn->query($query);
        $atRisk = [];
        
        while ($student = $result->fetch_assoc()) {
            $riskFactors = [];
            $riskScore = 0;
            
            // Low CGPA
            if ($student['cgpa'] < 2.5) {
                $riskFactors[] = "Very Low CGPA";
                $riskScore += 35;
            } elseif ($student['cgpa'] < 3.0) {
                $riskFactors[] = "Low CGPA";
                $riskScore += 20;
            }
            
            // Few skills
            $skillCount = count(explode(',', $student['skills'] ?? ''));
            if ($skillCount < 3) {
                $riskFactors[] = "Limited Skills";
                $riskScore += 30;
            } elseif ($skillCount < 5) {
                $riskFactors[] = "Moderate Skills";
                $riskScore += 15;
            }
            
            // No applications
            $appCount = $this->getApplicationCount($student['id']);
            if ($appCount == 0) {
                $riskFactors[] = "No Applications";
                $riskScore += 35;
            } elseif ($appCount < 3) {
                $riskFactors[] = "Few Applications";
                $riskScore += 15;
            }
            
            if ($riskScore > 40) {
                $probability = $this->predictPlacementProbability($student);
                $atRisk[] = [
                    'student' => $student,
                    'risk_score' => $riskScore,
                    'risk_factors' => $riskFactors,
                    'placement_probability' => $probability,
                    'predicted_salary' => $this->predictSalary($student)
                ];
            }
        }
        
        // Sort by risk score
        usort($atRisk, function($a, $b) {
            return $b['risk_score'] <=> $a['risk_score'];
        });
        
        return $atRisk;
    }
    
    /**
     * Analyze hiring trends by industry
     */
    public function analyzeHiringTrends() {
        $query = "SELECT 
                    c.industry,
                    COUNT(j.id) as job_count,
                    AVG(j.salary) as avg_salary,
                    COUNT(DISTINCT a.id) as applications
                  FROM companies c
                  LEFT JOIN jobs j ON c.id = j.company_id
                  LEFT JOIN applications a ON j.id = a.job_id
                  GROUP BY c.industry
                  ORDER BY job_count DESC";
        
        $result = $this->conn->query($query);
        $trends = [];
        
        while ($row = $result->fetch_assoc()) {
            $trends[] = $row;
        }
        
        return $trends;
    }
    
    /**
     * Get skill demand analysis
     */
    public function analyzeSkillDemand() {
        $query = "SELECT requirements FROM jobs";
        $result = $this->conn->query($query);
        $skillCounts = [];
        
        while ($row = $result->fetch_assoc()) {
            $skills = explode(',', $row['requirements']);
            foreach ($skills as $skill) {
                $skill = trim(strtolower($skill));
                if (!empty($skill)) {
                    $skillCounts[$skill] = ($skillCounts[$skill] ?? 0) + 1;
                }
            }
        }
        
        arsort($skillCounts);
        return array_slice($skillCounts, 0, 10);
    }
    
    /**
     * Predict next month's applications
     */
    public function predictNextMonth() {
        $query = "SELECT 
                    MONTH(created_at) as month,
                    COUNT(*) as count
                  FROM applications
                  WHERE created_at > DATE_SUB(NOW(), INTERVAL 3 MONTH)
                  GROUP BY MONTH(created_at)";
        
        $result = $this->conn->query($query);
        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[$row['month']] = $row['count'];
        }
        
        // Simple moving average
        $values = array_values($data);
        if (count($values) >= 2) {
            $avg = array_sum($values) / count($values);
            $trend = ($values[count($values)-1] - $values[0]) / count($values);
            $prediction = round($avg + $trend);
        } else {
            $prediction = 100;
        }
        
        return [
            'prediction' => $prediction,
            'confidence' => min(85, 50 + (count($values) * 10))
        ];
    }
    
    private function getApplicationCount($studentId) {
        $query = "SELECT COUNT(*) as count FROM applications WHERE student_id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $studentId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc()['count'];
    }
    
    private function getUniversityPremium($university) {
        $premiums = [
            'University of Nairobi' => 8000,
            'Strathmore University' => 10000,
            'JKUAT' => 5000,
            'Kenyatta University' => 3000,
            'Moi University' => 2000
        ];
        
        foreach ($premiums as $uni => $premium) {
            if (strpos($university, $uni) !== false) {
                return $premium;
            }
        }
        return 0;
    }
}
?>