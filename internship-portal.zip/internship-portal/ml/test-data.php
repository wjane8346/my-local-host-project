<?php
require_once '../includes/db_connect.php';
require_once 'analytics-engine.php';

$ml = new MLAnalyticsEngine($conn);

// Test with Wendy Jane
$query = "SELECT * FROM students WHERE id = 1";
$student = $conn->query($query)->fetch_assoc();

if ($student) {
    echo "<h1>🧪 ML Analytics Test</h1>";
    echo "<h2>Testing with: " . $student['name'] . "</h2>";
    
    // Test placement prediction
    $prob = $ml->predictPlacementProbability($student);
    echo "<p>Placement Probability: <strong>$prob%</strong></p>";
    
    // Test salary prediction
    $salary = $ml->predictExpectedSalary($student);
    echo "<p>Expected Salary: <strong>KSh " . number_format($salary) . "</strong></p>";
    
    // Test company recommendations
    $recommendations = $ml->recommendCompanies(1);
    echo "<h3>Recommended Companies:</h3>";
    foreach($recommendations as $rec) {
        echo "<p>🏢 " . $rec['company']['name'] . " - Match: " . $rec['match_score'] . "%</p>";
    }
}
?>