<?php
require_once '../includes/db_connect.php';
require_once '../includes/auth.php';
requireInstitution();
require_once 'analytics-engine.php';

$ml = new MLAnalyticsEngine($conn);
$institution = getCurrentUser($conn);
$atRisk = $ml->detectAtRiskStudents($institution['name']);
$trends = $ml->analyzeHiringTrends();
$skills = $ml->analyzeSkillDemand();
$prediction = $ml->predictNextMonth();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ML Analytics - SmartIntern Kenya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="../assets/css/style.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="flag-header"></div>
    
    <nav class="navbar navbar-expand-lg">
        <div class="container">
            <a class="navbar-brand" href="../index.php">
                <i class="fas fa-shield-alt me-2"></i>SmartIntern Kenya
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../index.php">Home</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle active" href="#" role="button" data-bs-toggle="dropdown">
                            Institution Portal
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="dashboard.php">Dashboard</a></li>
                            <li><a class="dropdown-item" href="students.php">Student Records</a></li>
                            <li><a class="dropdown-item active" href="ml-analytics.php">ML Insights</a></li>
                        </ul>
                    </li>
                </ul>
                <div class="d-flex align-items-center gap-3">
                    <span class="fw-medium"><?= $institution['name'] ?></span>
                    <a href="../logout.php" class="btn btn-outline-danger btn-sm">Logout</a>
                </div>
            </div>
        </div>
    </nav>
    
    <div class="container py-4">
        <h1 class="mb-4">🤖 Machine Learning Analytics</h1>
        
        <!-- Prediction Cards -->
        <div class="row g-4 mb-4">
            <div class="col-md-4">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <div class="stat-info">
                        <h3><?= $prediction['prediction'] ?></h3>
                        <p>Next Month's Applications</p>
                        <small class="text-success">Confidence: <?= $prediction['confidence'] ?>%</small>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-exclamation-triangle" style="color: var(--warning);"></i>
                    </div>
                    <div class="stat-info">
                        <h3><?= count($atRisk) ?></h3>
                        <p>At-Risk Students</p>
                        <small class="text-warning">Need intervention</small>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-trend-up"></i>
                    </div>
                    <div class="stat-info">
                        <h3><?= $trends[0]['industry'] ?? 'Tech' ?></h3>
                        <p>Top Hiring Sector</p>
                        <small><?= $trends[0]['job_count'] ?? 0 ?> jobs</small>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="row">
            <!-- At-Risk Students -->
            <div class="col-lg-6 mb-4">
                <div class="card h-100">
                    <div class="card-header">
                        <h5 class="mb-0">🚨 Students Needing Intervention</h5>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($atRisk)): ?>
                            <?php foreach(array_slice($atRisk, 0, 5) as $risk): ?>
                            <div class="mb-3 pb-2 border-bottom">
                                <div class="d-flex justify-content-between">
                                    <h6><?= $risk['student']['name'] ?></h6>
                                    <span class="badge badge-danger">Risk: <?= $risk['risk_score'] ?>%</span>
                                </div>
                                <p class="small mb-1"><?= $risk['student']['course'] ?> • Year <?= $risk['student']['year'] ?></p>
                                <p class="small mb-2">
                                    <?php foreach($risk['risk_factors'] as $factor): ?>
                                        <span class="badge bg-warning text-dark me-1"><?= $factor ?></span>
                                    <?php endforeach; ?>
                                </p>
                                <div class="d-flex justify-content-between small">
                                    <span>Placement Probability: <?= $risk['placement_probability'] ?>%</span>
                                    <span>Predicted Salary: KSh <?= number_format($risk['predicted_salary']) ?></span>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p class="text-muted">No at-risk students detected.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- Skill Demand -->
            <div class="col-lg-6 mb-4">
                <div class="card h-100">
                    <div class="card-header">
                        <h5 class="mb-0">📊 Top Skills in Demand</h5>
                    </div>
                    <div class="card-body">
                        <?php 
                        $colors = ['#059669', '#2563eb', '#d97706', '#b91c1c', '#7c3aed'];
                        $i = 0;
                        foreach($skills as $skill => $count): 
                        ?>
                        <div class="mb-3">
                            <div class="d-flex justify-content-between">
                                <span><?= ucfirst($skill) ?></span>
                                <span class="fw-bold"><?= $count ?> jobs</span>
                            </div>
                            <div class="progress" style="height: 8px;">
                                <?php $percent = ($count / max(array_values($skills))) * 100; ?>
                                <div class="progress-bar" style="width: <?= $percent ?>%; background: <?= $colors[$i % 5] ?>"></div>
                            </div>
                        </div>
                        <?php 
                        $i++;
                        endforeach; 
                        ?>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Industry Trends Chart -->
        <div class="card mt-4">
            <div class="card-header">
                <h5 class="mb-0">📈 Hiring by Industry</h5>
            </div>
            <div class="card-body">
                <canvas id="industryChart" style="height: 300px;"></canvas>
            </div>
        </div>
    </div>
    
    <footer class="footer">
        <div class="container text-center">
            <p class="small mb-0">&copy; 2026 SmartIntern Kenya. All rights reserved.</p>
        </div>
    </footer>
    
    <script>
        const ctx = document.getElementById('industryChart').getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: <?= json_encode(array_column($trends, 'industry')) ?>,
                datasets: [{
                    label: 'Jobs Available',
                    data: <?= json_encode(array_column($trends, 'job_count')) ?>,
                    backgroundColor: '#059669',
                    borderRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });
    </script>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>