<?php
require_once '../includes/db_connect.php';
require_once 'analytics-engine.php';

$ml = new MLAnalyticsEngine($conn);
$industryTrends = $ml->analyzeHiringTrends();
$locationTrends = $ml->analyzeLocationTrends();
$monthlyTrends = $ml->getMonthlyTrends();
$skillDemand = $ml->analyzeSkillDemand();
$industryGrowth = $ml->calculateIndustryGrowth();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trend Analysis - SmartIntern Kenya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { background: #0f172a; color: #e2e8f0; font-family: Arial, sans-serif; }
        .flag-header { height: 4px; background: linear-gradient(90deg, black 33%, #BB2B1F 33%, #BB2B1F 66%, #006233 66%); }
        .navbar { background: #1e293b; padding: 1rem; }
        .container { max-width: 1200px; margin: 2rem auto; padding: 0 20px; }
        .trend-card { background: #1e293b; border: 1px solid #334155; border-radius: 10px; padding: 1.5rem; margin-bottom: 1.5rem; }
        .chart-container { height: 300px; margin: 20px 0; }
        .growth-positive { color: #4ade80; }
        .growth-negative { color: #ef4444; }
    </style>
</head>
<body>
<div class="flag-header"></div>

<nav class="navbar">
    <div class="container">
        <a class="navbar-brand text-success" href="../index.html">SmartIntern Kenya</a>
        <a href="../institution/dashboard.html" class="btn btn-outline-success">← Back</a>
    </div>
</nav>

<div class="container">
    <h1 class="text-white mb-4">📈 Hiring Trend Analysis</h1>
    
    <!-- Industry Trends -->
    <div class="trend-card">
        <h3 class="text-white mb-3">Hiring by Industry</h3>
        <div class="chart-container">
            <canvas id="industryChart"></canvas>
        </div>
        <table class="table table-dark mt-3">
            <thead>
                <tr>
                    <th>Industry</th>
                    <th>Job Count</th>
                    <th>Avg CGPA Required</th>
                    <th>Growth</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($industryTrends as $trend): ?>
                <tr>
                    <td><?= $trend['industry'] ?></td>
                    <td><?= $trend['job_count'] ?></td>
                    <td><?= round($trend['avg_cgpa_req'], 2) ?></td>
                    <td class="<?= ($industryGrowth[$trend['industry']]['growth'] ?? 0) > 0 ? 'growth-positive' : 'growth-negative' ?>">
                        <?= ($industryGrowth[$trend['industry']]['growth'] ?? 0) ?>%
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    
    <!-- Location Trends -->
    <div class="trend-card">
        <h3 class="text-white mb-3">Hiring by Location</h3>
        <div class="row">
            <?php foreach($locationTrends as $location): ?>
            <div class="col-md-4 mb-3">
                <div class="bg-dark p-3 rounded">
                    <h5 class="text-success"><?= $location['location'] ?></h5>
                    <p><?= $location['job_count'] ?> jobs available</p>
                    <small class="text-muted">Min CGPA: <?= round($location['avg_cgpa'], 2) ?></small>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    
    <!-- Monthly Trends -->
    <div class="trend-card">
        <h3 class="text-white mb-3">Monthly Hiring Trends</h3>
        <div class="chart-container">
            <canvas id="monthlyChart"></canvas>
        </div>
    </div>
    
    <!-- Top Skills in Demand -->
    <div class="trend-card">
        <h3 class="text-white mb-3">Top Skills in Demand</h3>
        <div class="row">
            <?php 
            $colors = ['#4ade80', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6'];
            $i = 0;
            foreach($skillDemand as $skill => $count): 
            ?>
            <div class="col-md-6 mb-2">
                <div class="d-flex justify-content-between">
                    <span><?= ucfirst($skill) ?></span>
                    <span class="text-success"><?= $count ?> jobs</span>
                </div>
                <div class="progress mb-2">
                    <div class="progress-bar" style="width: <?= min(100, $count * 10) ?>%; background: <?= $colors[$i % 5] ?>"></div>
                </div>
            </div>
            <?php 
            $i++;
            endforeach; 
            ?>
        </div>
    </div>
</div>

<script>
    // Industry Chart
    new Chart(document.getElementById('industryChart'), {
        type: 'bar',
        data: {
            labels: <?= json_encode(array_column($industryTrends, 'industry')) ?>,
            datasets: [{
                label: 'Jobs Available',
                data: <?= json_encode(array_column($industryTrends, 'job_count')) ?>,
                backgroundColor: '#4ade80'
            }]
        },
        options: {
            plugins: { legend: { display: false } },
            scales: { y: { beginAtZero: true, grid: { color: '#334155' } } }
        }
    });

    // Monthly Chart
    new Chart(document.getElementById('monthlyChart'), {
        type: 'line',
        data: {
            labels: <?= json_encode(array_column($monthlyTrends, 'month')) ?>,
            datasets: [{
                label: 'Jobs Posted',
                data: <?= json_encode(array_column($monthlyTrends, 'job_count')) ?>,
                borderColor: '#4ade80',
                backgroundColor: 'rgba(74, 222, 128, 0.1)',
                tension: 0.4
            }]
        },
        options: {
            scales: { y: { beginAtZero: true, grid: { color: '#334155' } } }
        }
    });
</script>
</body>
</html>