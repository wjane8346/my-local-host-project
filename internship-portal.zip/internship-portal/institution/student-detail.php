<?php
require_once '../includes/db_connect.php';
require_once '../includes/auth.php';
requireInstitution();

$institution = getCurrentUser($conn);
$student_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Get student details
$query = "SELECT * FROM students WHERE id = ? AND university LIKE ?";
$univ_pattern = "%{$institution['name']}%";
$stmt = $conn->prepare($query);
$stmt->bind_param("is", $student_id, $univ_pattern);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();

if (!$student) {
    header("Location: students.php");
    exit();
}

// Get applications
$apps_query = "SELECT a.*, j.title, j.company_id, j.location, j.salary, c.name as company_name
               FROM applications a
               JOIN jobs j ON a.job_id = j.id
               JOIN companies c ON j.company_id = c.id
               WHERE a.student_id = ?
               ORDER BY a.applied_date DESC";
$stmt = $conn->prepare($apps_query);
$stmt->bind_param("i", $student_id);
$stmt->execute();
$applications = $stmt->get_result();

// Get stats
$stats_query = "SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status IN ('shortlisted', 'interview', 'accepted') THEN 1 ELSE 0 END) as successes
                FROM applications WHERE student_id = ?";
$stmt = $conn->prepare($stats_query);
$stmt->bind_param("i", $student_id);
$stmt->execute();
$stats = $stmt->get_result()->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($student['name']) ?> - Student Details</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #0f172a;
            color: #e2e8f0;
        }
        
        .flag-header {
            height: 4px;
            background: linear-gradient(90deg, 
                #000000 0%, #000000 33.33%,
                #b91c1c 33.33%, #b91c1c 66.66%,
                #059669 66.66%, #059669 100%);
        }
        
        .navbar {
            background: #1e293b;
            border-bottom: 1px solid #334155;
            padding: 1rem 0;
        }
        
        .container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        .navbar-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .navbar-brand {
            font-weight: 700;
            font-size: 1.3rem;
            color: #4ade80;
            text-decoration: none;
        }
        
        .btn-back {
            color: #4ade80;
            text-decoration: none;
            padding: 8px 20px;
            border: 1px solid #4ade80;
            border-radius: 6px;
        }
        
        .profile-header {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 12px;
            padding: 30px;
            margin: 30px 0;
            display: flex;
            align-items: center;
            gap: 30px;
        }
        
        .profile-avatar {
            width: 100px;
            height: 100px;
            background: linear-gradient(135deg, #059669, #4ade80);
            border-radius: 50px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 2.5rem;
            font-weight: bold;
        }
        
        .profile-info h1 {
            color: white;
            margin-bottom: 5px;
        }
        
        .profile-meta {
            display: flex;
            gap: 20px;
            margin-top: 10px;
            color: #94a3b8;
        }
        
        .profile-meta i {
            color: #4ade80;
            margin-right: 5px;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 10px;
            padding: 20px;
            text-align: center;
        }
        
        .stat-number {
            font-size: 2rem;
            font-weight: 700;
            color: #4ade80;
        }
        
        .section {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
        }
        
        .section h2 {
            color: white;
            font-size: 1.3rem;
            margin-bottom: 20px;
        }
        
        .skills-list {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }
        
        .skill-tag {
            background: #0f172a;
            color: #94a3b8;
            padding: 5px 15px;
            border-radius: 20px;
            border: 1px solid #334155;
        }
        
        .application-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 0;
            border-bottom: 1px solid #334155;
        }
        
        .application-item:last-child {
            border-bottom: none;
        }
        
        .company-name {
            color: #4ade80;
        }
        
        .status-badge {
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .status-pending { background: #fef3c7; color: #92400e; }
        .status-shortlisted { background: #d1fae5; color: #065f46; }
        .status-interview { background: #e0f2fe; color: #0369a1; }
        
        .footer {
            background: #1e293b;
            border-top: 1px solid #334155;
            padding: 30px 0;
            margin-top: 50px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="flag-header"></div>
    
    <nav class="navbar">
        <div class="container navbar-content">
            <a href="../index.php" class="navbar-brand">
                <i class="fas fa-shield-alt"></i>SmartIntern Kenya
            </a>
            
            <a href="students.php" class="btn-back">
                <i class="fas fa-arrow-left me-2"></i>Back to Students
            </a>
        </div>
    </nav>
    
    <div class="container">
        <!-- Profile Header -->
        <div class="profile-header">
            <div class="profile-avatar">
                <?= substr($student['name'], 0, 1) ?>
            </div>
            <div class="profile-info">
                <h1><?= htmlspecialchars($student['name']) ?></h1>
                <p><?= htmlspecialchars($student['course']) ?> • <?= htmlspecialchars($student['university']) ?></p>
                <div class="profile-meta">
                    <span><i class="fas fa-graduation-cap"></i> Year <?= $student['year'] ?></span>
                    <span><i class="fas fa-star"></i> CGPA: <?= $student['cgpa'] ?></span>
                    <span><i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($student['location']) ?></span>
                </div>
            </div>
        </div>
        
        <!-- Stats -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-number"><?= $stats['total'] ?></div>
                <div>Total Applications</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?= $stats['successes'] ?></div>
                <div>Successful</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?= $stats['total'] > 0 ? round(($stats['successes'] / $stats['total']) * 100) : 0 ?>%</div>
                <div>Success Rate</div>
            </div>
        </div>
        
        <!-- Skills -->
        <div class="section">
            <h2>Skills</h2>
            <div class="skills-list">
                <?php 
                $skills = explode(',', $student['skills']);
                foreach($skills as $skill): 
                    if(trim($skill)):
                ?>
                    <span class="skill-tag"><?= trim($skill) ?></span>
                <?php 
                    endif;
                endforeach; 
                ?>
            </div>
        </div>
        
        <!-- Bio -->
        <?php if (!empty($student['bio'])): ?>
        <div class="section">
            <h2>About</h2>
            <p><?= nl2br(htmlspecialchars($student['bio'])) ?></p>
        </div>
        <?php endif; ?>
        
        <!-- Applications -->
        <div class="section">
            <h2>Application History</h2>
            <?php if ($applications && $applications->num_rows > 0): ?>
                <?php while($app = $applications->fetch_assoc()): ?>
                    <div class="application-item">
                        <div>
                            <div style="font-weight: 500; color: white;"><?= htmlspecialchars($app['title']) ?></div>
                            <div class="company-name"><?= htmlspecialchars($app['company_name']) ?></div>
                            <div style="color: #94a3b8; font-size: 0.9rem;">
                                Applied: <?= date('M d, Y', strtotime($app['applied_date'])) ?>
                            </div>
                        </div>
                        <div>
                            <?php
                            $statusClass = '';
                            switch($app['status']) {
                                case 'pending': $statusClass = 'status-pending'; break;
                                case 'shortlisted': $statusClass = 'status-shortlisted'; break;
                                case 'interview': $statusClass = 'status-interview'; break;
                                default: $statusClass = 'status-pending';
                            }
                            ?>
                            <span class="status-badge <?= $statusClass ?>">
                                <?= ucfirst($app['status']) ?>
                            </span>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p style="color: #94a3b8;">No applications yet.</p>
            <?php endif; ?>
        </div>
    </div>
    
    <footer class="footer">
        <div class="container">
            <p>&copy; 2026 SmartIntern Kenya</p>
        </div>
    </footer>
</body>
</html>