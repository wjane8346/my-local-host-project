<?php
require_once '../includes/db_connect.php';
require_once '../includes/auth.php';
requireInstitution();

$institution = getCurrentUser($conn);

// Get companies with placement stats
$query = "SELECT c.*, 
                 COUNT(DISTINCT a.id) as total_hires,
                 COUNT(DISTINCT j.id) as total_jobs,
                 COUNT(DISTINCT s.id) as students_placed
          FROM companies c
          LEFT JOIN jobs j ON c.id = j.company_id
          LEFT JOIN applications a ON j.id = a.job_id AND a.status IN ('shortlisted', 'interview', 'accepted')
          LEFT JOIN students s ON a.student_id = s.id AND s.university LIKE ?
          GROUP BY c.id
          ORDER BY total_hires DESC";
$univ_pattern = "%{$institution['name']}%";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $univ_pattern);
$stmt->execute();
$companies = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Partner Companies - SmartIntern Kenya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #0f172a;
            color: #e2e8f0;
        }
        
        .flag-header {
            height: 4px;
            background: linear-gradient(90deg, 
                #000000 0%, #000000 33.33%,
                #b91c1c 33.33%, #b91c1c 66.66%,
                #059669 66.66%, #059669 100%);
        }
        
        .navbar {
            background: #1e293b;
            border-bottom: 1px solid #334155;
            padding: 1rem 0;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        .navbar-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .navbar-brand {
            font-weight: 700;
            font-size: 1.3rem;
            color: #4ade80;
            text-decoration: none;
        }
        
        .nav-links {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .nav-links a {
            color: #cbd5e1;
            text-decoration: none;
        }
        
        .nav-links a:hover {
            color: #4ade80;
        }
        
        .nav-links a.active {
            color: #4ade80;
            border-bottom: 2px solid #4ade80;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
            color: #94a3b8;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #059669, #4ade80);
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
        }
        
        .btn-logout {
            color: #ef4444;
            text-decoration: none;
            padding: 8px 15px;
            border: 1px solid #ef4444;
            border-radius: 6px;
        }
        
        .page-header {
            margin: 30px 0;
        }
        
        .page-header h1 {
            color: white;
            font-size: 2rem;
        }
        
        .companies-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .company-card {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 12px;
            padding: 25px;
            transition: all 0.3s;
        }
        
        .company-card:hover {
            border-color: #4ade80;
        }
        
        .company-header {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 15px;
        }
        
        .company-logo {
            width: 50px;
            height: 50px;
            background: #0f172a;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #4ade80;
            font-size: 1.3rem;
            border: 1px solid #334155;
        }
        
        .company-header h3 {
            color: white;
            margin: 0;
        }
        
        .company-industry {
            color: #4ade80;
            font-size: 0.9rem;
            margin-bottom: 15px;
        }
        
        .stats-row {
            display: flex;
            justify-content: space-between;
            margin: 15px 0;
        }
        
        .stat-item {
            text-align: center;
        }
        
        .stat-value {
            font-size: 1.3rem;
            font-weight: 700;
            color: #4ade80;
        }
        
        .stat-label {
            color: #94a3b8;
            font-size: 0.8rem;
        }
        
        .btn-view {
            color: #4ade80;
            text-decoration: none;
            border: 1px solid #4ade80;
            padding: 8px 15px;
            border-radius: 6px;
            display: inline-block;
            width: 100%;
            text-align: center;
        }
        
        .btn-view:hover {
            background: #4ade80;
            color: #0f172a;
        }
        
        .footer {
            background: #1e293b;
            border-top: 1px solid #334155;
            padding: 30px 0;
            margin-top: 50px;
            text-align: center;
        }
        
        @media (max-width: 768px) {
            .companies-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="flag-header"></div>
    
    <nav class="navbar">
        <div class="container navbar-content">
            <a href="../index.php" class="navbar-brand">
                <i class="fas fa-shield-alt"></i>SmartIntern Kenya
            </a>
            
            <div class="nav-links">
                <a href="dashboard.php">Dashboard</a>
                <a href="students.php">Students</a>
                <a href="companies.php" class="active">Companies</a>
                <a href="reports.php">Reports</a>
                <a href="ml-analytics.php">ML Insights</a>
                
                <div class="user-info">
                    <div class="user-avatar">
                        <?= substr($institution['name'], 0, 1) ?>
                    </div>
                    <span><?= htmlspecialchars($institution['name']) ?></span>
                </div>
                
                <a href="../logout.php" class="btn-logout">Logout</a>
            </div>
        </div>
    </nav>
    
    <div class="container">
        <div class="page-header">
            <h1>Partner Companies</h1>
        </div>
        
        <div class="companies-grid">
            <?php if ($companies && $companies->num_rows > 0): ?>
                <?php while($company = $companies->fetch_assoc()): ?>
                    <div class="company-card">
                        <div class="company-header">
                            <div class="company-logo">
                                <?= substr($company['name'], 0, 1) ?>
                            </div>
                            <div>
                                <h3><?= htmlspecialchars($company['name']) ?></h3>
                                <div class="company-industry"><?= htmlspecialchars($company['industry']) ?></div>
                            </div>
                        </div>
                        
                        <div class="stats-row">
                            <div class="stat-item">
                                <div class="stat-value"><?= $company['total_jobs'] ?></div>
                                <div class="stat-label">Jobs</div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-value"><?= $company['students_placed'] ?></div>
                                <div class="stat-label">Students</div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-value"><?= $company['total_hires'] ?></div>
                                <div class="stat-label">Placements</div>
                            </div>
                        </div>
                        
                        <p style="color: #94a3b8; margin: 15px 0;">
                            <i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($company['location']) ?>
                        </p>
                        
                        <a href="company-details.php?id=<?= $company['id'] ?>" class="btn-view">View Details</a>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p style="color: #94a3b8; text-align: center;">No partner companies yet.</p>
            <?php endif; ?>
        </div>
    </div>
    
    <footer class="footer">
        <div class="container">
            <p>&copy; 2026 SmartIntern Kenya</p>
        </div>
    </footer>
</body>
</html>