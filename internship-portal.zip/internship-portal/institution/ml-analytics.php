<?php
require_once '../includes/db_connect.php';
require_once '../includes/auth.php';
requireInstitution();

// Simple ML analytics without external dependencies
$institution = getCurrentUser($conn);
$univ_pattern = "%{$institution['name']}%";

// Get at-risk students (simple version)
$at_risk = [];
$query = "SELECT * FROM students WHERE university LIKE ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $univ_pattern);
$stmt->execute();
$students = $stmt->get_result();

while ($student = $students->fetch_assoc()) {
    $risk_score = 0;
    $factors = [];
    
    if ($student['cgpa'] < 2.5) {
        $risk_score += 30;
        $factors[] = "Low CGPA";
    }
    
    $skill_count = count(explode(',', $student['skills'] ?? ''));
    if ($skill_count < 3) {
        $risk_score += 30;
        $factors[] = "Few skills";
    }
    
    // Check applications
    $app_query = "SELECT COUNT(*) as count FROM applications WHERE student_id = ?";
    $app_stmt = $conn->prepare($app_query);
    $app_stmt->bind_param("i", $student['id']);
    $app_stmt->execute();
    $app_count = $app_stmt->get_result()->fetch_assoc()['count'];
    
    if ($app_count == 0) {
        $risk_score += 40;
        $factors[] = "No applications";
    }
    
    if ($risk_score > 40) {
        $at_risk[] = [
            'student' => $student,
            'risk_score' => $risk_score,
            'risk_factors' => $factors,
            'placement_probability' => 100 - $risk_score
        ];
    }
}

// Get top skills in demand
$skills_demand = [];
$jobs_query = "SELECT requirements FROM jobs";
$jobs_result = $conn->query($jobs_query);
while ($job = $jobs_result->fetch_assoc()) {
    $skills = explode(',', $job['requirements']);
    foreach ($skills as $skill) {
        $skill = trim($skill);
        if ($skill) {
            $skills_demand[$skill] = ($skills_demand[$skill] ?? 0) + 1;
        }
    }
}
arsort($skills_demand);
$top_skills = array_slice($skills_demand, 0, 5, true);
?>
<!DOCTYPE html>
<html>
<head>
    <title>ML Insights - SmartIntern Kenya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #0f172a; color: white; padding: 20px; }
        .card { background: #1e293b; border: 1px solid #334155; padding: 20px; margin: 10px 0; border-radius: 10px; }
        .risk-high { color: #ef4444; }
        .risk-medium { color: #f59e0b; }
        .risk-low { color: #4ade80; }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="text-success">🤖 ML Analytics Dashboard</h1>
        
        <div class="card">
            <h2>At-Risk Students (<?= count($at_risk) ?>)</h2>
            <?php if ($at_risk): ?>
                <table class="table table-dark">
                    <thead>
                        <tr>
                            <th>Student</th>
                            <th>Course</th>
                            <th>CGPA</th>
                            <th>Risk Score</th>
                            <th>Factors</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($at_risk as $risk): ?>
                        <tr>
                            <td><?= htmlspecialchars($risk['student']['name']) ?></td>
                            <td><?= htmlspecialchars($risk['student']['course']) ?></td>
                            <td><?= $risk['student']['cgpa'] ?></td>
                            <td class="<?= $risk['risk_score'] > 70 ? 'risk-high' : ($risk['risk_score'] > 50 ? 'risk-medium' : 'risk-low') ?>">
                                <?= $risk['risk_score'] ?>%
                            </td>
                            <td><?= implode(', ', $risk['risk_factors']) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No at-risk students detected.</p>
            <?php endif; ?>
        </div>
        
        <div class="card">
            <h2>Top Skills in Demand</h2>
            <ul>
                <?php foreach($top_skills as $skill => $count): ?>
                <li><?= ucfirst($skill) ?>: <?= $count ?> jobs</li>
                <?php endforeach; ?>
            </ul>
        </div>
        
        <a href="dashboard.php" class="btn btn-success">Back to Dashboard</a>
    </div>
</body>
</html>