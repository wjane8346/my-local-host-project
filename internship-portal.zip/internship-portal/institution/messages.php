<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Messages - SmartIntern Kenya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #0f172a; color: #e2e8f0; font-family: 'Segoe UI', sans-serif; }
        .flag-header { height: 4px; background: linear-gradient(90deg, #000000 33%, #BB2B1F 33%, #BB2B1F 66%, #006233 66%); }
        .navbar { background: #1e293b; padding: 1rem 0; border-bottom: 1px solid #334155; }
        .navbar-brand { color: #4ade80 !important; font-weight: bold; }
        .container { max-width: 800px; margin: 2rem auto; padding: 0 20px; }
        .message-card { background: #1e293b; border: 1px solid #334155; border-radius: 8px; padding: 1rem; margin-bottom: 0.75rem; display: flex; justify-content: space-between; align-items: center; }
        .message-card:hover { border-color: #4ade80; }
        .badge-new { background: #4ade80; color: #0f172a; padding: 0.2rem 0.5rem; border-radius: 4px; font-size: 0.7rem; }
    </style>
</head>
<body>
<div class="flag-header"></div>

<nav class="navbar">
    <div class="container">
        <a class="navbar-brand" href="/internship-portal/index.html">SmartIntern Kenya</a>
        <a href="/internship-portal/institution/dashboard.html" class="btn btn-outline-success">← Back</a>
    </div>
</nav>

<div class="container">
    <h2 class="text-white mb-4">Messages</h2>
    
    <div class="message-card">
        <div><strong>Safaricom HR</strong><br><small class="text-muted">3 students shortlisted for interview</small></div>
        <div class="text-end"><small class="text-success">2 hours ago</small><br><span class="badge-new">New</span></div>
    </div>
    
    <div class="message-card">
        <div><strong>Wendy Jane</strong><br><small class="text-muted">I got an interview at KCB! 🎉</small></div>
        <div><small class="text-success">Yesterday</small></div>
    </div>
    
    <div class="message-card">
        <div><strong>KCB Bank</strong><br><small class="text-muted">Seeking more engineering students</small></div>
        <div><small class="text-success">2 days ago</small></div>
    </div>
    
    <div class="message-card">
        <div><strong>Career Fair 2026</strong><br><small class="text-muted">15 companies confirmed for March 15th</small></div>
        <div><small class="text-success">3 days ago</small></div>
    </div>
</div>
</body>
</html>