<?php
require_once '../includes/db_connect.php';
require_once '../includes/auth.php';
requireInstitution();

$institution = getCurrentUser($conn);
$univ_pattern = "%{$institution['name']}%";

// Get filter parameters
$year = isset($_GET['year']) ? (int)$_GET['year'] : date('Y');
$faculty = isset($_GET['faculty']) ? $_GET['faculty'] : '';
$company = isset($_GET['company']) ? (int)$_GET['company'] : 0;

// Get available years for filter
$years_query = "SELECT DISTINCT YEAR(a.created_at) as year 
                FROM applications a
                JOIN students s ON a.student_id = s.id
                WHERE s.university LIKE ? AND a.status IN ('accepted', 'completed')
                ORDER BY year DESC";
$stmt = $conn->prepare($years_query);
$stmt->bind_param("s", $univ_pattern);
$stmt->execute();
$available_years = $stmt->get_result();

// Get companies for filter
$companies_query = "SELECT DISTINCT c.id, c.name 
                    FROM companies c
                    JOIN jobs j ON c.id = j.company_id
                    JOIN applications a ON j.id = a.job_id
                    JOIN students s ON a.student_id = s.id
                    WHERE s.university LIKE ? AND a.status IN ('accepted', 'completed')
                    ORDER BY c.name";
$stmt = $conn->prepare($companies_query);
$stmt->bind_param("s", $univ_pattern);
$stmt->execute();
$companies = $stmt->get_result();

// Build main query
$query = "SELECT 
            s.id as student_id,
            s.name as student_name,
            s.course,
            s.year as student_year,
            s.cgpa,
            c.id as company_id,
            c.name as company_name,
            c.industry,
            j.id as job_id,
            j.title as job_title,
            j.salary,
            j.location,
            a.applied_date,
            a.status,
            a.created_at as placement_date
          FROM applications a
          JOIN students s ON a.student_id = s.id
          JOIN jobs j ON a.job_id = j.id
          JOIN companies c ON j.company_id = c.id
          WHERE s.university LIKE ? 
          AND a.status IN ('accepted', 'completed')";

$params = [$univ_pattern];
$types = "s";

if ($year > 0) {
    $query .= " AND YEAR(a.created_at) = ?";
    $params[] = $year;
    $types .= "i";
}

if (!empty($faculty)) {
    $query .= " AND s.course LIKE ?";
    $params[] = "%$faculty%";
    $types .= "s";
}

if ($company > 0) {
    $query .= " AND c.id = ?";
    $params[] = $company;
    $types .= "i";
}

$query .= " ORDER BY a.created_at DESC";

$stmt = $conn->prepare($query);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$placements = $stmt->get_result();

// Get summary statistics
$stats_query = "SELECT 
                COUNT(DISTINCT a.id) as total_placements,
                COUNT(DISTINCT s.id) as total_students,
                COUNT(DISTINCT c.id) as total_companies,
                AVG(j.salary) as avg_salary,
                SUM(CASE WHEN YEAR(a.created_at) = ? THEN 1 ELSE 0 END) as this_year
                FROM applications a
                JOIN students s ON a.student_id = s.id
                JOIN jobs j ON a.job_id = j.id
                JOIN companies c ON j.company_id = c.id
                WHERE s.university LIKE ? AND a.status IN ('accepted', 'completed')";
$stmt = $conn->prepare($stats_query);
$current_year = date('Y');
$stmt->bind_param("is", $current_year, $univ_pattern);
$stmt->execute();
$stats = $stmt->get_result()->fetch_assoc();

// Get monthly trends for the year
$monthly_query = "SELECT 
                  MONTH(a.created_at) as month,
                  COUNT(*) as placements
                  FROM applications a
                  JOIN students s ON a.student_id = s.id
                  WHERE s.university LIKE ? 
                  AND a.status IN ('accepted', 'completed')
                  AND YEAR(a.created_at) = ?
                  GROUP BY MONTH(a.created_at)
                  ORDER BY month";
$stmt = $conn->prepare($monthly_query);
$stmt->bind_param("si", $univ_pattern, $year);
$stmt->execute();
$monthly = $stmt->get_result();

// Initialize monthly data array
$monthly_data = array_fill(1, 12, 0);
while ($row = $monthly->fetch_assoc()) {
    $monthly_data[$row['month']] = $row['placements'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Placement Records - SmartIntern Kenya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #0f172a;
            color: #e2e8f0;
        }
        
        .flag-header {
            height: 4px;
            background: linear-gradient(90deg, 
                #000000 0%, #000000 33.33%,
                #b91c1c 33.33%, #b91c1c 66.66%,
                #059669 66.66%, #059669 100%);
        }
        
        .navbar {
            background: #1e293b;
            border-bottom: 1px solid #334155;
            padding: 1rem 0;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        .navbar-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .navbar-brand {
            font-weight: 700;
            font-size: 1.3rem;
            color: #4ade80;
            text-decoration: none;
        }
        
        .navbar-brand i {
            color: #4ade80;
        }
        
        .nav-links {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .nav-links a {
            color: #cbd5e1;
            text-decoration: none;
            padding: 5px 10px;
        }
        
        .nav-links a:hover {
            color: #4ade80;
        }
        
        .nav-links a.active {
            color: #4ade80;
            border-bottom: 2px solid #4ade80;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
            color: #94a3b8;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #059669, #4ade80);
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
        }
        
        .btn-logout {
            color: #ef4444;
            text-decoration: none;
            padding: 8px 15px;
            border: 1px solid #ef4444;
            border-radius: 6px;
        }
        
        .page-header {
            margin: 30px 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .page-header h1 {
            color: white;
            font-size: 2rem;
        }
        
        .filter-section {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 30px;
        }
        
        .filter-form {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr auto auto;
            gap: 15px;
            align-items: end;
        }
        
        .form-group {
            margin-bottom: 0;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #94a3b8;
            font-size: 0.9rem;
        }
        
        .form-control {
            width: 100%;
            padding: 8px 12px;
            background: #0f172a;
            border: 1px solid #334155;
            border-radius: 6px;
            color: white;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #4ade80;
        }
        
        .btn-filter {
            background: #4ade80;
            color: #0f172a;
            border: none;
            padding: 8px 20px;
            border-radius: 6px;
            font-weight: 600;
            cursor: pointer;
        }
        
        .btn-reset {
            background: transparent;
            color: #94a3b8;
            border: 1px solid #334155;
            padding: 8px 20px;
            border-radius: 6px;
            text-decoration: none;
            display: inline-block;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 12px;
            padding: 25px;
        }
        
        .stat-number {
            font-size: 2rem;
            font-weight: 700;
            color: #4ade80;
            margin-bottom: 5px;
        }
        
        .stat-label {
            color: #94a3b8;
        }
        
        .stat-sub {
            font-size: 0.8rem;
            color: #4ade80;
            margin-top: 5px;
        }
        
        .chart-container {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 30px;
        }
        
        .chart-box {
            height: 300px;
        }
        
        .table-container {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 12px;
            overflow: hidden;
            margin-bottom: 30px;
        }
        
        .table-header {
            display: grid;
            grid-template-columns: 2fr 1.5fr 1.5fr 1fr 1fr 1fr 0.5fr;
            background: #0f172a;
            padding: 15px;
            color: #4ade80;
            font-weight: 600;
        }
        
        .table-row {
            display: grid;
            grid-template-columns: 2fr 1.5fr 1.5fr 1fr 1fr 1fr 0.5fr;
            padding: 15px;
            border-bottom: 1px solid #334155;
            align-items: center;
        }
        
        .table-row:hover {
            background: #0f172a;
        }
        
        .student-name {
            color: white;
            font-weight: 500;
        }
        
        .company-name {
            color: #4ade80;
        }
        
        .badge-salary {
            background: #4ade80;
            color: #0f172a;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .btn-view {
            color: #4ade80;
            text-decoration: none;
        }
        
        .export-buttons {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
            margin-bottom: 20px;
        }
        
        .btn-export {
            background: transparent;
            border: 1px solid #4ade80;
            color: #4ade80;
            padding: 8px 15px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 0.9rem;
        }
        
        .btn-export:hover {
            background: #4ade80;
            color: #0f172a;
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-top: 30px;
        }
        
        .page-link {
            background: #1e293b;
            border: 1px solid #334155;
            color: #94a3b8;
            padding: 8px 15px;
            border-radius: 6px;
            text-decoration: none;
        }
        
        .page-link.active {
            background: #4ade80;
            color: #0f172a;
        }
        
        .footer {
            background: #1e293b;
            border-top: 1px solid #334155;
            padding: 30px 0;
            margin-top: 50px;
            text-align: center;
        }
        
        @media (max-width: 768px) {
            .filter-form {
                grid-template-columns: 1fr;
            }
            
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .table-header, .table-row {
                grid-template-columns: 1fr;
                gap: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="flag-header"></div>
    
    <nav class="navbar">
        <div class="container navbar-content">
            <a href="../index.php" class="navbar-brand">
                <i class="fas fa-shield-alt"></i>SmartIntern Kenya
            </a>
            
            <div class="nav-links">
                <a href="dashboard.php">Dashboard</a>
                <a href="students.php">Students</a>
                <a href="companies.php">Companies</a>
                <a href="placements.php" class="active">Placements</a>
                <a href="reports.php">Reports</a>
                <a href="ml-analytics.php">ML Insights</a>
                <a href="settings.php">Settings</a>
                
                <div class="user-info">
                    <div class="user-avatar">
                        <?= substr($institution['name'], 0, 1) ?>
                    </div>
                    <span><?= htmlspecialchars($institution['name']) ?></span>
                </div>
                
                <a href="../logout.php" class="btn-logout">Logout</a>
            </div>
        </div>
    </nav>
    
    <div class="container">
        <div class="page-header">
            <h1>Placement Records</h1>
            <div class="export-buttons">
                <a href="#" class="btn-export"><i class="fas fa-file-pdf me-2"></i>PDF</a>
                <a href="#" class="btn-export"><i class="fas fa-file-excel me-2"></i>Excel</a>
                <a href="#" class="btn-export"><i class="fas fa-print me-2"></i>Print</a>
            </div>
        </div>
        
        <!-- Stats Cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-number"><?= $stats['total_placements'] ?></div>
                <div class="stat-label">Total Placements</div>
                <div class="stat-sub">All time</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?= $stats['total_students'] ?></div>
                <div class="stat-label">Students Placed</div>
                <div class="stat-sub">Unique students</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?= $stats['total_companies'] ?></div>
                <div class="stat-label">Partner Companies</div>
                <div class="stat-sub">Active employers</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">KSh <?= number_format($stats['avg_salary'] ?? 0) ?></div>
                <div class="stat-label">Average Salary</div>
                <div class="stat-sub">Per month</div>
            </div>
        </div>
        
        <!-- Filter Section -->
        <div class="filter-section">
            <form method="GET" class="filter-form">
                <div class="form-group">
                    <label>Year</label>
                    <select name="year" class="form-control">
                        <option value="0">All Years</option>
                        <?php while($y = $available_years->fetch_assoc()): ?>
                        <option value="<?= $y['year'] ?>" <?= $year == $y['year'] ? 'selected' : '' ?>>
                            <?= $y['year'] ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Faculty</label>
                    <input type="text" name="faculty" class="form-control" placeholder="e.g., Computer Science" value="<?= htmlspecialchars($faculty) ?>">
                </div>
                
                <div class="form-group">
                    <label>Company</label>
                    <select name="company" class="form-control">
                        <option value="0">All Companies</option>
                        <?php 
                        $companies->data_seek(0);
                        while($comp = $companies->fetch_assoc()): ?>
                        <option value="<?= $comp['id'] ?>" <?= $company == $comp['id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($comp['name']) ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                
                <div>
                    <button type="submit" class="btn-filter">Apply Filters</button>
                </div>
                <div>
                    <a href="placements.php" class="btn-reset">Reset</a>
                </div>
            </form>
        </div>
        
        <!-- Monthly Chart -->
        <div class="chart-container">
            <h3 style="color: white; margin-bottom: 15px;">Monthly Placements - <?= $year > 0 ? $year : 'All Time' ?></h3>
            <div class="chart-box">
                <canvas id="monthlyChart"></canvas>
            </div>
        </div>
        
        <!-- Placements Table -->
        <div class="table-container">
            <div class="table-header">
                <div>Student</div>
                <div>Program</div>
                <div>Company</div>
                <div>Position</div>
                <div>Salary</div>
                <div>Date</div>
                <div></div>
            </div>
            
            <?php if ($placements && $placements->num_rows > 0): ?>
                <?php while($p = $placements->fetch_assoc()): ?>
                <div class="table-row">
                    <div>
                        <div class="student-name"><?= htmlspecialchars($p['student_name']) ?></div>
                        <div style="color: #94a3b8; font-size: 0.8rem;">CGPA: <?= $p['cgpa'] ?></div>
                    </div>
                    <div>
                        <div><?= htmlspecialchars($p['course']) ?></div>
                        <div style="color: #94a3b8; font-size: 0.8rem;">Year <?= $p['student_year'] ?></div>
                    </div>
                    <div>
                        <div class="company-name"><?= htmlspecialchars($p['company_name']) ?></div>
                        <div style="color: #94a3b8; font-size: 0.8rem;"><?= htmlspecialchars($p['industry']) ?></div>
                    </div>
                    <div><?= htmlspecialchars($p['job_title']) ?></div>
                    <div><span class="badge-salary">KSh <?= number_format($p['salary']) ?></span></div>
                    <div><?= date('M d, Y', strtotime($p['placement_date'])) ?></div>
                    <div>
                        <a href="student-details.php?id=<?= $p['student_id'] ?>" class="btn-view">
                            <i class="fas fa-eye"></i>
                        </a>
                    </div>
                </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div style="padding: 40px; text-align: center; color: #94a3b8;">
                    <i class="fas fa-trophy fa-3x mb-3" style="color: #334155;"></i>
                    <h4>No placement records found</h4>
                    <p>Try adjusting your filters or check back later</p>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Pagination (simplified) -->
        <div class="pagination">
            <a href="#" class="page-link">«</a>
            <a href="#" class="page-link active">1</a>
            <a href="#" class="page-link">2</a>
            <a href="#" class="page-link">3</a>
            <a href="#" class="page-link">»</a>
        </div>
    </div>
    
    <footer class="footer">
        <div class="container">
            <p>&copy; 2026 SmartIntern Kenya - Placement Records</p>
        </div>
    </footer>
    
    <script>
        // Monthly Chart
        const ctx = document.getElementById('monthlyChart').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                datasets: [{
                    label: 'Placements',
                    data: <?= json_encode(array_values($monthly_data)) ?>,
                    borderColor: '#4ade80',
                    backgroundColor: 'rgba(74, 222, 128, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: { color: '#334155' },
                        ticks: { color: '#94a3b8' }
                    },
                    x: {
                        grid: { display: false },
                        ticks: { color: '#94a3b8' }
                    }
                }
            }
        });
    </script>
</body>
</html>