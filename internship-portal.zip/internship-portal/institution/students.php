<?php
require_once '../includes/db_connect.php';
require_once '../includes/auth.php';
requireInstitution();

$institution = getCurrentUser($conn);

// Get search and filter parameters
$search = isset($_GET['search']) ? $_GET['search'] : '';
$faculty = isset($_GET['faculty']) ? $_GET['faculty'] : '';
$year = isset($_GET['year']) ? (int)$_GET['year'] : 0;

// Build query
$query = "SELECT * FROM students WHERE university LIKE ?";
$params = ["%{$institution['name']}%"];
$types = "s";

if (!empty($search)) {
    $query .= " AND (name LIKE ? OR course LIKE ? OR skills LIKE ?)";
    $search_param = "%$search%";
    $params[] = $search_param;
    $params[] = $search_param;
    $params[] = $search_param;
    $types .= "sss";
}

if (!empty($faculty)) {
    $query .= " AND course LIKE ?";
    $params[] = "%$faculty%";
    $types .= "s";
}

if ($year > 0) {
    $query .= " AND year = ?";
    $params[] = $year;
    $types .= "i";
}

$query .= " ORDER BY name ASC";

$stmt = $conn->prepare($query);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$students = $stmt->get_result();

// Get stats
$stats_query = "SELECT 
                COUNT(*) as total,
                AVG(cgpa) as avg_cgpa,
                COUNT(DISTINCT course) as courses
                FROM students WHERE university LIKE ?";
$stmt = $conn->prepare($stats_query);
$stmt->bind_param("s", $params[0]);
$stmt->execute();
$stats = $stmt->get_result()->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Records - SmartIntern Kenya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #0f172a;
            color: #e2e8f0;
        }
        
        .flag-header {
            height: 4px;
            background: linear-gradient(90deg, 
                #000000 0%, #000000 33.33%,
                #b91c1c 33.33%, #b91c1c 66.66%,
                #059669 66.66%, #059669 100%);
        }
        
        .navbar {
            background: #1e293b;
            border-bottom: 1px solid #334155;
            padding: 1rem 0;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        .navbar-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .navbar-brand {
            font-weight: 700;
            font-size: 1.3rem;
            color: #4ade80;
            text-decoration: none;
        }
        
        .navbar-brand i {
            color: #4ade80;
        }
        
        .nav-links {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .nav-links a {
            color: #cbd5e1;
            text-decoration: none;
            padding: 5px 10px;
        }
        
        .nav-links a:hover {
            color: #4ade80;
        }
        
        .nav-links a.active {
            color: #4ade80;
            border-bottom: 2px solid #4ade80;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
            color: #94a3b8;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #059669, #4ade80);
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
        }
        
        .btn-logout {
            color: #ef4444;
            text-decoration: none;
            padding: 8px 15px;
            border: 1px solid #ef4444;
            border-radius: 6px;
        }
        
        .page-header {
            margin: 30px 0;
        }
        
        .page-header h1 {
            color: white;
            font-size: 2rem;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 10px;
            padding: 20px;
        }
        
        .stat-number {
            font-size: 2rem;
            font-weight: 700;
            color: #4ade80;
        }
        
        .filter-section {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 30px;
        }
        
        .filter-form {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr auto;
            gap: 15px;
            align-items: end;
        }
        
        .form-group {
            margin-bottom: 0;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #94a3b8;
            font-size: 0.9rem;
        }
        
        .form-control {
            width: 100%;
            padding: 8px 12px;
            background: #0f172a;
            border: 1px solid #334155;
            border-radius: 6px;
            color: white;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #4ade80;
        }
        
        .btn-filter {
            background: #4ade80;
            color: #0f172a;
            border: none;
            padding: 8px 20px;
            border-radius: 6px;
            font-weight: 600;
            cursor: pointer;
        }
        
        .btn-reset {
            background: transparent;
            color: #94a3b8;
            border: 1px solid #334155;
            padding: 8px 20px;
            border-radius: 6px;
            text-decoration: none;
            display: inline-block;
        }
        
        .students-table {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 10px;
            overflow: hidden;
        }
        
        .table-header {
            display: grid;
            grid-template-columns: 2fr 2fr 1fr 1fr 1fr 1fr;
            background: #0f172a;
            padding: 15px;
            color: #4ade80;
            font-weight: 600;
        }
        
        .student-row {
            display: grid;
            grid-template-columns: 2fr 2fr 1fr 1fr 1fr 1fr;
            padding: 15px;
            border-bottom: 1px solid #334155;
            align-items: center;
        }
        
        .student-row:hover {
            background: #0f172a;
        }
        
        .student-name {
            color: white;
            font-weight: 500;
        }
        
        .student-email {
            color: #94a3b8;
            font-size: 0.9rem;
        }
        
        .badge-cgpa {
            background: #4ade80;
            color: #0f172a;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .btn-view {
            color: #4ade80;
            text-decoration: none;
            font-size: 0.9rem;
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-top: 30px;
        }
        
        .page-link {
            background: #1e293b;
            border: 1px solid #334155;
            color: #94a3b8;
            padding: 8px 15px;
            border-radius: 6px;
            text-decoration: none;
        }
        
        .page-link.active {
            background: #4ade80;
            color: #0f172a;
            border-color: #4ade80;
        }
        
        .footer {
            background: #1e293b;
            border-top: 1px solid #334155;
            padding: 30px 0;
            margin-top: 50px;
            text-align: center;
        }
        
        @media (max-width: 768px) {
            .filter-form {
                grid-template-columns: 1fr;
            }
            
            .table-header, .student-row {
                grid-template-columns: 1fr;
                gap: 10px;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="flag-header"></div>
    
    <nav class="navbar">
        <div class="container navbar-content">
            <a href="../index.php" class="navbar-brand">
                <i class="fas fa-shield-alt"></i>SmartIntern Kenya
            </a>
            
            <div class="nav-links">
                <a href="dashboard.php">Dashboard</a>
                <a href="students.php" class="active">Students</a>
                <a href="companies.php">Companies</a>
                <a href="reports.php">Reports</a>
                <a href="ml-analytics.php">ML Insights</a>
                <a href="settings.php">Settings</a>
                
                <div class="user-info">
                    <div class="user-avatar">
                        <?= substr($institution['name'], 0, 1) ?>
                    </div>
                    <span><?= htmlspecialchars($institution['name']) ?></span>
                </div>
                
                <a href="../logout.php" class="btn-logout">Logout</a>
            </div>
        </div>
    </nav>
    
    <div class="container">
        <div class="page-header">
            <h1>Student Records</h1>
        </div>
        
        <!-- Stats Cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-number"><?= $stats['total'] ?></div>
                <div>Total Students</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?= round($stats['avg_cgpa'], 2) ?></div>
                <div>Average CGPA</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?= $stats['courses'] ?></div>
                <div>Programs</div>
            </div>
        </div>
        
        <!-- Filter Section -->
        <div class="filter-section">
            <form method="GET" class="filter-form">
                <div class="form-group">
                    <label>Search</label>
                    <input type="text" name="search" class="form-control" placeholder="Name, course, skills..." value="<?= htmlspecialchars($search) ?>">
                </div>
                
                <div class="form-group">
                    <label>Faculty/Program</label>
                    <input type="text" name="faculty" class="form-control" placeholder="e.g., Computer Science" value="<?= htmlspecialchars($faculty) ?>">
                </div>
                
                <div class="form-group">
                    <label>Year</label>
                    <select name="year" class="form-control">
                        <option value="0">All Years</option>
                        <?php for($i=1; $i<=4; $i++): ?>
                        <option value="<?= $i ?>" <?= $year == $i ? 'selected' : '' ?>>Year <?= $i ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
                
                <div>
                    <button type="submit" class="btn-filter">Apply Filters</button>
                    <a href="students.php" class="btn-reset">Reset</a>
                </div>
            </form>
        </div>
        
        <!-- Students Table -->
        <div class="students-table">
            <div class="table-header">
                <div>Student</div>
                <div>Program</div>
                <div>Year</div>
                <div>CGPA</div>
                <div>Location</div>
                <div>Action</div>
            </div>
            
            <?php if ($students && $students->num_rows > 0): ?>
                <?php while($student = $students->fetch_assoc()): ?>
                    <div class="student-row">
                        <div>
                            <div class="student-name"><?= htmlspecialchars($student['name']) ?></div>
                            <div class="student-email"><?= htmlspecialchars($student['email']) ?></div>
                        </div>
                        <div><?= htmlspecialchars($student['course']) ?></div>
                        <div>Year <?= $student['year'] ?></div>
                        <div><span class="badge-cgpa"><?= $student['cgpa'] ?></span></div>
                        <div><?= htmlspecialchars($student['location']) ?></div>
                        <div>
                            <a href="student-details.php?id=<?= $student['id'] ?>" class="btn-view">
                                <i class="fas fa-eye"></i> View
                            </a>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div style="padding: 40px; text-align: center; color: #94a3b8;">
                    No students found matching your criteria.
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Pagination (simplified) -->
        <div class="pagination">
            <a href="#" class="page-link active">1</a>
            <a href="#" class="page-link">2</a>
            <a href="#" class="page-link">3</a>
            <a href="#" class="page-link">Next</a>
        </div>
    </div>
    
    <footer class="footer">
        <div class="container">
            <p>&copy; 2026 SmartIntern Kenya - Institution Portal</p>
        </div>
    </footer>
</body>
</html>