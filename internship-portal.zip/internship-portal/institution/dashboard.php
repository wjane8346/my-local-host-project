<?php
require_once '../includes/db_connect.php';
require_once '../includes/auth.php';
requireInstitution();

$institution = getCurrentUser($conn);

// Get students from this institution
$students_query = "SELECT * FROM students WHERE university LIKE ? ORDER BY created_at DESC";
$univ_pattern = "%{$institution['name']}%";
$stmt = $conn->prepare($students_query);
$stmt->bind_param("s", $univ_pattern);
$stmt->execute();
$students = $stmt->get_result();

// Get stats
$stats_query = "SELECT 
                COUNT(*) as total_students,
                AVG(cgpa) as avg_cgpa,
                COUNT(DISTINCT id) as students_count
                FROM students 
                WHERE university LIKE ?";
$stmt = $conn->prepare($stats_query);
$stmt->bind_param("s", $univ_pattern);
$stmt->execute();
$stats = $stmt->get_result()->fetch_assoc();

// Get application stats
$apps_query = "SELECT 
                COUNT(DISTINCT a.id) as total_apps,
                COUNT(DISTINCT a.student_id) as students_applied,
                SUM(CASE WHEN a.status IN ('shortlisted', 'interview', 'accepted') THEN 1 ELSE 0 END) as placements
                FROM students s
                LEFT JOIN applications a ON s.id = a.student_id
                WHERE s.university LIKE ?";
$stmt = $conn->prepare($apps_query);
$stmt->bind_param("s", $univ_pattern);
$stmt->execute();
$app_stats = $stmt->get_result()->fetch_assoc();

// Get top companies
$companies_query = "SELECT c.name, COUNT(a.id) as hires
                    FROM companies c
                    JOIN jobs j ON c.id = j.company_id
                    JOIN applications a ON j.id = a.job_id
                    JOIN students s ON a.student_id = s.id
                    WHERE s.university LIKE ? AND a.status IN ('shortlisted', 'interview', 'accepted')
                    GROUP BY c.id
                    ORDER BY hires DESC
                    LIMIT 5";
$stmt = $conn->prepare($companies_query);
$stmt->bind_param("s", $univ_pattern);
$stmt->execute();
$top_companies = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Institution Dashboard - SmartIntern Kenya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #0f172a;
            color: #e2e8f0;
            line-height: 1.6;
        }
        
        .flag-header {
            height: 4px;
            background: linear-gradient(90deg, 
                #000000 0%, #000000 33.33%,
                #b91c1c 33.33%, #b91c1c 66.66%,
                #059669 66.66%, #059669 100%);
        }
        
        .navbar {
            background: #1e293b;
            border-bottom: 1px solid #334155;
            padding: 1rem 0;
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        .navbar-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .navbar-brand {
            font-weight: 700;
            font-size: 1.3rem;
            color: #4ade80;
            text-decoration: none;
        }
        
        .navbar-brand i {
            color: #4ade80;
            margin-right: 8px;
        }
        
        .nav-links {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .nav-links a {
            color: #cbd5e1;
            text-decoration: none;
            transition: color 0.2s;
            padding: 5px 10px;
            border-radius: 6px;
        }
        
        .nav-links a:hover {
            color: #4ade80;
            background: #0f172a;
        }
        
        .nav-links a.active {
            color: #4ade80;
            background: #0f172a;
            border-left: 3px solid #4ade80;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
            color: #94a3b8;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #059669, #4ade80);
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.1rem;
        }
        
        .btn-logout {
            color: #ef4444;
            text-decoration: none;
            padding: 8px 15px;
            border-radius: 6px;
            border: 1px solid #ef4444;
            transition: all 0.2s;
        }
        
        .btn-logout:hover {
            background: #ef4444;
            color: white;
        }
        
        .welcome-section {
            background: linear-gradient(135deg, #1e293b, #0f172a);
            border: 1px solid #334155;
            border-radius: 12px;
            padding: 30px;
            margin: 30px 0;
            display: flex;
            align-items: center;
            gap: 30px;
        }
        
        .welcome-avatar {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #059669, #4ade80);
            border-radius: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 2rem;
            font-weight: bold;
        }
        
        .welcome-text h1 {
            color: white;
            margin-bottom: 5px;
        }
        
        .welcome-text p {
            color: #94a3b8;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 10px;
            padding: 20px;
            transition: all 0.3s;
        }
        
        .stat-card:hover {
            border-color: #4ade80;
            transform: translateY(-2px);
        }
        
        .stat-number {
            font-size: 2rem;
            font-weight: 700;
            color: #4ade80;
            margin-bottom: 5px;
        }
        
        .stat-label {
            color: #94a3b8;
            font-size: 0.9rem;
        }
        
        .stat-desc {
            color: #64748b;
            font-size: 0.8rem;
            margin-top: 5px;
        }
        
        .action-buttons {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 15px;
            margin-bottom: 30px;
        }
        
        .action-btn {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 8px;
            padding: 15px;
            text-align: center;
            text-decoration: none;
            color: #e2e8f0;
            transition: all 0.3s;
        }
        
        .action-btn:hover {
            border-color: #4ade80;
            transform: translateY(-2px);
        }
        
        .action-btn i {
            color: #4ade80;
            font-size: 1.5rem;
            margin-bottom: 10px;
            display: block;
        }
        
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 30px 0 20px;
        }
        
        .section-header h2 {
            color: white;
            font-size: 1.5rem;
        }
        
        .section-header a {
            color: #4ade80;
            text-decoration: none;
        }
        
        .card {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
        }
        
        .student-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 0;
            border-bottom: 1px solid #334155;
        }
        
        .student-item:last-child {
            border-bottom: none;
        }
        
        .student-info h4 {
            color: white;
            margin-bottom: 5px;
        }
        
        .student-info p {
            color: #94a3b8;
            font-size: 0.85rem;
        }
        
        .student-meta {
            display: flex;
            gap: 15px;
            margin-top: 5px;
            color: #64748b;
            font-size: 0.8rem;
        }
        
        .student-meta i {
            color: #4ade80;
            margin-right: 5px;
        }
        
        .company-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 0;
            border-bottom: 1px solid #334155;
        }
        
        .company-item:last-child {
            border-bottom: none;
        }
        
        .company-info h4 {
            color: white;
            margin-bottom: 5px;
        }
        
        .company-info p {
            color: #94a3b8;
            font-size: 0.85rem;
        }
        
        .hire-badge {
            background: #0f172a;
            color: #4ade80;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.85rem;
        }
        
        .progress-section {
            margin-top: 20px;
        }
        
        .progress-item {
            margin-bottom: 15px;
        }
        
        .progress-label {
            display: flex;
            justify-content: space-between;
            margin-bottom: 5px;
            color: #94a3b8;
        }
        
        .progress {
            height: 8px;
            background: #0f172a;
            border-radius: 4px;
            overflow: hidden;
        }
        
        .progress-bar {
            height: 100%;
            background: #4ade80;
            border-radius: 4px;
        }
        
        .footer {
            background: #1e293b;
            border-top: 1px solid #334155;
            padding: 30px 0;
            margin-top: 50px;
            text-align: center;
            color: #64748b;
        }
        
        @media (max-width: 768px) {
            .stats-grid,
            .action-buttons {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .navbar-content {
                flex-direction: column;
                gap: 15px;
            }
        }
    </style>
</head>
<body>
    <div class="flag-header"></div>
    
    <nav class="navbar">
        <div class="container navbar-content">
            <a href="../index.php" class="navbar-brand">
                <i class="fas fa-shield-alt"></i>SmartIntern Kenya
            </a>
            
            <div class="nav-links">
                <a href="dashboard.php" class="active">Dashboard</a>
                <a href="students.php">Students</a>
                <a href="companies.php">Companies</a>
                <a href="reports.php">Reports</a>
                <a href="ml-analytics.php">ML Insights</a>
                
                <div class="user-info">
                    <div class="user-avatar">
                        <?= substr($institution['name'], 0, 1) ?>
                    </div>
                    <span><?= htmlspecialchars($institution['name']) ?></span>
                </div>
                
                <a href="../logout.php" class="btn-logout">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </div>
    </nav>
    
    <div class="container">
        <!-- Welcome Section -->
        <div class="welcome-section">
            <div class="welcome-avatar">
                <?= substr($institution['name'], 0, 1) ?>
            </div>
            <div class="welcome-text">
                <h1><?= htmlspecialchars($institution['name']) ?></h1>
                <p>Office of Career Services • Established <?= htmlspecialchars($institution['established']) ?></p>
            </div>
        </div>
        
        <!-- Stats Cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-number"><?= $stats['total_students'] ?? 0 ?></div>
                <div class="stat-label">Total Students</div>
                <div class="stat-desc">Registered in the system</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-number"><?= $app_stats['students_applied'] ?? 0 ?></div>
                <div class="stat-label">Students Applied</div>
                <div class="stat-desc">Actively seeking internships</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-number"><?= $app_stats['total_apps'] ?? 0 ?></div>
                <div class="stat-label">Total Applications</div>
                <div class="stat-desc">Across all companies</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-number"><?= $app_stats['placements'] ?? 0 ?></div>
                <div class="stat-label">Placements</div>
                <div class="stat-desc">Shortlisted + Hired</div>
            </div>
        </div>
        
        <!-- Quick Actions -->
        <div class="action-buttons">
            <a href="students.php" class="action-btn">
                <i class="fas fa-user-graduate"></i>
                View Students
            </a>
            <a href="companies.php" class="action-btn">
                <i class="fas fa-building"></i>
                Partner Companies
            </a>
            <a href="reports.php" class="action-btn">
                <i class="fas fa-chart-bar"></i>
                Analytics
            </a>
            <a href="ml-analytics.php" class="action-btn">
                <i class="fas fa-brain"></i>
                ML Insights
            </a>
        </div>
        
        <div class="row">
            <div class="col-md-7">
                <!-- Recent Students -->
                <div class="section-header">
                    <h2>Recent Students</h2>
                    <a href="students.php">View All →</a>
                </div>
                
                <div class="card">
                    <?php if ($students && $students->num_rows > 0): ?>
                        <?php while($student = $students->fetch_assoc()): ?>
                            <div class="student-item">
                                <div class="student-info">
                                    <h4><?= htmlspecialchars($student['name']) ?></h4>
                                    <p><?= htmlspecialchars($student['course']) ?> • Year <?= $student['year'] ?></p>
                                    <div class="student-meta">
                                        <span><i class="fas fa-star"></i> CGPA: <?= $student['cgpa'] ?></span>
                                        <span><i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($student['location']) ?></span>
                                    </div>
                                </div>
                                <div>
                                    <a href="student-details.php?id=<?= $student['id'] ?>" style="color: #4ade80;">View →</a>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <p style="color: #64748b; text-align: center; padding: 20px;">No students found.</p>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="col-md-5">
                <!-- Top Partner Companies -->
                <div class="section-header">
                    <h2>Top Partners</h2>
                    <a href="companies.php">View All →</a>
                </div>
                
                <div class="card">
                    <?php if ($top_companies && $top_companies->num_rows > 0): ?>
                        <?php while($company = $top_companies->fetch_assoc()): ?>
                            <div class="company-item">
                                <div class="company-info">
                                    <h4><?= htmlspecialchars($company['name']) ?></h4>
                                </div>
                                <div>
                                    <span class="hire-badge">
                                        <i class="fas fa-users"></i> <?= $company['hires'] ?> hires
                                    </span>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <p style="color: #64748b; text-align: center; padding: 20px;">No placement data yet.</p>
                    <?php endif; ?>
                </div>
                
                <!-- Quick Stats -->
                <div class="card" style="margin-top: 20px;">
                    <h3 style="color: white; margin-bottom: 15px;">Quick Stats</h3>
                    
                    <div class="progress-section">
                        <div class="progress-item">
                            <div class="progress-label">
                                <span>Average CGPA</span>
                                <span><?= round($stats['avg_cgpa'] ?? 0, 2) ?></span>
                            </div>
                            <div class="progress">
                                <?php $cgpa_percent = (($stats['avg_cgpa'] ?? 0) / 4) * 100; ?>
                                <div class="progress-bar" style="width: <?= $cgpa_percent ?>%"></div>
                            </div>
                        </div>
                        
                        <div class="progress-item">
                            <div class="progress-label">
                                <span>Application Rate</span>
                                <span><?= $stats['total_students'] > 0 ? round(($app_stats['students_applied'] / $stats['total_students']) * 100) : 0 ?>%</span>
                            </div>
                            <div class="progress">
                                <?php $app_rate = $stats['total_students'] > 0 ? ($app_stats['students_applied'] / $stats['total_students']) * 100 : 0; ?>
                                <div class="progress-bar" style="width: <?= $app_rate ?>%"></div>
                            </div>
                        </div>
                        
                        <div class="progress-item">
                            <div class="progress-label">
                                <span>Placement Rate</span>
                                <span><?= $app_stats['students_applied'] > 0 ? round(($app_stats['placements'] / $app_stats['students_applied']) * 100) : 0 ?>%</span>
                            </div>
                            <div class="progress">
                                <?php $placement_rate = $app_stats['students_applied'] > 0 ? ($app_stats['placements'] / $app_stats['students_applied']) * 100 : 0; ?>
                                <div class="progress-bar" style="width: <?= $placement_rate ?>%"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <footer class="footer">
        <div class="container">
            <p>&copy; 2026 SmartIntern Kenya - Institution Portal</p>
        </div>
    </footer>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>