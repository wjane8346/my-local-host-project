<?php
require_once '../includes/db_connect.php';
require_once '../includes/auth.php';
requireInstitution();

$institution = getCurrentUser($conn);
$univ_pattern = "%{$institution['name']}%";

// Get overall stats
$overall_query = "SELECT 
                  COUNT(DISTINCT s.id) as total_students,
                  COUNT(DISTINCT a.id) as total_apps,
                  COUNT(DISTINCT CASE WHEN a.status IN ('shortlisted', 'interview', 'accepted') THEN a.id END) as placements,
                  AVG(s.cgpa) as avg_cgpa
                  FROM students s
                  LEFT JOIN applications a ON s.id = a.student_id
                  WHERE s.university LIKE ?";
$stmt = $conn->prepare($overall_query);
$stmt->bind_param("s", $univ_pattern);
$stmt->execute();
$overall = $stmt->get_result()->fetch_assoc();

// Get stats by faculty
$faculty_query = "SELECT 
                  SUBSTRING_INDEX(course, ' ', 1) as faculty,
                  COUNT(*) as student_count,
                  AVG(cgpa) as avg_cgpa,
                  COUNT(a.id) as applications,
                  SUM(CASE WHEN a.status IN ('shortlisted', 'interview', 'accepted') THEN 1 ELSE 0 END) as placements
                  FROM students s
                  LEFT JOIN applications a ON s.id = a.student_id
                  WHERE s.university LIKE ?
                  GROUP BY faculty
                  ORDER BY student_count DESC";
$stmt = $conn->prepare($faculty_query);
$stmt->bind_param("s", $univ_pattern);
$stmt->execute();
$faculties = $stmt->get_result();

// Get monthly trends
$monthly_query = "SELECT 
                  DATE_FORMAT(a.applied_date, '%Y-%m') as month,
                  COUNT(*) as applications,
                  SUM(CASE WHEN a.status IN ('shortlisted', 'interview', 'accepted') THEN 1 ELSE 0 END) as placements
                  FROM applications a
                  JOIN students s ON a.student_id = s.id
                  WHERE s.university LIKE ?
                  GROUP BY month
                  ORDER BY month DESC
                  LIMIT 6";
$stmt = $conn->prepare($monthly_query);
$stmt->bind_param("s", $univ_pattern);
$stmt->execute();
$monthly = $stmt->get_result();

// Get top companies
$top_query = "SELECT 
              c.name,
              COUNT(a.id) as hires
              FROM companies c
              JOIN jobs j ON c.id = j.company_id
              JOIN applications a ON j.id = a.job_id
              JOIN students s ON a.student_id = s.id
              WHERE s.university LIKE ? AND a.status IN ('shortlisted', 'interview', 'accepted')
              GROUP BY c.id
              ORDER BY hires DESC
              LIMIT 5";
$stmt = $conn->prepare($top_query);
$stmt->bind_param("s", $univ_pattern);
$stmt->execute();
$top_companies = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Placement Reports - SmartIntern Kenya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #0f172a;
            color: #e2e8f0;
        }
        
        .flag-header {
            height: 4px;
            background: linear-gradient(90deg, 
                #000000 0%, #000000 33.33%,
                #b91c1c 33.33%, #b91c1c 66.66%,
                #059669 66.66%, #059669 100%);
        }
        
        .navbar {
            background: #1e293b;
            border-bottom: 1px solid #334155;
            padding: 1rem 0;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        .navbar-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .navbar-brand {
            font-weight: 700;
            font-size: 1.3rem;
            color: #4ade80;
            text-decoration: none;
        }
        
        .nav-links {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .nav-links a {
            color: #cbd5e1;
            text-decoration: none;
        }
        
        .nav-links a:hover {
            color: #4ade80;
        }
        
        .nav-links a.active {
            color: #4ade80;
            border-bottom: 2px solid #4ade80;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
            color: #94a3b8;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #059669, #4ade80);
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
        }
        
        .btn-logout {
            color: #ef4444;
            text-decoration: none;
            padding: 8px 15px;
            border: 1px solid #ef4444;
            border-radius: 6px;
        }
        
        .page-header {
            margin: 30px 0;
        }
        
        .page-header h1 {
            color: white;
            font-size: 2rem;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 10px;
            padding: 20px;
        }
        
        .stat-number {
            font-size: 2rem;
            font-weight: 700;
            color: #4ade80;
        }
        
        .stat-label {
            color: #94a3b8;
        }
        
        .stat-small {
            font-size: 0.8rem;
            color: #4ade80;
        }
        
        .chart-container {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 30px;
        }
        
        .chart-box {
            height: 300px;
        }
        
        .table-container {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 10px;
            overflow: hidden;
            margin-bottom: 30px;
        }
        
        .table-header {
            display: grid;
            grid-template-columns: 2fr 1fr 1fr 1fr;
            background: #0f172a;
            padding: 15px;
            color: #4ade80;
            font-weight: 600;
        }
        
        .table-row {
            display: grid;
            grid-template-columns: 2fr 1fr 1fr 1fr;
            padding: 15px;
            border-bottom: 1px solid #334155;
        }
        
        .footer {
            background: #1e293b;
            border-top: 1px solid #334155;
            padding: 30px 0;
            margin-top: 50px;
            text-align: center;
        }
        
        .export-buttons {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }
        
        .btn-export {
            background: transparent;
            border: 1px solid #4ade80;
            color: #4ade80;
            padding: 8px 15px;
            border-radius: 6px;
            text-decoration: none;
        }
        
        @media (max-width: 768px) {
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
    </style>
</head>
<body>
    <div class="flag-header"></div>
    
    <nav class="navbar">
        <div class="container navbar-content">
            <a href="../index.php" class="navbar-brand">
                <i class="fas fa-shield-alt"></i>SmartIntern Kenya
            </a>
            
            <div class="nav-links">
                <a href="dashboard.php">Dashboard</a>
                <a href="students.php">Students</a>
                <a href="companies.php">Companies</a>
                <a href="reports.php" class="active">Reports</a>
                <a href="ml-analytics.php">ML Insights</a>
                
                <div class="user-info">
                    <div class="user-avatar">
                        <?= substr($institution['name'], 0, 1) ?>
                    </div>
                    <span><?= htmlspecialchars($institution['name']) ?></span>
                </div>
                
                <a href="../logout.php" class="btn-logout">Logout</a>
            </div>
        </div>
    </nav>
    
    <div class="container">
        <div class="page-header">
            <h1>Placement Reports</h1>
        </div>
        
        <!-- Export Buttons -->
        <div class="export-buttons">
            <a href="#" class="btn-export"><i class="fas fa-file-pdf"></i> Export PDF</a>
            <a href="#" class="btn-export"><i class="fas fa-file-excel"></i> Export Excel</a>
        </div>
        
        <!-- Stats Cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-number"><?= $overall['total_students'] ?></div>
                <div class="stat-label">Total Students</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?= $overall['total_apps'] ?></div>
                <div class="stat-label">Applications</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?= $overall['placements'] ?></div>
                <div class="stat-label">Placements</div>
                <div class="stat-small">
                    <?= $overall['total_apps'] > 0 ? round(($overall['placements'] / $overall['total_apps']) * 100) : 0 ?>% success rate
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?= round($overall['avg_cgpa'], 2) ?></div>
                <div class="stat-label">Avg CGPA</div>
            </div>
        </div>
        
        <!-- Faculty Performance -->
        <div class="chart-container">
            <h3 style="color: white; margin-bottom: 20px;">Faculty Performance</h3>
            <div class="chart-box">
                <canvas id="facultyChart"></canvas>
            </div>
        </div>
        
        <!-- Faculty Table -->
        <div class="table-container">
            <div class="table-header">
                <div>Faculty</div>
                <div>Students</div>
                <div>Applications</div>
                <div>Placements</div>
            </div>
            <?php while($faculty = $faculties->fetch_assoc()): ?>
            <div class="table-row">
                <div><?= htmlspecialchars($faculty['faculty']) ?></div>
                <div><?= $faculty['student_count'] ?></div>
                <div><?= $faculty['applications'] ?></div>
                <div>
                    <?= $faculty['placements'] ?> 
                    (<?= $faculty['student_count'] > 0 ? round(($faculty['placements'] / $faculty['student_count']) * 100) : 0 ?>%)
                </div>
            </div>
            <?php endwhile; ?>
        </div>
        
        <!-- Top Companies -->
        <div class="chart-container">
            <h3 style="color: white; margin-bottom: 20px;">Top Hiring Companies</h3>
            <div class="table-container" style="margin-bottom: 0;">
                <?php while($company = $top_companies->fetch_assoc()): ?>
                <div class="table-row" style="grid-template-columns: 3fr 1fr;">
                    <div><?= htmlspecialchars($company['name']) ?></div>
                    <div style="color: #4ade80;"><?= $company['hires'] ?> students</div>
                </div>
                <?php endwhile; ?>
            </div>
        </div>
    </div>
    
    <footer class="footer">
        <div class="container">
            <p>&copy; 2026 SmartIntern Kenya</p>
        </div>
    </footer>
    
    <script>
        // Faculty Chart
        const facultyCtx = document.getElementById('facultyChart').getContext('2d');
        new Chart(facultyCtx, {
            type: 'bar',
            data: {
                labels: <?php 
                    $faculties->data_seek(0);
                    $labels = [];
                    $placements = [];
                    while($row = $faculties->fetch_assoc()) {
                        $labels[] = $row['faculty'];
                        $placements[] = $row['student_count'] > 0 ? round(($row['placements'] / $row['student_count']) * 100) : 0;
                    }
                    echo json_encode($labels);
                ?>,
                datasets: [{
                    label: 'Placement Rate (%)',
                    data: <?= json_encode($placements) ?>,
                    backgroundColor: '#4ade80',
                    borderRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        grid: { color: '#334155' },
                        ticks: { color: '#94a3b8' }
                    },
                    x: {
                        ticks: { color: '#94a3b8' }
                    }
                }
            }
        });
    </script>
</body>
</html>