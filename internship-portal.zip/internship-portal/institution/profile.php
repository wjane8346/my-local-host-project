<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Institution Profile - SmartIntern Kenya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #0f172a; color: #e2e8f0; font-family: 'Segoe UI', sans-serif; }
        .flag-header { height: 4px; background: linear-gradient(90deg, #000000 33%, #BB2B1F 33%, #BB2B1F 66%, #006233 66%); }
        .navbar { background: #1e293b; padding: 1rem 0; border-bottom: 1px solid #334155; }
        .navbar-brand { color: #4ade80 !important; font-weight: bold; }
        .container { max-width: 600px; margin: 2rem auto; padding: 0 20px; }
        .profile-card { background: #1e293b; border: 1px solid #334155; border-radius: 15px; padding: 2rem; }
        .profile-logo { width: 100px; height: 100px; background: linear-gradient(135deg, #006233, #BB2B1F); border-radius: 25px; display: flex; align-items: center; justify-content: center; margin: 0 auto 1.5rem; color: white; font-size: 2.5rem; font-weight: bold; }
        .info-row { display: flex; padding: 0.75rem 0; border-bottom: 1px solid #334155; }
        .info-label { width: 150px; color: #94a3b8; }
        .info-value { color: white; }
        .btn-save { background: #4ade80; color: #0f172a; border: none; padding: 0.6rem; width: 100%; border-radius: 6px; font-weight: 600; margin-top: 1rem; }
    </style>
</head>
<body>
<div class="flag-header"></div>

<nav class="navbar">
    <div class="container">
        <a class="navbar-brand" href="/internship-portal/index.html">SmartIntern Kenya</a>
        <a href="/internship-portal/institution/dashboard.html" class="btn btn-outline-success">← Back</a>
    </div>
</nav>

<div class="container">
    <div class="profile-card">
        <div class="profile-logo">UoN</div>
        <h3 class="text-white text-center mb-4">University of Nairobi</h3>
        
        <div class="info-row"><span class="info-label">Institution Name</span><span class="info-value">University of Nairobi</span></div>
        <div class="info-row"><span class="info-label">Email</span><span class="info-value">careers@uonbi.ac.ke</span></div>
        <div class="info-row"><span class="info-label">Phone</span><span class="info-value">+254 700 000 000</span></div>
        <div class="info-row"><span class="info-label">Location</span><span class="info-value">Nairobi, Kenya</span></div>
        <div class="info-row"><span class="info-label">Website</span><span class="info-value">www.uonbi.ac.ke</span></div>
        <div class="info-row"><span class="info-label">Established</span><span class="info-value">1970</span></div>
        <div class="info-row"><span class="info-label">Total Students</span><span class="info-value">3,247</span></div>
        
        <button class="btn-save">Edit Profile</button>
    </div>
</div>
</body>
</html>