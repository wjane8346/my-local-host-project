<?php
// Turn on error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1 style='color: #4ade80;'>Adding Sample Data - Debug Mode</h1>";

// Database connection
$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'internship_portal';

echo "<p>Connecting to database: $dbname...</p>";

$conn = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($conn->connect_error) {
    die("<p style='color: red;'>❌ Connection failed: " . $conn->connect_error . "</p>");
}
echo "<p style='color: green;'>✅ Connected to database successfully!</p>";

// Clear existing data
echo "<p>Clearing old data...</p>";
$conn->query("DELETE FROM students");
$conn->query("DELETE FROM jobs");
$conn->query("DELETE FROM matches");
echo "<p style='color: green;'>✅ Old data cleared</p>";

// Sample students
$students = [
    [
        'name' => 'Wendy Jane',
        'email' => 'wendy.jane@uonbi.ac.ke',
        'university' => 'University of Nairobi',
        'course' => 'Computer Science',
        'year' => 3,
        'cgpa' => 3.8,
        'skills' => 'Python, JavaScript, React, SQL, Django',
        'location' => 'Nairobi'
    ],
    [
        'name' => 'James Mwangi',
        'email' => 'james.mwangi@jkuat.ac.ke',
        'university' => 'JKUAT',
        'course' => 'Software Engineering',
        'year' => 4,
        'cgpa' => 3.6,
        'skills' => 'Java, Spring Boot, MySQL, AWS',
        'location' => 'Nairobi'
    ]
];

echo "<p>Adding " . count($students) . " students...</p>";

foreach ($students as $s) {
    $sql = "INSERT INTO students (name, email, university, course, year, cgpa, skills, location) 
            VALUES (
                '$s[name]', 
                '$s[email]', 
                '$s[university]', 
                '$s[course]', 
                $s[year], 
                $s[cgpa], 
                '$s[skills]', 
                '$s[location]'
            )";
    
    if ($conn->query($sql)) {
        echo "<p style='color: green;'>✅ Added student: $s[name]</p>";
    } else {
        echo "<p style='color: red;'>❌ Error adding student: " . $conn->error . "</p>";
    }
}

// Sample jobs
$jobs = [
    [
        'company_id' => 1,
        'title' => 'Software Developer Intern',
        'description' => 'Join our digital team',
        'required_skills' => 'Python, JavaScript, SQL, React',
        'min_cgpa' => 3.0,
        'location' => 'Nairobi',
        'salary' => 'KSh 45,000/month'
    ]
];

echo "<p>Adding " . count($jobs) . " jobs...</p>";

foreach ($jobs as $j) {
    $sql = "INSERT INTO jobs (company_id, title, description, required_skills, min_cgpa, location, salary) 
            VALUES (
                $j[company_id], 
                '$j[title]', 
                '$j[description]', 
                '$j[required_skills]', 
                $j[min_cgpa], 
                '$j[location]', 
                '$j[salary]'
            )";
    
    if ($conn->query($sql)) {
        echo "<p style='color: green;'>✅ Added job: $j[title]</p>";
    } else {
        echo "<p style='color: red;'>❌ Error adding job: " . $conn->error . "</p>";
    }
}

echo "<h2 style='color: #4ade80; margin-top: 20px;'>✅ Process completed!</h2>";

// Show what's in database
$result = $conn->query("SELECT COUNT(*) as count FROM students");
$row = $result->fetch_assoc();
echo "<p>Total students in database: " . $row['count'] . "</p>";

$result = $conn->query("SELECT COUNT(*) as count FROM jobs");
$row = $result->fetch_assoc();
echo "<p>Total jobs in database: " . $row['count'] . "</p>";

echo '<p><a href="../ai/test-match.php" style="color: #4ade80;">Click here to test matching →</a></p>';
?>