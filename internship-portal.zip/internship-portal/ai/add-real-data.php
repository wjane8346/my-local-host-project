<?php
// Turn on error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1 style='color: #4ade80;'>📊 Adding REAL User Data</h1>";

// Database connection
require_once '../includes/db_connect.php';

// Clear existing data
$conn->query("DELETE FROM students");
$conn->query("DELETE FROM companies");
$conn->query("DELETE FROM jobs");
$conn->query("DELETE FROM applications");
$conn->query("DELETE FROM matches");
$conn->query("DELETE FROM institutions");

echo "<p style='color: green;'>✅ Old data cleared</p>";

// ============================================
// 1. ADD INSTITUTIONS (Universities)
// ============================================
$institutions = [
    ['University of Nairobi', 'UoN', 'Nairobi', 'careers@uonbi.ac.ke', '024'],
    ['Jomo Kenyatta University', 'JKUAT', 'Kiambu', 'careers@jkuat.ac.ke', '045'],
    ['Strathmore University', 'Strathmore', 'Nairobi', 'careers@strathmore.edu', '032'],
    ['Moi University', 'Moi', 'Eldoret', 'careers@mu.ac.ke', '056'],
    ['Kenyatta University', 'KU', 'Nairobi', 'careers@ku.ac.ke', '078'],
    ['Technical University of Mombasa', 'TUM', 'Mombasa', 'careers@tum.ac.ke', '089']
];

foreach ($institutions as $inst) {
    $sql = "INSERT INTO institutions (name, short_name, location, email, code) 
            VALUES ('$inst[0]', '$inst[1]', '$inst[2]', '$inst[3]', '$inst[4]')";
    if ($conn->query($sql)) {
        echo "<p style='color: green;'>✅ Added institution: $inst[0]</p>";
    }
}

// ============================================
// 2. ADD COMPANIES (Employers)
// ============================================
$companies = [
    ['Safaricom PLC', 'Telecommunications', 'Nairobi', 'hr@safaricom.co.ke', '5000+', 'Verified'],
    ['KCB Bank Kenya', 'Banking', 'Nairobi', 'careers@kcb.co.ke', '3000+', 'Verified'],
    ['Kenya Airways', 'Aviation', 'Nairobi', 'hr@kenya-airways.com', '2000+', 'Verified'],
    ['EABL', 'Beverage', 'Nairobi', 'careers@eabl.com', '1500+', 'Verified'],
    ['Equity Bank', 'Banking', 'Nairobi', 'hr@equitybank.co.ke', '2500+', 'Verified'],
    ['M-Kopa', 'Fintech', 'Nairobi', 'jobs@m-kopa.com', '500+', 'Verified'],
    ['Twiga Foods', 'Agri-tech', 'Nairobi', 'careers@twigafoods.com', '300+', 'Verified'],
    ['Cellulant', 'Fintech', 'Nairobi', 'hr@cellulant.com', '400+', 'Verified']
];

foreach ($companies as $comp) {
    $sql = "INSERT INTO companies (name, industry, location, email, size, status) 
            VALUES ('$comp[0]', '$comp[1]', '$comp[2]', '$comp[3]', '$comp[4]', '$comp[5]')";
    if ($conn->query($sql)) {
        echo "<p style='color: green;'>✅ Added company: $comp[0]</p>";
    }
}

// ============================================
// 3. ADD STUDENTS (Realistic Profiles)
// ============================================
$students = [
    // UoN Students
    ['Wendy Jane', 'wendy.jane@students.uonbi.ac.ke', 'University of Nairobi', 'Computer Science', 3, 3.8, 'Python, JavaScript, React, SQL, Django, Node.js', 'Nairobi', '2026'],
    ['Brian Otieno', 'brian.otieno@students.uonbi.ac.ke', 'University of Nairobi', 'Electrical Engineering', 4, 3.6, 'Circuit Design, MATLAB, C++, Python, AutoCAD', 'Nairobi', '2026'],
    ['Sarah Kimani', 'sarah.kimani@students.uonbi.ac.ke', 'University of Nairobi', 'Business IT', 3, 3.5, 'Excel, SQL, Power BI, Python, Data Analysis', 'Nairobi', '2026'],
    
    // JKUAT Students
    ['James Mwangi', 'james.mwangi@students.jkuat.ac.ke', 'Jomo Kenyatta University', 'Software Engineering', 4, 3.6, 'Java, Spring Boot, MySQL, AWS, Docker, JavaScript', 'Kiambu', '2026'],
    ['Mary Wanjiku', 'mary.wanjiku@students.jkuat.ac.ke', 'Jomo Kenyatta University', 'Civil Engineering', 4, 3.7, 'AutoCAD, Revit, Structural Analysis, Project Management', 'Kiambu', '2026'],
    ['Peter Odhiambo', 'peter.odhiambo@students.jkuat.ac.ke', 'Jomo Kenyatta University', 'Mechatronics', 3, 3.4, 'Arduino, C++, Robotics, PLC, SolidWorks', 'Kiambu', '2026'],
    
    // Strathmore Students
    ['Alice Kariuki', 'alice.kariuki@strathmore.edu', 'Strathmore University', 'Data Science', 4, 3.9, 'Python, Pandas, TensorFlow, SQL, Tableau, R', 'Nairobi', '2026'],
    ['Michael Omondi', 'michael.omondi@strathmore.edu', 'Strathmore University', 'Finance', 4, 3.7, 'Excel, Financial Modeling, Python, Bloomberg, CPA', 'Nairobi', '2026'],
    ['Cynthia Muthoni', 'cynthia.muthoni@strathmore.edu', 'Strathmore University', 'Business', 3, 3.5, 'Marketing, Excel, Social Media, Communication', 'Nairobi', '2026'],
    
    // Moi University
    ['John Otieno', 'john.otieno@mu.ac.ke', 'Moi University', 'Computer Science', 3, 3.2, 'Python, JavaScript, HTML, CSS, PHP', 'Eldoret', '2026'],
    ['Esther Chepkirui', 'esther.chepkirui@mu.ac.ke', 'Moi University', 'Agriculture', 4, 3.6, 'Agronomy, Research, Data Analysis, Report Writing', 'Eldoret', '2026'],
    ['David Kiprono', 'david.kiprono@mu.ac.ke', 'Moi University', 'Economics', 4, 3.4, 'Statistics, Excel, Stata, Research, Data Analysis', 'Eldoret', '2026'],
    
    // TUM
    ['Hassan Ali', 'hassan.ali@tum.ac.ke', 'Technical University of Mombasa', 'Marine Engineering', 4, 3.3, 'Naval Architecture, AutoCAD, Mechanical Systems', 'Mombasa', '2026'],
    ['Fatma Said', 'fatma.said@tum.ac.ke', 'Technical University of Mombasa', 'Hospitality', 3, 3.5, 'Customer Service, Hotel Operations, Events, Communication', 'Mombasa', '2026'],
    ['Kennedy Mwangi', 'kennedy.mwangi@tum.ac.ke', 'Technical University of Mombasa', 'IT', 3, 3.1, 'Networking, Python, SQL, Hardware, Troubleshooting', 'Mombasa', '2026'],
    
    // KU
    ['Lucy Wambui', 'lucy.wambui@ku.ac.ke', 'Kenyatta University', 'Education', 4, 3.6, 'Teaching, Communication, Curriculum Development', 'Nairobi', '2026'],
    ['Samuel Kipchoge', 'samuel.kipchoge@ku.ac.ke', 'Kenyatta University', 'Sports Science', 3, 3.2, 'Fitness Training, Nutrition, Coaching, First Aid', 'Nairobi', '2026']
];

foreach ($students as $s) {
    $sql = "INSERT INTO students (name, email, university, course, year, cgpa, skills, location, graduation_year) 
            VALUES ('$s[0]', '$s[1]', '$s[2]', '$s[3]', $s[4], $s[5], '$s[6]', '$s[7]', '$s[8]')";
    if ($conn->query($sql)) {
        echo "<p style='color: green;'>✅ Added student: $s[0]</p>";
    }
}

// ============================================
// 4. ADD JOBS (Real Internships)
// ============================================
$jobs = [
    // Safaricom Jobs (company_id = 1)
    [1, 'Software Developer Intern', 'Join Safaricom\'s digital team working on M-PESA and innovative products', 'Python, JavaScript, SQL, React', 3.0, 'Nairobi', 'KSh 45,000/month', '3 months'],
    [1, 'Network Engineer Intern', 'Work with Kenya\'s largest telecommunications network', 'CCNA, Networking, TCP/IP, Linux', 3.2, 'Nairobi', 'KSh 40,000/month', '4 months'],
    [1, 'Data Science Intern', 'Analyze customer data and build ML models', 'Python, SQL, Machine Learning, Statistics', 3.5, 'Nairobi', 'KSh 50,000/month', '3 months'],
    
    // KCB Jobs (company_id = 2)
    [2, 'Banking Intern', 'Learn banking operations and customer service', 'Excel, Communication, Accounting, Finance', 3.0, 'Nairobi', 'KSh 35,000/month', '6 months'],
    [2, 'Risk Analyst Intern', 'Assess credit risk and financial data', 'Excel, SQL, Statistics, Financial Analysis', 3.2, 'Nairobi', 'KSh 38,000/month', '4 months'],
    
    // Kenya Airways Jobs (company_id = 3)
    [3, 'Aviation Intern', 'Learn airline operations and customer service', 'Communication, Customer Service, MS Office', 3.0, 'Nairobi', 'KSh 32,000/month', '4 months'],
    [3, 'Engineering Intern', 'Work with aircraft maintenance team', 'Mechanical Engineering, AutoCAD, Problem Solving', 3.2, 'Nairobi', 'KSh 35,000/month', '3 months'],
    
    // EABL Jobs (company_id = 4)
    [4, 'Marketing Intern', 'Assist with brand marketing campaigns', 'Marketing, Excel, Communication, Social Media', 3.0, 'Nairobi', 'KSh 38,000/month', '3 months'],
    [4, 'Supply Chain Intern', 'Learn logistics and distribution', 'Logistics, Excel, Supply Chain, Communication', 3.0, 'Nairobi', 'KSh 36,000/month', '4 months'],
    
    // Equity Bank Jobs (company_id = 5)
    [5, 'Banking Intern', 'Customer service and banking operations', 'Excel, Communication, Customer Service', 3.0, 'Nairobi', 'KSh 35,000/month', '4 months'],
    [5, 'IT Support Intern', 'Help desk and technical support', 'Networking, Hardware, Windows, Troubleshooting', 3.0, 'Nairobi', 'KSh 32,000/month', '3 months'],
    
    // M-Kopa Jobs (company_id = 6)
    [6, 'Software Developer Intern', 'Build fintech solutions', 'Python, JavaScript, React, Node.js, MongoDB', 3.2, 'Nairobi', 'KSh 45,000/month', '3 months'],
    
    // Regional Jobs
    [3, 'Customer Service Intern', 'Kenya Airways - Mombasa office', 'Communication, Customer Service, MS Office', 3.0, 'Mombasa', 'KSh 30,000/month', '3 months'],
    [2, 'Banking Intern', 'KCB - Kisumu branch', 'Excel, Communication, Banking', 3.0, 'Kisumu', 'KSh 32,000/month', '4 months'],
    [1, 'Field Technician Intern', 'Safaricom - Eldoret office', 'Networking, Hardware, Customer Service', 3.0, 'Eldoret', 'KSh 35,000/month', '3 months']
];

foreach ($jobs as $j) {
    $sql = "INSERT INTO jobs (company_id, title, description, required_skills, min_cgpa, location, salary, duration) 
            VALUES ($j[0], '$j[1]', '$j[2]', '$j[3]', $j[4], '$j[5]', '$j[6]', '$j[7]')";
    if ($conn->query($sql)) {
        echo "<p style='color: green;'>✅ Added job: $j[1]</p>";
    }
}

echo "<h2 style='color: #4ade80; margin-top: 20px;'>✅ REAL DATA ADDED SUCCESSFULLY!</h2>";
echo "<p>Added: " . count($institutions) . " institutions</p>";
echo "<p>Added: " . count($companies) . " companies</p>";
echo "<p>Added: " . count($students) . " students</p>";
echo "<p>Added: " . count($jobs) . " jobs</p>";

echo '<p><a href="../student/dashboard.php" style="color: white;">View Student Dashboard →</a></p>';
echo '<p><a href="../company/dashboard.html" style="color: white;">View Company Dashboard →</a></p>';
echo '<p><a href="../institution/dashboard.html" style="color: white;">View Institution Dashboard →</a></p>';
?>