<?php
require_once '../includes/db_connect.php';
require_once 'match-engine.php';

$engine = new SmartMatchEngine($conn);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Test AI Matching</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #0f172a; color: white; padding: 20px; }
        .card { background: #1e293b; border: 1px solid #334155; border-radius: 10px; padding: 20px; margin: 20px 0; }
        .score { color: #4ade80; font-size: 2rem; font-weight: bold; }
        .table { color: white; }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="text-success">🧪 Test AI Matching Engine</h1>
        
        <div class="card">
            <h3>Step 1: Fetching Jobs</h3>
            <?php
            $jobs = $conn->query("SELECT * FROM jobs");
            echo "<p>Found " . $jobs->num_rows . " jobs</p>";
            ?>
        </div>
        
        <div class="card">
            <h3>Step 2: Fetching Students</h3>
            <?php
            $students = $conn->query("SELECT * FROM students");
            echo "<p>Found " . $students->num_rows . " students</p>";
            ?>
        </div>
        
        <div class="card">
            <h3>Step 3: Test Single Match</h3>
            <?php
            // Get first job and first student
            $job = $conn->query("SELECT * FROM jobs LIMIT 1")->fetch_assoc();
            $student = $conn->query("SELECT * FROM students LIMIT 1")->fetch_assoc();
            
            if ($job && $student) {
                $match = $engine->calculateOverallMatch($job, $student);
                ?>
                <p><strong>Job:</strong> <?= $job['title'] ?></p>
                <p><strong>Student:</strong> <?= $student['name'] ?></p>
                <p><strong>Skills Match:</strong> <?= $match['skills'] ?>%</p>
                <p><strong>CGPA Match:</strong> <?= $match['cgpa'] ?>%</p>
                <p><strong>Location Match:</strong> <?= $match['location'] ?>%</p>
                <h2 class="score">Overall: <?= $match['overall'] ?>%</h2>
                <?php
            }
            ?>
        </div>
        
        <div class="card">
            <h3>Step 4: Test All Matches for Job #1</h3>
            <?php
            $matches = $engine->findMatchesForJob(1);
            ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>Rank</th>
                        <th>Student</th>
                        <th>University</th>
                        <th>Skills Match</th>
                        <th>CGPA</th>
                        <th>Overall</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($matches as $index => $m): ?>
                    <tr>
                        <td>#<?= $index + 1 ?></td>
                        <td><?= $m['student']['name'] ?></td>
                        <td><?= $m['student']['university'] ?></td>
                        <td><?= $m['breakdown']['skills'] ?>%</td>
                        <td><?= $m['student']['cgpa'] ?></td>
                        <td><strong style="color: #4ade80;"><?= $m['match_score'] ?>%</strong></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <div class="text-center">
            <a href="../company/ai-matches.php" class="btn btn-success btn-lg">Next: View Company AI Matches →</a>
        </div>
    </div>
</body>
</html>