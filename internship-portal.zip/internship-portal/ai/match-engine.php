<?php
/**
 * AI Matching Engine - Pure PHP, No Python!
 */

class SmartMatchEngine {
    private $conn;
    
    public function __construct($db_connection) {
        $this->conn = $db_connection;
    }
    
    /**
     * Calculate skill match percentage
     */
    public function calculateSkillMatch($requiredSkills, $candidateSkills) {
        // Convert strings to arrays
        $required = array_map('trim', explode(',', strtolower($requiredSkills)));
        $candidate = array_map('trim', explode(',', strtolower($candidateSkills)));
        
        if (empty($required) || empty($required[0])) {
            return 100;
        }
        
        if (empty($candidate) || empty($candidate[0])) {
            return 0;
        }
        
        // Count matches
        $matches = array_intersect($required, $candidate);
        $matchCount = count($matches);
        $requiredCount = count($required);
        
        // Calculate percentage
        return round(($matchCount / $requiredCount) * 100, 2);
    }
    
    /**
     * Calculate CGPA match
     */
    public function calculateCGPAMatch($requiredCGPA, $studentCGPA) {
        if ($requiredCGPA <= 0) {
            return 100;
        }
        
        if ($studentCGPA >= $requiredCGPA) {
            return 100;
        } else {
            $ratio = $studentCGPA / $requiredCGPA;
            return round($ratio * 100, 2);
        }
    }
    
    /**
     * Calculate location match
     */
    public function calculateLocationMatch($jobLocation, $studentLocation) {
        if (empty($jobLocation) || $jobLocation == 'Any' || $jobLocation == 'Remote') {
            return 100;
        }
        
        if (strtolower($jobLocation) == strtolower($studentLocation)) {
            return 100;
        }
        
        return 50; // Partial match
    }
    
    /**
     * Calculate overall match score
     */
    public function calculateOverallMatch($job, $student) {
        // Weights
        $skillWeight = 60;
        $cgpaWeight = 25;
        $locationWeight = 15;
        
        // Calculate scores
        $skillScore = $this->calculateSkillMatch(
            $job['required_skills'] ?? '',
            $student['skills'] ?? ''
        );
        
        $cgpaScore = $this->calculateCGPAMatch(
            $job['min_cgpa'] ?? 0,
            $student['cgpa'] ?? 0
        );
        
        $locationScore = $this->calculateLocationMatch(
            $job['location'] ?? '',
            $student['location'] ?? ''
        );
        
        // Weighted average
        $totalScore = (
            ($skillScore * $skillWeight / 100) +
            ($cgpaScore * $cgpaWeight / 100) +
            ($locationScore * $locationWeight / 100)
        );
        
        return [
            'overall' => round($totalScore, 2),
            'skills' => $skillScore,
            'cgpa' => $cgpaScore,
            'location' => $locationScore
        ];
    }
    
    /**
     * Find best matches for a job
     */
    public function findMatchesForJob($jobId, $limit = 10) {
        // Get job
        $query = "SELECT * FROM jobs WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $jobId);
        $stmt->execute();
        $job = $stmt->get_result()->fetch_assoc();
        
        if (!$job) {
            return [];
        }
        
        // Get all students
        $query = "SELECT * FROM students";
        $result = $this->conn->query($query);
        $matches = [];
        
        while ($student = $result->fetch_assoc()) {
            $score = $this->calculateOverallMatch($job, $student);
            
            $matches[] = [
                'student' => $student,
                'match_score' => $score['overall'],
                'breakdown' => [
                    'skills' => $score['skills'],
                    'cgpa' => $score['cgpa'],
                    'location' => $score['location']
                ]
            ];
        }
        
        // Sort by score (highest first)
        usort($matches, function($a, $b) {
            return $b['match_score'] <=> $a['match_score'];
        });
        
        return array_slice($matches, 0, $limit);
    }
    
    /**
     * Find best jobs for a student
     */
    public function findMatchesForStudent($studentId, $limit = 10) {
        // Get student
        $query = "SELECT * FROM students WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $studentId);
        $stmt->execute();
        $student = $stmt->get_result()->fetch_assoc();
        
        if (!$student) {
            return [];
        }
        
        // Get all jobs
        $query = "SELECT * FROM jobs";
        $result = $this->conn->query($query);
        $matches = [];
        
        while ($job = $result->fetch_assoc()) {
            $score = $this->calculateOverallMatch($job, $student);
            
            $matches[] = [
                'job' => $job,
                'match_score' => $score['overall'],
                'breakdown' => [
                    'skills' => $score['skills'],
                    'cgpa' => $score['cgpa'],
                    'location' => $score['location']
                ]
            ];
        }
        
        // Sort by score
        usort($matches, function($a, $b) {
            return $b['match_score'] <=> $a['match_score'];
        });
        
        return array_slice($matches, 0, $limit);
    }
}
?>