<?php
// Turn on error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
$host = 'localhost';
$user = 'root';
$pass = '';
$db = 'internship_portal';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$error = '';
$success = '';

// Handle registration
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_type = $_POST['user_type'] ?? 'student';
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    // Validate input
    if (empty($name) || empty($email) || empty($password)) {
        $error = 'Please fill in all required fields';
    } elseif ($password !== $confirm_password) {
        $error = 'Passwords do not match';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters';
    } else {
        // Check if email already exists
        $table = $user_type === 'student' ? 'students' : ($user_type === 'company' ? 'companies' : 'institutions');
        $check = $conn->query("SELECT id FROM $table WHERE email = '$email'");
        
        if ($check && $check->num_rows > 0) {
            $error = 'Email already registered';
        } else {
            // Hash password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // Insert based on user type
            if ($user_type === 'student') {
                $query = "INSERT INTO students (name, email, password, university, course, year, cgpa, skills, location) 
                         VALUES (?, ?, ?, '', '', 1, 0.0, '', '')";
                $stmt = $conn->prepare($query);
                $stmt->bind_param("sss", $name, $email, $hashed_password);
            } elseif ($user_type === 'company') {
                $query = "INSERT INTO companies (name, email, password, industry, location, size, website, description) 
                         VALUES (?, ?, ?, '', '', '', '', '')";
                $stmt = $conn->prepare($query);
                $stmt->bind_param("sss", $name, $email, $hashed_password);
            } else {
                $query = "INSERT INTO institutions (name, email, password, location, established, students_count, code) 
                         VALUES (?, ?, ?, '', '', 0, '')";
                $stmt = $conn->prepare($query);
                $stmt->bind_param("sss", $name, $email, $hashed_password);
            }
            
            if ($stmt->execute()) {
                $success = 'Registration successful! You can now login.';
            } else {
                $error = 'Registration failed: ' . $conn->error;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - SmartIntern Kenya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #0f172a;
            color: #e2e8f0;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        .flag-header {
            height: 4px;
            background: linear-gradient(90deg, 
                #000000 0%, #000000 33.33%,
                #b91c1c 33.33%, #b91c1c 66.66%,
                #059669 66.66%, #059669 100%);
        }
        
        .navbar {
            background: #1e293b;
            border-bottom: 1px solid #334155;
            padding: 1rem 0;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        .navbar-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .navbar-brand {
            font-weight: 700;
            font-size: 1.3rem;
            color: #4ade80;
            text-decoration: none;
        }
        
        .navbar-brand i {
            color: #4ade80;
            margin-right: 8px;
        }
        
        .btn-home {
            border: 1px solid #4ade80;
            color: #4ade80;
            padding: 8px 20px;
            border-radius: 6px;
            text-decoration: none;
            transition: all 0.2s;
        }
        
        .btn-home:hover {
            background: #4ade80;
            color: #0f172a;
        }
        
        .register-container {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 40px 20px;
        }
        
        .register-card {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 16px;
            padding: 40px;
            width: 100%;
            max-width: 500px;
            box-shadow: 0 20px 30px rgba(0, 0, 0, 0.3);
        }
        
        .register-header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .register-header i {
            font-size: 3rem;
            color: #4ade80;
            margin-bottom: 15px;
        }
        
        .register-header h2 {
            color: white;
            font-size: 2rem;
            margin-bottom: 5px;
        }
        
        .register-header p {
            color: #94a3b8;
        }
        
        /* User Type Selector */
        .user-type-selector {
            display: flex;
            gap: 15px;
            margin-bottom: 25px;
            justify-content: center;
        }
        
        .type-option {
            flex: 1;
            text-align: center;
        }
        
        .type-option input[type="radio"] {
            display: none;
        }
        
        .type-option label {
            display: block;
            padding: 15px;
            background: #0f172a;
            border: 1px solid #334155;
            border-radius: 8px;
            color: #94a3b8;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .type-option input[type="radio"]:checked + label {
            background: #4ade80;
            color: #0f172a;
            border-color: #4ade80;
        }
        
        .type-option label i {
            display: block;
            font-size: 1.5rem;
            margin-bottom: 5px;
        }
        
        /* Form */
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #cbd5e1;
            font-weight: 500;
        }
        
        .form-control {
            width: 100%;
            padding: 12px 15px;
            background: #0f172a;
            border: 1px solid #334155;
            border-radius: 8px;
            color: white;
            font-size: 1rem;
            transition: all 0.2s;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #4ade80;
            box-shadow: 0 0 0 3px rgba(74, 222, 128, 0.2);
        }
        
        .form-control::placeholder {
            color: #64748b;
        }
        
        /* Alert */
        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        
        .alert-danger {
            background: #fee2e2;
            color: #b91c1c;
            border: 1px solid #fecaca;
        }
        
        .alert-success {
            background: #d1fae5;
            color: #065f46;
            border: 1px solid #a7f3d0;
        }
        
        /* Buttons */
        .btn-register {
            width: 100%;
            padding: 14px;
            background: #4ade80;
            color: #0f172a;
            border: none;
            border-radius: 8px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            margin-bottom: 20px;
        }
        
        .btn-register:hover {
            background: #22c55e;
            transform: translateY(-2px);
        }
        
        .login-link {
            text-align: center;
            color: #94a3b8;
        }
        
        .login-link a {
            color: #4ade80;
            text-decoration: none;
            font-weight: 600;
        }
        
        .login-link a:hover {
            text-decoration: underline;
        }
        
        /* Footer */
        .footer {
            background: #1e293b;
            border-top: 1px solid #334155;
            padding: 20px 0;
            text-align: center;
            color: #64748b;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .register-card {
                padding: 30px 20px;
            }
            
            .user-type-selector {
                flex-direction: column;
                gap: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="flag-header"></div>
    
    <!-- Navbar with Home Link -->
    <nav class="navbar">
        <div class="container navbar-content">
            <a href="index.php" class="navbar-brand">
                <i class="fas fa-shield-alt"></i>SmartIntern Kenya
            </a>
            
            <a href="index.php" class="btn-home">
                <i class="fas fa-home me-2"></i>Back to Home
            </a>
        </div>
    </nav>
    
    <!-- Register Container -->
    <div class="register-container">
        <div class="register-card">
            <div class="register-header">
                <i class="fas fa-user-plus"></i>
                <h2>Create Account</h2>
                <p>Join SmartIntern Kenya today</p>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle me-2"></i><?= $error ?>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle me-2"></i><?= $success ?>
                </div>
                <div class="text-center mt-3">
                    <a href="login.php" class="btn-home" style="display: inline-block;">Go to Login</a>
                </div>
            <?php else: ?>
            
            <form method="POST" action="">
                <!-- User Type Selection -->
                <div class="user-type-selector">
                    <div class="type-option">
                        <input type="radio" name="user_type" value="student" id="student" checked>
                        <label for="student">
                            <i class="fas fa-user-graduate"></i>
                            <span>Student</span>
                        </label>
                    </div>
                    
                    <div class="type-option">
                        <input type="radio" name="user_type" value="company" id="company">
                        <label for="company">
                            <i class="fas fa-building"></i>
                            <span>Company</span>
                        </label>
                    </div>
                    
                    <div class="type-option">
                        <input type="radio" name="user_type" value="institution" id="institution">
                        <label for="institution">
                            <i class="fas fa-university"></i>
                            <span>Institution</span>
                        </label>
                    </div>
                </div>
                
                <!-- Full Name -->
                <div class="form-group">
                    <label for="name">Full Name</label>
                    <input type="text" class="form-control" id="name" name="name" 
                           placeholder="Enter your full name" required>
                </div>
                
                <!-- Email -->
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" class="form-control" id="email" name="email" 
                           placeholder="you@example.com" required>
                </div>
                
                <!-- Password -->
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" class="form-control" id="password" name="password" 
                           placeholder="Min. 6 characters" required>
                </div>
                
                <!-- Confirm Password -->
                <div class="form-group">
                    <label for="confirm_password">Confirm Password</label>
                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" 
                           placeholder="Re-enter password" required>
                </div>
                
                <!-- Terms -->
                <div class="form-group" style="margin-bottom: 25px;">
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <input type="checkbox" id="terms" required style="width: 16px; height: 16px; accent-color: #4ade80;">
                        <label for="terms" style="margin-bottom: 0; color: #94a3b8;">
                            I agree to the <a href="#" style="color: #4ade80; text-decoration: none;">Terms of Service</a> and 
                            <a href="#" style="color: #4ade80; text-decoration: none;">Privacy Policy</a>
                        </label>
                    </div>
                </div>
                
                <!-- Register Button -->
                <button type="submit" class="btn-register">
                    <i class="fas fa-user-plus me-2"></i>Create Account
                </button>
                
                <!-- Login Link -->
                <div class="login-link">
                    Already have an account? <a href="login.php">Sign In</a>
                </div>
            </form>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <p>&copy; 2026 SmartIntern Kenya. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>